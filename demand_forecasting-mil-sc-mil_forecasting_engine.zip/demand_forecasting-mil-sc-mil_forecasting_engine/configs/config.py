"""
    This file contains the configuration parameters to run the MIL Demand Forecast Module.
"""

CHANNEL_NAME = 'GT'
FORECAST_TYPE = 'MIL' #MIL/RBF
RUN_MONTH = "2023-11-30"

# 
RUN_TYPE = 'Monthly Run'

# flag to enable runs to snowflake or not
PUSH_DATA_TO_SNOWFLAKE = False

# Prepare Modelling Data Flag
PREPARE_MODELLING_DATA = False

# generate forecast results
GENERATE_FORECAST_RESULT = True

# Flag to show streamlit dashboard
RUN_STREAMLIT_DASHBOARD = False

# Start Date & End Date for fetching the data from database
START_DATE = '2017-01-01'

# Train Data Table Name of Snowflake
MIL_DATA_SNOWFLAKE_TABLE = 'TRN_MIL_DF_DATA'

# Train Data Table Name of Snowflake
MIL_RBF_DATA_SNOWFLAKE_TABLE = 'TRN_MIL_RBF_DF_DATA'

# RBF ML Runs table
RBF_TREND_DATA_TABLE  = 'TRN_MIL_RBF_RESULTS'

# RBF range runs table
RBF_RUN_FORECAST_TABLE = 'TRN_MIL_RBF_DF_RESULTS'



MONTH_DICT = {
    1: "Jan",
    2: "Feb",
    3: "Mar",
    4: "Apr",
    5: "May",
    6: "Jun",
    7: "Jul",
    8: "Aug",
    9: "Sep",
    10: "Oct",
    11: "Nov",
    12: "Dec"}