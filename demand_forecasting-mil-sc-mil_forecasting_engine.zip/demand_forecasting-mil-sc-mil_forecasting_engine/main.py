"""
Author: Pranjal Soni
Version: 0.0.2
Description: This file is the main file to run the forecast engine pipeline
"""

# file to run the project
from src import pd, datetime, os, shutil, relativedelta, MonthEnd
from src import (
    GetInputTemplateDataClass,
    GetSalesDataClass,
    PrepMasterData,
    MasterDataValidation,
    SnowflakeDataIngestion,
    PrepRBFMasterData,
)
from src import OutlierTreatmentClass, FeatureSelectionModuleClass
from src import (
    GetMlModelsResultsClass,
    GetProphetModelResultsClass,
    GetCtsModelResultsClass,
    GetDLResultsClass,
)
from src import CreateSummary
from src import GetRBFResult, MILStreamlitDashboard, RBFStreamlitDashboard
from src import FetchSnowflakeData, PushResultToSnowflake
import configs as mil_config


def read_input_template():
    """
      Read the input template data.
    Returns:
        input_dict(dict): all the inputs with input templates
    """
    # reading input template file stored at data/processed/Inputs_Template.xlsx
    if mil_config.FORECAST_TYPE.strip().lower() == "mil":
        input_template_location = (
            f"input/{mil_config.CHANNEL_NAME}_Inputs_Template.xlsx"
        )
    else:
        input_template_location = (
            f"input/{mil_config.CHANNEL_NAME}_RBF_Inputs_Template.xlsx"
        )

    input_template_data = pd.read_excel(
        input_template_location, engine="openpyxl", sheet_name=None
    )
    # get input template data
    get_input_template_data_obj = GetInputTemplateDataClass(
        input_template_data=input_template_data, config=mil_config
    )
    get_input_template_data_obj.run()
    input_dict = get_input_template_data_obj.input_dict
    # delete the class using del keyword
    del get_input_template_data_obj
    return input_dict


def read_modelling_data(input_dict):
    """
        Reading the modelling data.
    Returns:
        df ( pandas dataframe): dataframe with the all the demand variables
    """
    # get sales data
    get_sales_data_obj = GetSalesDataClass(input_dict=input_dict, config=mil_config)
    df = (
        get_sales_data_obj.run()
    )
    input_dict = get_sales_data_obj.input_dict
    del get_sales_data_obj
    return df


def push_data_to_db(df, path, table_name):
    data_push_obj = SnowflakeDataIngestion()
    data_updated = data_push_obj.push_to_snowflake(
        df=df, snowflake_table_name=table_name, date=mil_config.RUN_MONTH, cap_cols=True
    )
    if data_updated:
        shutil.rmtree(path)
        print(
            "\n Data is Successfully updated to snowflake \n And Deleted From Local..."
        )


def prepare_mil_data():
    """
    Perform the data validation and push data to snowflake.
    """
    prep_data_obj = PrepMasterData(input_dict=input_dict, config=mil_config)
    data_prepared = prep_data_obj.prepare_master_data()

    if data_prepared:
        curr_month, curr_year = datetime.now().month, str(datetime.now().year)[-2:]
        curr_month = mil_config.MONTH_DICT[curr_month] + "'" + curr_year

        path = f"./data/model_input_data/{curr_month}/"
        master_data_file = f"{mil_config.CHANNEL_NAME.lower()}_mil_data_updated.csv"

        df = pd.read_csv(os.path.join(path, master_data_file))
        data_val_obj = MasterDataValidation(df, input_dict, mil_config.CHANNEL_NAME)
        data_validation = data_val_obj.run_data_validation()
        df = df.round(4)
        df.columns = ["_".join(col.split('-')) if '-' in col else col for col in df.columns ]
        if data_validation == True:
            push_data_to_db(df, path, mil_config.MIL_DATA_SNOWFLAKE_TABLE)


def generate_forecasting_results(df, input_dict):
    """Runs All the models mentioned in input template and
        save the outputs in the respective folders
    Args:
        df ( pandas dataframe): dataframe with the all the demand variables
        input_dict ( dict): all the inputs with input templates
    """
    # get outlier treatment
    outlier_treatment_obj = OutlierTreatmentClass(input_dict=input_dict)
    df = outlier_treatment_obj.run(df=df)
    del outlier_treatment_obj

    # #get basic feature selection done
    feature_selection_module_obj = FeatureSelectionModuleClass(input_dict=input_dict)
    df = feature_selection_module_obj.run_basic_feature_selection_process(df=df)

    #run ml pipeline
    ml_results_obj = GetMlModelsResultsClass(df=df,
                                            input_dict=input_dict,
                                            feature_selection_module_obj=feature_selection_module_obj)
    ml_results_obj.run()
    del ml_results_obj

    # run prophet pipeline
    prophet_results_obj = GetProphetModelResultsClass(df=df, input_dict=input_dict)

    prophet_results_obj.run()
    del prophet_results_obj

    # run cts pipeline
    cts_results_obj = GetCtsModelResultsClass(
        df=df,
        input_dict=input_dict,
    )
    cts_results_obj.run()
    del cts_results_obj

    # run dl pipeline
    dl_model_obj = GetDLResultsClass(input_dict=input_dict, df=df)
    dl_model_obj.run()
    del dl_model_obj

    # create summary files
    cs = CreateSummary(input_dict=input_dict)
    cs.run()

    # generate rbf results
    # rbf_result_obj = GetRBFResult( input_dict=input_dict, df=df)
    # rbf_result_obj.run()

    del df, input_dict


if __name__ == "__main__":
    input_dict = read_input_template()

    if mil_config.PREPARE_MODELLING_DATA:
      # print(f" Preparing Modelling Data For {mil_config.CHANNEL_NAME} \
      #       For Start Date: {mil_config.START_DATE} to End Date: {input_dict['train_till_date']} ")

      data_check_query = f"""SELECT DISTINCT("RUN_MONTH") FROM {mil_config.MIL_DATA_SNOWFLAKE_TABLE} where channel = '{mil_config.CHANNEL_NAME}'"""
      run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=data_check_query)['run_month'].tolist()
      print(run_months)
      if mil_config.RUN_MONTH not in run_months:
            prepare_mil_data()

      if mil_config.FORECAST_TYPE == 'RBF':
          prep_data_obj = PrepRBFMasterData( input_dict=input_dict, config= mil_config)
          data_prepared = prep_data_obj.prepare_master_data()

          if data_prepared:
            curr_month, curr_year = datetime.now().month, str(datetime.now().year)[-2:]
            curr_month = mil_config.MONTH_DICT[curr_month] + "'" + curr_year
            path = f"./data/model_input_data/{curr_month}/"
            master_data_file = f"{mil_config.CHANNEL_NAME.lower()}_mil_rbf_data_updated.csv"
            df = pd.read_csv( os.path.join( path, master_data_file))
            df.drop(['asm_area_code_x','asm_area_code_y'], axis=1, inplace=True, errors='ignore')
            df = df.round(4)
            push_data_to_db( df, path, mil_config.MIL_RBF_DATA_SNOWFLAKE_TABLE)


    if mil_config.GENERATE_FORECAST_RESULT:
        df  = read_modelling_data(input_dict=input_dict)
        # df = df[df['key'].isin(df['key'].unique()[:1])]
        qtr_ind_rate_df = df[['month_date','brand_code', 'qtr_ind_rate']].drop_duplicates(subset=['month_date', 'brand_code'], keep='first')
        # generate the forecasting results
        input_dict['index_rate_data'] = qtr_ind_rate_df.reset_index(drop=True).copy()
        input_dict['input_template_data_processed']['di_model_input']['idx_key_cols'] = ['month_date', 'brand_code']
        df.drop('qtr_ind_rate', axis=1, inplace=True)
        generate_forecasting_results(df = df, input_dict=input_dict)
    
    for file in os.listdir('data/processed'):
        if 'cache' in file: 
            print(f'Deleting {file}....')
            os.remove(os.path.join('data/processed/'+file))

    if mil_config.PUSH_DATA_TO_SNOWFLAKE:
        if mil_config.FORECAST_TYPE == 'RBF':
            PushResultToSnowflake(input_dict, mil_config).push_rbf_results_to_snowflake()
        else:
            PushResultToSnowflake(input_dict, mil_config).push_mil_data_to_snowflake()

    if mil_config.RUN_STREAMLIT_DASHBOARD:
        if mil_config.FORECAST_TYPE == 'RBF' :
            mil_streamlit_dashboard_obj =RBFStreamlitDashboard(
                input_dict=input_dict, config=mil_config
            )
            mil_streamlit_dashboard_obj.run_streamlit_dashboard()
            
        if mil_config.FORECAST_TYPE == 'MIL':
            mil_streamlit_dashboard_obj = MILStreamlitDashboard(
                input_dict=input_dict, config=mil_config
            )
            mil_streamlit_dashboard_obj.run_streamlit_dashboard()