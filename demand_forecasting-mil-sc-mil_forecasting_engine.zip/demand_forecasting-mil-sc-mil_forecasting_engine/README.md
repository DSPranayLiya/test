#  Forecast Engine
<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li> <a href="#Instructions">Instructions to use the repository</a></li>
    <li> <a href="#about-the-project">About The Project</a></li>
    <li>  <a href="#getting-started">Getting Started</a></li>
        <ul>
            <li><a href="#checklist">Input Template Location</a></li>
            <li><a href="Usage">Usage</a></li>
            <li><a href="PipelineFlow">Pipeline Flow</a></li>
            <li><a href="Documentation">Detailed Documentation</a></li>
      </ul>
    </li>
  </ol>
</details>



<!-- Instructions -->
## Instructions to use the repository


- If you are using the forecast engine pipeline for a different project altogether then follow these steps:

  * Click on fork option on the top-right corner of the screen.

  * Select the repository owner and give the repository name.

  * Click on create fork.

  * Now, clone this new repository to get started with your new project.

- If you are developing a new feature for a forecast engine pipeline then follow these steps:

  * Clone the repository

  ```sh
  git clone git@github.com:MaricoDataScience/forecast_engine.git
  ```

  * Make sure you are on the main branch by using the following command:

  ```sh
  git branch
  ```

  * Make a new branch and name it that best describe the feature you are developing:

  ```sh
  git checkout -b feature_branch_name
  ```
  
  * Start your work on the newly created branch.

  * After developing the feature on the new branch. Create a pull request to merge the changes to development branch.

  * Once the changes are tested in development branch, again create a pull request to merge the new feature to main branch.

  > Make sure you do not do any changes directly to main and development branch. It should always via pull request.


<!-- ABOUT THE PROJECT -->
## About The Project

The following repository contains the code for general forecasting pipeline.

<!-- GETTING STARTED -->
## Getting Started

These instructions will get you a copy of the project up and running on your dev/prod server.
A step by step process given below that witll tell you how to get the pipeline running.


<!-- #checklist -->
### Input Template Location
```
    input/Inputs_Template.xlsx
```

<!--Usage-->
### Usage
1. The input template should get updated as per requirements of forecasting.
2. All the files(like sales data or extra files like master data, festival data, bpm_file/index_rate file)
    must be placed at following location ```data/processed/```
3. Now run the following command to run the pipeline.

    ```sh
    bash main.sh
    ```

<!-- #PipelineFlow -->
### Overall Forecast Engine Pipeline Flow
<p align="center">
  <img src="docs/forecast_engine_overall_pipeline.png" title="Overall flow of forecast engine pipeline">
</p>

<!-- #Documentation -->
### Detailed Documentation

Detailed documentation for forecast engine is at ```Wiki```.