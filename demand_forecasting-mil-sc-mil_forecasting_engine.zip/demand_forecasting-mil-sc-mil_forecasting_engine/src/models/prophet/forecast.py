"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains all the function to generate live results.
"""
from ...helper import os, pd, Prophet, pickle, traceback, pickle, record_model_runtime
from ...helper import GetProphetPipelineInput

class ProphetForecastClass(GetProphetPipelineInput):
    """
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        with open(f"{self.location_to_save}/prophet_results/validation/prophet_models.pkl", 'rb') as f:
            self.prophet_model_list = pickle.load(f)
        self.path = input_dict["prophet_forecast_dir"]

    @record_model_runtime(function_name='prophet_forecast')
    def run(self, Key):
            """
            This function will generate the live forecast from prophet model for a combination

            Arguments:

            df_prophet_model: pandas dataframe 
            -contains the sales data along with date in a format required by prophet
            model.

            Key: str 
            - contains the key for which validation process needs to run

            actual_forecast_period: list of datetime values
            - contains the months to be forecasted

            prophet_model_list: list
            - list contains the best params of prophet model for all keys
            
            holidays_df: pandas dataframe
            - holidays data with festival data included in a format required by prophet for 
            holidays_df parameter
            
            Return:
                forecast: pandas dataframe
                - contains the prediction of training & testing data along with all the features
                for a key
            """
            try:
                df_prophet_key = self.df_prophet_model[self.df_prophet_model.key == Key]
                if pd.isnull(self.di_model_input['holiday_data_type'])==False:
                    holidays_df = self.create_holidays_df(Key=Key)
                else:
                    holidays_df = pd.DataFrame()

                train = df_prophet_key[df_prophet_key[self.prophet_DATE_COL] <= self.di_model_input['train_till_date']].copy()
                if Key in self.prophet_model_list.keys():
                    best_param = self.prophet_model_list[Key]
                    if holidays_df.empty==True:
                        m = Prophet(changepoint_prior_scale = float(best_param['changepoint_prior_scale']),
                            changepoint_range = float(best_param['changepoint_range']),
                            seasonality_prior_scale = float(best_param['seasonality_prior_scale']))
                    else:
                        m = Prophet(changepoint_prior_scale = float(best_param['changepoint_prior_scale']),
                                    changepoint_range = float(best_param['changepoint_range']),
                                    seasonality_prior_scale = float(best_param['seasonality_prior_scale']),
                                    holidays=holidays_df)
                    if self.additional_regressors:
                        for add_reg in self.additional_regressors:
                            m.add_regressor(add_reg)
                    m.fit(train.drop(['key'],axis=1))
                    future = m.make_future_dataframe(periods=len(self.actual_forecast_period), freq =self.input_dict['data_frequency'])
                    if self.additional_regressors:
                        future = pd.merge(future, df_prophet_key[['ds']+self.additional_regressors], how="left",
                                on = ['ds'])
                    forecast = m.predict(future)
                    forecast[self.prophet_pred_column] = forecast[self.prophet_pred_column].apply(lambda x : 0 if x < 0 else x)
                    forecast['key'] = Key
                    forecast = pd.merge(forecast, df_prophet_key[['key',self.prophet_DATE_COL,
                                    self.prophet_target_column]], on = [self.prophet_DATE_COL,"key"], how = "left")
                    if self.index_rate.empty==False:
                        forecast['pred'] = forecast[self.prophet_pred_column]
                        forecast[self.DATE_COL] = forecast[self.prophet_DATE_COL]
                        forecast = self.get_bpm(df_to_update = forecast, original_df = self.original_df)
                        forecast[f"{self.prophet_pred_column}_value"] = forecast['pred_value']
                        forecast.drop(["pred","pred_value"],axis=1,inplace=True)
                    forecast['Model_Run'] = 'Yes'
                    forecast['Model_Type'] = 'Prophet'
                    return [forecast]

            except Exception as e:
                err  = str(traceback.format_exc())
                with open(f"{self.path}/{Key}_prophet_forecast_errors.txt", 'w+') as f:
                        f.write(str(err))

            