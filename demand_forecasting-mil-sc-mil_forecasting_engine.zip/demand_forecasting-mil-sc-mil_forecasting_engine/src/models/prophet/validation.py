"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains all the function to generate prophet validation results.
"""

from ...helper import os, np, pd, Prophet, cross_validation, MonthEnd,\
    Parallel, cpu_count, delayed, logger_1, logger_2, logger_3, relativedelta, traceback, pickle
from ...helper import calculate_bias, calculate_wape, calculate_root_mean_sqaured_error, concatenate_pandas_dataframe,\
    get_add_month, get_add_days, record_model_runtime
from ...helper import GetProphetPipelineInput

class ProphetValidationClass(GetProphetPipelineInput):
    """
    This class will get validation results for prophet model
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        self.path = self.input_dict["prophet_valid_dir"]
        
        
    def calculate_prophet_metrics(self, data, idx, is_vol=True):
        """
        This function will calculate the metrics required to select
        the best prophet model.

        Arguments:

            data: pandas dataframe
            - contains the actual and target column values

            is_vol: bool
            - signifies whether to calculate metrics for volume or value

        Results:

            data: pandas dataframe
            - updated dataframe contains the actual and pred alond with bias calculataion

            wape: float
            - wape metric value

            rmse: float
            - rmse metric value
        """
        if is_vol==True:
            pred = self.prophet_pred_column
            actual = self.prophet_target_column
            col = 'vol'
        else:
            pred = f"{self.prophet_pred_column}_value"
            actual = f"{self.prophet_target_column}_value"
            col = 'val'

        data = calculate_bias(data = data, target_column=actual, pred_column=pred)

        if self.di_model_input['buffer_horizon']==0:
            pass
        else:
            if self.input_dict['data_frequency']=='M':
                to_exclude = get_add_month(x = data[self.prophet_DATE_COL].min(), months=self.di_model_input['buffer_horizon'])
            if self.input_dict['data_frequency']=='D':
                to_exclude = get_add_days(x = data[self.prophet_DATE_COL].min(), days=self.di_model_input['buffer_horizon'])
            data = data[data[self.prophet_DATE_COL]>=to_exclude]
        wape = calculate_wape(y_true=data[actual], y_pred=data[pred])*100
        rmse = calculate_root_mean_sqaured_error(y_true=data[actual], y_pred=data[pred])

        data = data.rename(columns={self.prophet_DATE_COL:f"Validation_Date_{idx+1}_{col}",
                                                'bias':f"Validation_Bias_{idx+1}_{col}",
                                                pred:f"Validation_Bias_{idx+1}_pred_{col}",
                                                actual:f"Validation_Bias_{idx+1}_actual_{col}"}).reset_index(drop=True)
        return data, wape, rmse

    def rolling_cross_validation_prophet(self, history_df, param_dict, cutoffs_periods_subset, cv_periods_subset, holidays_df):
        """
        This function will perform the cross validation of a prophet model for all the 
        validation sets for single combination.

        Arguments:

            history_df: pandas dataframe 
            - data frame to be used for cross-validation
            
            param_dict: dict 
            - contains the parameters to be passed in prophet model
            
            cutoffs_periods_subset: list of datetime values 
            - contains the different cutoffs for different validation sets


            cv_periods_subset: list of list of datetime values
            - contains the list of all validation periods for different cutoff

            holidays_df: pandas dataframe
            - holidays data with festival data included in a format required by prophet for 
            holidays_df parameter
        Return:

            results: dict
            - contains the validation bias and validation accuracy, parameters 
            of prophet model for a key
        """
        cv_error_valid_volume, cv_validation_bias_volume, cv_wape_valid_volume = [],[],[]
        cv_error_valid_value, cv_validation_bias_value, cv_wape_valid_value = [],[],[]
        if holidays_df.empty==True:
            m = Prophet(**param_dict)
        else:
            m = Prophet(**param_dict, holidays=holidays_df)

        if self.additional_regressors:
            for add_reg in self.additional_regressors:
                m.add_regressor(add_reg)
        key = history_df['key'].values[0]
        m.fit(history_df.drop(["key"],axis=1))

        cutoffs_periods_subset = [pd.to_datetime(date.date()) for date in cutoffs_periods_subset]
        if min(self.prophet_horizon)==max(self.prophet_horizon):
            prophet_horizon_to_use = str(max(self.prophet_horizon))+" days"
            df_cv = cross_validation(m, cutoffs=cutoffs_periods_subset, horizon=prophet_horizon_to_use,disable_tqdm=True)
        
        if min(self.prophet_horizon)!=max(self.prophet_horizon):
            cv_outputs = []
            for idx in range(len(self.prophet_horizon)):
                prophet_horizon_to_use = str(self.prophet_horizon[idx])+" days"
                cv_outputs.append(cross_validation(m,cutoffs=[cutoffs_periods_subset[idx]],horizon=prophet_horizon_to_use,disable_tqdm=True))
            cv_outputs = concatenate_pandas_dataframe(data_list=cv_outputs)
            df_cv = cv_outputs[cv_outputs['cutoff'].isin(cutoffs_periods_subset)]
        
        df_cv[self.prophet_DATE_COL] = pd.to_datetime(df_cv[self.prophet_DATE_COL])
        df_cv["cutoff"] = df_cv["cutoff"] 
        df_cv['yhat'] = df_cv['yhat'].apply(lambda x : 0 if x < 0 else x)
        df_cv[self.DATE_COL] = df_cv[self.prophet_DATE_COL]
        history_df[self.prophet_DATE_COL] = history_df[self.prophet_DATE_COL]

        for idx in range(0,len(cutoffs_periods_subset)):

            df_cv_1 = df_cv[(df_cv["cutoff"]==cutoffs_periods_subset[idx]) & (df_cv[self.prophet_DATE_COL].isin(cv_periods_subset[idx]))]
            df_cv_1['key'] = key
            vb_cv_1_volume = df_cv_1[[self.prophet_DATE_COL, self.prophet_target_column, self.prophet_pred_column]].copy()
            vb_cv_1_volume, wape_cv_1_volume, valid_rmse_volume_cv_1 = self.calculate_prophet_metrics(data=vb_cv_1_volume, idx=idx)
        
            if self.index_rate.empty==False:
                df_cv_1['pred'] = df_cv_1[self.prophet_pred_column]
                df_cv_1 = self.get_bpm(df_to_update = df_cv_1, original_df = self.original_df, target_column=self.prophet_target_column)
                df_cv_1[f"{self.prophet_pred_column}_value"] = df_cv_1['pred_value']
                df_cv_1.drop(["pred","pred_value"],axis=1,inplace=True)
                vb_cv_1_value = df_cv_1[[self.prophet_DATE_COL,f"{self.prophet_pred_column}_value",f'{self.prophet_target_column}_value']].copy()
                vb_cv_1_value, wape_cv_1_value, valid_rmse_cv_1_value = self.calculate_prophet_metrics(data=vb_cv_1_value,idx=idx,is_vol=False)
                
                cv_error_valid_value.append(valid_rmse_cv_1_value)
                cv_validation_bias_value.append(vb_cv_1_value)
                cv_wape_valid_value.append(wape_cv_1_value)       

            cv_error_valid_volume.append(valid_rmse_volume_cv_1)
            cv_validation_bias_volume.append(vb_cv_1_volume)
            cv_wape_valid_volume.append(wape_cv_1_volume)

        results = {
                    "cv_error_valid_volume":np.mean(cv_error_valid_volume),
                    "cv_wape_valid_volume":np.mean(cv_wape_valid_volume),
                    "cv_validation_bias_volume":cv_validation_bias_volume,
                    'params':param_dict
            }
        
        if self.index_rate.empty==False:
            results["cv_error_valid_value"]=np.mean(cv_error_valid_value)
            results["cv_wape_valid_value"]=np.mean(cv_wape_valid_value)
            results["cv_validation_bias_value"]=cv_validation_bias_value
            
        return results

    @record_model_runtime( function_name='prophet_validation_run')
    def run(self, Key):
        """
        This is the final function to run in order to generate the prophet validation
        results for a combination

        Arguments:

            Key: str
            - contains the key for which validation process needs to run

        Return:

            validation_results: pandas dataframe
            - contains the cross validation accuracy, bias along with predictions & features

            prophet_model_dict: dict
            - contains the best parameter of prophet model for a key

        """
        # print(Key)
        try:
            df_prophet_key = self.df_prophet_model[self.df_prophet_model.key == Key]
            df_key = self.original_df[self.original_df['key']==Key]
            cutoffs_periods_subset, cv_periods_subset = self.cross_validation_date_check(data_key=df_key)
            del df_key
            
            params_df_dict = self.params_df.to_dict("records")
            if pd.isnull(self.di_model_input['holiday_data_type'])==False:
                holidays_df = self.create_holidays_df(Key=Key)
            else:
                holidays_df = pd.DataFrame()
            date_to_filter_prophet_data = max(list(map(max, zip(*cv_periods_subset))))
            history_df = df_prophet_key[df_prophet_key[self.prophet_DATE_COL] <= date_to_filter_prophet_data]

            prophet_validation_output =  Parallel(n_jobs = cpu_count()-2)(delayed(self.rolling_cross_validation_prophet)
                                                                    (history_df=history_df, 
                                                                    param_dict=param, 
                                                                    holidays_df = holidays_df,
                                                                    cutoffs_periods_subset=cutoffs_periods_subset, 
                                                                    cv_periods_subset=cv_periods_subset)
                                                                    for param in params_df_dict)
            # prophet_validation_output = [self.rolling_cross_validation_prophet
            #                                                         (history_df=history_df, 
            #                                                         param_dict=param, 
            #                                                         holidays_df = holidays_df,
            #                                                         cutoffs_periods_subset=cutoffs_periods_subset, 
            #                                                         cv_periods_subset=cv_periods_subset)
            #                                                         for param in params_df_dict]

            best = prophet_validation_output[np.argmin([r['cv_error_valid_volume'] for r in prophet_validation_output])]
            valid_error_volume = best['cv_error_valid_volume']
            valid_wape_acc_volume = 100-best['cv_wape_valid_volume']
            validation_bias_volume = best["cv_validation_bias_volume"]
            validation_bias_volume = concatenate_pandas_dataframe(data_list=validation_bias_volume, axis=1,
                                    ignore_index=False)
            if self.index_rate.empty==False:
                validation_bias_value = best["cv_validation_bias_value"]   
                validation_bias_value = concatenate_pandas_dataframe(validation_bias_value, axis=1,
                                                        ignore_index=False)
            else:
                validation_bias_value = pd.DataFrame()
            
            validation_results = concatenate_pandas_dataframe(data_list=[validation_bias_volume,validation_bias_value], 
                                                                axis=1,
                                                                ignore_index=False) 
            validation_results["CV_RMSE_Volume"] = valid_error_volume
            validation_results["CV_WAPE_Volume"] = valid_wape_acc_volume
            if self.index_rate.empty==False:
                validation_results["CV_RMSE_Value"] = best['cv_error_valid_value']
                validation_results["CV_WAPE_Value"] = 100-best['cv_wape_valid_value']
            validation_results["Model_Type"] = "Prophet"
            validation_results["key"] = Key
            prophet_model_dict = {}
            prophet_model_dict[Key] = best['params']
            return validation_results, prophet_model_dict

        except Exception as e:
            err  = str(traceback.format_exc())
            with open(f"{self.path}/{Key}_prophet_valid_errors.txt", 'w+') as f:
                    f.write(str(err))




# prophet_validation_arg_dict = {"history_df":history_df,
#                                 "cutoffs_periods_subset":cutoffs_periods_subset,
#                                 "cv_periods_subset":cv_periods_subset,
#                                 "holidays_df":holidays_df}


# prophet_validation_output = run_parallel_functions(func=self.rolling_cross_validation_prophet,
#                                                     df = params_df.values,
#                                                     argument_dict=prophet_validation_arg_dict,
#                                                     iter_col=params_df_dict,
#                                                     is_iter_idx=True,
#                                                     is_df_arg=False,
#                                                     desc="Prophet Cross Validation")

# prophet_validation_output = [self.rolling_cross_validation_prophet
#                                                         (history_df=history_df, 
#                                                         param_dict=param, 
#                                                         holidays_df = holidays_df,
#                                                         cutoffs_periods_subset=cutoffs_periods_subset, 
#                                                         cv_periods_subset=cv_periods_subset)
#                                                         for param in params_df_dict]