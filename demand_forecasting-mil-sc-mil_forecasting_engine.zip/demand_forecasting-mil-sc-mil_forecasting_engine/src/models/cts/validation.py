
"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains all the functions to generate cts validation & live forecast results
"""

from ...helper import os, auto_arima, pd, np, traceback, pickle
from ...helper import calculate_r2, calculate_wape, concatenate_pandas_dataframe, get_diff_month, get_diff_days
from ...helper import GetCtsPipelineInput

class CtsForecastClass(GetCtsPipelineInput):
    """
    """
    def __init__(self, df, input_dict, model_type):
        """
        This class will do the validation and forecast for the cts model passed
        in argument
        """
        super().__init__(df=df, input_dict=input_dict)
        self.model_type = model_type
        self.path = self.input_dict[f"{model_type}_dir"]


    def fit_arima_model(self, train_data, valid_data):
        """
         This function will fit the ARIMA model for a single key combination.

        Arguments:

            train_data: pandas dataframe 
            - contains the training data

            valid_data: pandas dataframe
            - contains the testing data 

        Return:

            train_final: pandas dataframe
            - contains the train data along with its predictions for best arima model of 
            a combination

            valid_final: pandas dataframe
            - contains the test data along with its predictions for best arima model of a
            combination

            stepwise_model: pmdarima object
            - contains the best arima model
        """
        try:
            stepwise_model = auto_arima(train_data.drop(["key"],axis=1),
                                        start_p=self.di_cts_inputs['ARIMA']["start_p"], 
                                        start_q=self.di_cts_inputs['ARIMA']["start_q"],
                                        max_p=self.di_cts_inputs['ARIMA']["max_p"], 
                                        max_q=self.di_cts_inputs['ARIMA']["max_q"], 
                                        seasonal=False,
                                        test=self.di_cts_inputs['ARIMA']["stationarity_test"],
                                        trace=False,error_action='ignore',
                                        suppress_warnings=True,stepwise=True)
                
        except Exception as e:
                stepwise_model = auto_arima(train_data.drop(["key"],axis=1),start_p=self.di_cts_inputs['ARIMA']["start_p"], 
                                                start_q=self.di_cts_inputs['ARIMA']["start_q"],
                                    max_p=self.di_cts_inputs['ARIMA']["max_p"], 
                                    max_q=self.di_cts_inputs['ARIMA']["max_q"], 
                                    seasonal=False,
                                    test="kpss",
                                    suppress_warnings=True,stepwise=True)
        forecast = stepwise_model.predict(n_periods=len(valid_data))
        forecast = pd.DataFrame(forecast).reset_index(drop=True)
        valid_data[self.DATE_COL] = pd.to_datetime(valid_data.index)
        valid_data = valid_data.reset_index(drop=True)
        valid_data['pred'] = forecast
        resids = stepwise_model.resid()

        train_data[self.DATE_COL] = pd.to_datetime(train_data.index)
        train_data = train_data.reset_index(drop=True)
        try:train_data.loc[:, 'Residuals'] = resids.values
        except: train_data.loc[:, 'Residuals'] = resids
        train_data['pred'] = train_data[self.target_column] - train_data['Residuals']

        train_final = train_data.copy()
        valid_final = valid_data.copy()

        return train_final, valid_final, stepwise_model

    
    def fit_sarima_model(self, train_data, valid_data):
        """
         This function will fit the SARIMA model for a single key combination.

        Arguments:

            train_data: pandas dataframe 
            - contains the training data

            valid_data: pandas dataframe
            - contains the testing data 

        Return:

            train_final: pandas dataframe
            - contains the train data along with its predictions for best sarima model of 
            a combination

            valid_final: pandas dataframe
            - contains the test data along with its predictions for best sarima model of a
            combination

            stepwise_model: pmdarima object
            - contains the best sarima model
        
        """
        valid_final = []
        train_final = []
        model = {}
    
        for m in self.di_cts_inputs['SARIMA']["m"]:
            try:
                stepwise_model = auto_arima(train_data.drop(['key'],axis=1), start_p=self.di_cts_inputs['SARIMA']["start_p"], 
                                                        start_q=self.di_cts_inputs['SARIMA']["start_q"],
                                                        max_p=self.di_cts_inputs['SARIMA']["max_p"], 
                                                        max_q=self.di_cts_inputs['SARIMA']["max_q"], 
                                                        seasonal=True, 
                                                        start_P=self.di_cts_inputs['SARIMA']["start_P"], 
                                                        start_Q=self.di_cts_inputs['SARIMA']["start_Q"], 
                                                        max_P=self.di_cts_inputs['SARIMA']["max_P"], 
                                                        max_Q=self.di_cts_inputs['SARIMA']["max_Q"], 
                                                        m=m,
                                                        d=None, D=None, 
                                                        test=self.di_cts_inputs['SARIMA']["stationarity_test"],
                                                        seasonal_test=self.di_cts_inputs['SARIMA']["seasonality_test"],
                                                        trace=False, error_action='ignore', suppress_warnings=True, stepwise=True)
            except Exception as e:
                    stepwise_model = auto_arima(train_data.drop(['key'],axis=1), start_p=self.di_cts_inputs['SARIMA']["start_p"], 
                                                start_q=self.di_cts_inputs['SARIMA']["start_q"],
                                                max_p=self.di_cts_inputs['SARIMA']["max_p"], 
                                                max_q=self.di_cts_inputs['SARIMA']["max_q"], 
                                                seasonal=True, 
                                                start_P=self.di_cts_inputs['SARIMA']["start_P"], 
                                                start_Q=self.di_cts_inputs['SARIMA']["start_Q"], 
                                                max_P=self.di_cts_inputs['SARIMA']["max_P"], 
                                                max_Q=self.di_cts_inputs['SARIMA']["max_Q"], 
                                                m=m,
                                                d=None, D=None, 
                                                test="kpss",
                                                seasonal_test=self.di_cts_inputs['SARIMA']["seasonality_test"],
                                                trace=False, error_action='ignore', suppress_warnings=True, stepwise=True)  
        
            forecast,conf_int = stepwise_model.predict(n_periods=len(valid_data), return_conf_int=True)
            valid_copy = valid_data.copy()
            train_copy = train_data.copy()
            forecast = forecast.tolist()
            valid_copy[self.DATE_COL] = pd.to_datetime(valid_copy.index)
            train_copy[self.DATE_COL] = pd.to_datetime(train_copy.index)
            valid_copy = valid_copy.reset_index(drop=True)
            train_copy = train_copy.reset_index(drop=True)
            valid_copy['pred'] = forecast
            resids = stepwise_model.resid()
            try:train_copy.loc[:, 'Residuals'] = resids.values
            except: train_copy.loc[:, 'Residuals'] = resids
            train_copy['pred'] = train_copy[self.target_column] - train_copy['Residuals']
            valid_copy['m'] = m
            train_copy['m'] = m
            valid_final.append(valid_copy)
            train_final.append(train_copy)
            model[m] = stepwise_model.bic()
            
        best_m = min(model, key=model.get)
        valid_final = concatenate_pandas_dataframe(data_list=valid_final)
        train_final = concatenate_pandas_dataframe(data_list=train_final)
        train_final = train_final[train_final['m']==best_m]
        valid_final = valid_final[valid_final['m']==best_m]
        return train_final, valid_final, stepwise_model

    def fit_cts_model(self, train_data, valid_data):
        """
        This function will fit the cts model for a combination.

        Arguments:

            train_data: pandas dataframe 
            - contains the training data

            valid_data: pandas dataframe
            - contains the testing data 

        Return:

            train_final: pandas dataframe
            - contains the train data along with its predictions for best cts model of 
            a combination

            valid_final: pandas dataframe
            - contains the test data along with its predictions for best cts model of a
            combination

            stepwise_model: pmdarima object
            - contains the best cts model
        """
        train_data.index = train_data[self.DATE_COL]
        train_data.drop([self.DATE_COL],axis=1,inplace=True)
    
        valid_data.index = valid_data[self.DATE_COL]
        valid_data.drop([self.DATE_COL],axis=1,inplace=True)

        if self.model_type=="ARIMA":
            train_final,valid_final,stepwise_model = self.fit_arima_model(train_data=train_data,
                                                                        valid_data=valid_data)
        if self.model_type=="SARIMA":
            train_final,valid_final,stepwise_model = self.fit_sarima_model(train_data=train_data,
                                                                        valid_data=valid_data)
                                                                        
        return train_final,valid_final,stepwise_model

    def cts_validation(self, data_key, cutoffs_periods_subset, cv_periods_subset):
        """
        This function will perform the  cross validation of sarima model(for all values of m) 
        for all validation sets of a combination.

        Arguments:

            data_key: pandas dataframe 
            - contains the sales data on monthly level for a combination

            DATE_COL: str 
            - defines the name of the date column in data_key

            cutoffs_periods_subset: list of datetime values
            - contains the different cutoffs for different validation sets
            
            cv_periods_subset: list of list of datetime values 
            - contains the list of all validation periods for different cutoff
            
        Return:

        valid_error_value: float
        - defines the validation error in terms of bpm

        valid_wape_acc_value: float
        - defines the validatioin wape in terms of bpm

        valid_error_volume: float
        - defines the validation error in terms of vol

        valid_wape_acc_volume: float
        - defines the validation wape in terms of vol

        validation_bias: pandas dataframe
        - contains validation bias, predictions & accuracies for all months in 
        validation sets.

        """
        try:
            cv_error_train_volume, cv_r2_score_train_volume, cv_error_valid_volume, cv_wape_valid_volume = [],[],[],[]
            cv_validation_bias_volume = []
            
            cv_error_train_value, cv_r2_score_train_value, cv_error_valid_value, cv_wape_valid_value = [],[],[],[]
            cv_validation_bias_value = []        

            for idx in range(len(cutoffs_periods_subset)):
                train_cv = data_key[data_key[self.DATE_COL]<=cutoffs_periods_subset[idx]]
                valid_cv = data_key[data_key[self.DATE_COL].isin(cv_periods_subset[idx])]
                train_cv, valid_cv, _ = self.fit_cts_model(train_cv, valid_cv) 
                valid_cv = valid_cv[valid_cv[self.DATE_COL].isin(cv_periods_subset[idx])]
                valid_cv_metric = self.calculate_forecasting_metrics(train=train_cv, 
                                                        train_pred=train_cv['pred'].tolist(), 
                                                        valid=valid_cv, 
                                                        valid_pred=valid_cv['pred'].tolist(), 
                                                        original_df=self.original_df,
                                                        vb_value=True)
                vol_metrics = self.get_metric_values(metric=valid_cv_metric, idx=idx, if_vol=True)
                cv_error_train_volume.append(vol_metrics[0])
                cv_r2_score_train_volume.append(vol_metrics[1])
                #valid metrics
                cv_error_valid_volume.append(vol_metrics[2])
                cv_wape_valid_volume.append(vol_metrics[3])
                cv_validation_bias_volume.append(vol_metrics[4])
                if self.index_rate.empty==False:
                    val_metrics = self.get_metric_values(metric=valid_cv_metric, idx=idx, if_vol=False)
                    cv_error_train_value.append(val_metrics[0])
                    cv_r2_score_train_value.append(val_metrics[1])
                    cv_error_valid_value.append(val_metrics[2])
                    cv_wape_valid_value.append(val_metrics[3])
                    cv_validation_bias_value.append(val_metrics[4]) 
            valid_error_volume = np.mean(cv_error_valid_volume)
            valid_wape_acc_volume = 100-np.mean(cv_wape_valid_volume)
            validation_bias_volume = concatenate_pandas_dataframe(data_list=cv_validation_bias_volume, axis=1,
                                        ignore_index=False)
            if self.index_rate.empty==False:
                valid_error_value = np.mean(cv_error_valid_value)
                valid_wape_acc_value = 100-np.mean(cv_wape_valid_value)
                validation_bias_value = concatenate_pandas_dataframe(data_list=cv_validation_bias_value, axis=1,
                                        ignore_index=False)
            else:
                validation_bias_value = pd.DataFrame()
                valid_error_value = 0
                valid_wape_acc_value = 0

            validation_bias = concatenate_pandas_dataframe(data_list=[validation_bias_volume, validation_bias_value], 
                                                        axis=1,
                                                        ignore_index=False)
            return valid_error_value,valid_wape_acc_value,valid_error_volume,valid_wape_acc_volume,validation_bias
        except:
            return 0


    def cts_forecast(self, train, test):
        """
        This function will generate the live forecast for cts model defined in the 
        constructor.

        Argument:

            train: pandas dataframe
            - contains the training data

            test: pandas dataframe
            - contains the testing data

        Return:

            train_updated: pandas dataframe
            - contains the train data along with its predictions for best cts model of 
            a combination

            test_updated: pandas dataframe
            - contains the test data along with its predictions for best cts model of a
            combination

            best_model: pmdarima object
            - contains the best cts model

        """
        train_updated, test_updated, best_model = self.fit_cts_model(train_data=train, valid_data=test)

        if self.index_rate.empty==False:

            train_updated = self.get_bpm(df_to_update=train_updated, original_df=self.original_df)
            test_updated = self.get_bpm(df_to_update=test_updated, original_df=self.original_df)

        return train_updated, test_updated, best_model

    
    def run(self, Key, validation=True):
        """
        This is the main function to get the cts results for a key 
        combination

        Arguments:

            Key: string
            - defines the Key for which data has to filtered

        Return:


            train_updated: pandas dataframe 
            - contains the training data predictions along with the training data

            test_updated: pandas dataframe
            - contains the testing data prediction along with cross-validation
            biases & accuracies.

            model: pmdarima object
            - best cts model for a key combination
        """
        try:
            model = {}
            data_key = self.df_cts_data[(self.df_cts_data['key']==Key)]
            train = data_key[data_key[self.DATE_COL]<=self.di_model_input["train_till_date"]].copy()
            test = pd.DataFrame(self.actual_forecast_period,columns=[self.DATE_COL])
            test['key'] = Key
            test['key'] = test['key'].astype(str)
            df_key = self.original_df[self.original_df['key']==Key]
            cutoffs_periods_subset, cv_periods_subset= self.cross_validation_date_check(data_key=df_key)
            del df_key
            cts_validation_output  = self.cts_validation(data_key = data_key, 
                                                        cutoffs_periods_subset= cutoffs_periods_subset,
                                                        cv_periods_subset = cv_periods_subset)
            if type(cts_validation_output)==int and (cts_validation_output==0):
                if self.input_dict['data_frequency']=="M":
                    func_to_use = get_diff_month
                elif self.input_dict['data_frequency']=="D":
                    func_to_use = get_diff_days
                else: 
                    pass

                cutoffs_periods_subset_updated = list(map(func_to_use, cutoffs_periods_subset))
                cv_periods_subset_updated =  list(map(lambda b : list(map(func_to_use, b)), cv_periods_subset))
                cts_validation_output = self.cts_validation(data_key = data_key, 
                                                        cutoffs_periods_subset= cutoffs_periods_subset_updated,
                                                        cv_periods_subset = cv_periods_subset_updated)
                
            valid_error_value = cts_validation_output[0]
            valid_wape_acc_value= cts_validation_output[1]
            valid_error_volume = cts_validation_output[2]
            valid_wape_acc_volume = cts_validation_output[3]
            validation_bias=cts_validation_output[4]
            
            train_updated, test_updated, best_model = self.cts_forecast(train, test)

            if self.index_rate.empty==False:
                train_acc_value = 100 -(calculate_wape(y_true=train_updated[f"{self.target_column}_value"], y_pred=train_updated['pred_value'])*100)
                r2_score_train_value = calculate_r2(y_true=train_updated[f"{self.target_column}_value"], y_pred=train_updated['pred_value'])
                test_updated.loc[:,"Train_Accuracy_value"] =train_acc_value
                test_updated.loc[:,"Train_R2_Score_value"] =r2_score_train_value
                test_updated.loc[:,"Valid_RMSE_value"] = valid_error_value
                test_updated.loc[:,'Valid_Accuracy_value'] = valid_wape_acc_value

            train_acc_volume =100 -(calculate_wape(y_true=train_updated[self.target_column], y_pred=train_updated['pred'])*100)
            r2_score_train_volume = calculate_r2(y_true=train_updated[self.target_column], y_pred=train_updated['pred'])
            test_updated.loc[:,"Train_Accuracy_volume"] =train_acc_volume
            test_updated.loc[:,"Train_R2_Score_volume"] =r2_score_train_volume
            test_updated.loc[:,"Valid_RMSE_volume"] = valid_error_volume
            test_updated.loc[:,'Valid_Accuracy_volume'] = valid_wape_acc_volume
            test_updated = concatenate_pandas_dataframe(data_list=[test_updated.reset_index(drop=True), validation_bias], axis=1,
                                                        ignore_index=False)
            
            train_updated.loc[:,"Model_Type"] = self.model_type
            test_updated.loc[:,"Model_Type"] = self.model_type
            model[Key] = best_model

            return train_updated, test_updated, model
        
        except Exception as e:
            err  = str(traceback.format_exc())
            with open(f"{self.path}/{Key}_{self.model_type}_errors.txt", 'w+') as f:
                    f.write(str(err))