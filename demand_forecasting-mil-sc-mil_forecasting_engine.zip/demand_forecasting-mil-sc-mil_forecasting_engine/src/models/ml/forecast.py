"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains all the functions to generate ml live forecast results
"""

from ...helper import os, np, pd, pickle, shap, plt, pickle, traceback
from ...helper import concatenate_pandas_dataframe, create_dir, record_model_runtime
from ...helper import GetMlPipelineInput

class MlForecastClass(GetMlPipelineInput):
    """
    This class contains the functions to give the ml live forecasts
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        with open(f'{self.location_to_save}/ml_results/validation/ml_models.pkl', 'rb') as f:
            self.ml_models_list = pickle.load(f)
        
        self.path = input_dict["ml_forecast_dir"]


    def get_shap_values(self, suffix, model, train, test, Key):
        """
        """
        plots_dir = f"{self.path}/shap_plots/{suffix}"
        create_dir(location=plots_dir, message="plots dir")

        if (suffix=="rf") or (suffix=="xgb") or (suffix=="lgbm"):
            explainer = shap.TreeExplainer(model,feature_names=train.drop(self.to_drop,axis=1).columns.tolist())
            
            train_shap_values = explainer.shap_values(train.drop(self.to_drop,axis=1))
            train_shap_values_df = pd.DataFrame(train_shap_values, 
                            columns=train.drop(self.to_drop,axis=1).columns.tolist())
            
            test_shap_values = explainer.shap_values(test.drop(self.to_drop,axis=1))
            test_shap_values_df = pd.DataFrame(test_shap_values, 
                            columns=test.drop(self.to_drop,axis=1).columns.tolist())

        else:
            explainer = shap.KernelExplainer(model.predict,train.drop(self.to_drop,axis=1))
            train_shap_values = explainer.shap_values(train.drop(self.to_drop,axis=1))
            
            train_shap_values_df = pd.DataFrame(train_shap_values, 
                            columns=train.drop(self.to_drop,axis=1).columns.tolist())
            
            explainer = shap.KernelExplainer(model.predict,test.drop(self.to_drop,axis=1))
            test_shap_values = explainer.shap_values(test.drop(self.to_drop,axis=1))
            test_shap_values_df = pd.DataFrame(test_shap_values, 
                            columns=test.drop(self.to_drop,axis=1).columns.tolist())
                            
        summary_dir = f"{plots_dir}/summary_plot/"
        create_dir(summary_dir,message="summary dir")
        fig = plt.figure() 
        fig.set_size_inches(30.,18.)
        shap.summary_plot(train_shap_values, train.drop(self.to_drop,axis=1),show=False)
        plt.title(f"{Key}")
        plt.tight_layout()
        plt.savefig(f"{summary_dir}/training_summary_plot_{Key}.png", bbox_inches='tight', dpi=200)
        shap.summary_plot(train_shap_values, train.drop(self.to_drop,axis=1),show=False)
        plt.title(f"{Key}")
        plt.tight_layout()
        plt.savefig(f"{summary_dir}/training_summary_plot_{Key}.png", bbox_inches='tight')
        plt.close()
        
        test = test.reset_index(drop=True)
        waterfall_dir = f"{plots_dir}/waterfall_plot/"
        create_dir(waterfall_dir,message="waterfall_plot")
        if (suffix=="rf") or (suffix=="xgb") or (suffix=="lgbm"):
            
            sv = explainer(test.drop(self.to_drop,axis=1))
            exp = shap.Explanation(sv.values, 
                        sv.base_values[0][0], 
                        data=test.drop(self.to_drop,axis=1).values, 
                        feature_names=test.drop(self.to_drop,axis=1).columns)
            for index, row in test.iterrows():
                fig = plt.figure() 
                fig.set_size_inches(30.,18.)
                shap.plots.waterfall(exp[index], show =False)
                plt.title(f"{Key}:{row[self.DATE_COL].date()}")
                plt.savefig(f"{waterfall_dir}/waterfall_{Key}_{row[self.DATE_COL].date()}.png",bbox_inches='tight',dpi=200)
                plt.close()
        else:
            for index, row in test.iterrows():
                fig = plt.figure() 
                fig.set_size_inches(30.,18.)
                sv = explainer.shap_values(test.loc[[index]].drop(self.to_drop,axis=1))   # pass the row of interest as df
                exp = shap.Explanation(sv,
                                    explainer.expected_value, 
                                    data=test.loc[[index]].drop(self.to_drop,axis=1).values, 
                                feature_names=test.drop(self.to_drop,axis=1).columns)
                shap.plots.waterfall(exp[0],show =False)
                plt.title(f"{Key}:{row[self.DATE_COL].date()}")
                plt.savefig(f"{waterfall_dir}/waterfall_{Key}_{row[self.DATE_COL].date()}.png",bbox_inches='tight',
                            dpi=200)
                plt.close()
                
        train_shap_values_df.loc[:,'key'] = Key
        train_shap_values_df.loc[:,'Model_Type'] = suffix
        
        train_shap_values_df.loc[:,self.DATE_COL] = train[self.DATE_COL].values
        test_shap_values_df.loc[:,'key'] = Key
        test_shap_values_df.loc[:,self.DATE_COL] = test[self.DATE_COL].values
        test_shap_values_df.loc[:,'Model_Type'] = suffix

        return train_shap_values_df, test_shap_values_df

    @record_model_runtime( function_name='ml_model_forecast')
    def run_forecast(self, best_model, train, test, Key, suffix):
        """
        This function will generate the live forecast for all ml models specific to a key

        Arguments:

            best_model: function
            - contains the best parameter for the model specified

            train: pandas dataframe
            - training data
            
            test: pandas dataframe
            - test data/ forecast data
        
            Key: key
            - contains the Key for which validation results needs to be calculated
            
            suffix: str
            - contains the model type

        Return:
            train: pandas dataframe
            - contains the training data along with prediction for a model & key specified

            test: pandas dataframe
            - contains the testing/forecast data along with prediction for a model & key specified

            feat_imp_df: pandas dataframe
            - contains the feature importance for a model and key specified

            forecast_data: dictionary
            - contains pca, shap data if the flag for pca and shap is 1
        """
        forecast_data = {}
        if self.di_model_input["VIF"]==1:
            vif_data = self.calculate_vif(train, suffix)
            forecast_data['vif'] = vif_data
        
        if self.di_model_input['PCA']==1:
            _PCA, PCA_mst_imp_feat, train_pred, pred = self.calculate_pca(train, test, best_model, suffix)
            forecast_data['pca'] = _PCA
            forecast_data['pca_mst_imp_feat'] = PCA_mst_imp_feat
        else:
            if suffix in ['lr','lasso','ridge','elasticnet', 'bayesian_ridge','xgb','rf','lgbm','mlp_2layer']:               
                best_model.fit(train.drop(self.to_drop,axis=1), train[self.target_column])
                train_pred  = best_model.predict(train.drop(self.to_drop,axis=1))
                pred = best_model.predict(test.drop(self.to_drop,axis = 1))
            
            if suffix in ['bayesian_lr']:
                train_pred, pred = self.run_bayesian_linear_regression(train=train, test=test)
        
        if self.di_model_input["SHAP"]==1:
            try:
                train_shap_values_df, test_shap_values_df = self.get_shap_values(suffix, best_model, train, test, Key)
                forecast_data['train_shap_values_df'] = train_shap_values_df
                forecast_data['test_shap_values_df'] = test_shap_values_df
            except:
                forecast_data['train_shap_values_df'] = pd.DataFrame()
                forecast_data['test_shap_values_df'] = pd.DataFrame()


        try:
            feat_imp = best_model.feature_importances_
            feat_imp_df = pd.DataFrame(feat_imp*100,index=test.drop(self.to_drop,axis = 1).columns,
                                            columns = ['feature_importance']).sort_values('feature_importance', ascending=False)
            feat_imp_df.loc[:,'key'] = Key
            feat_imp_df.loc[:,'Model_Type'] = suffix
            feat_imp_df.reset_index(inplace=True)
        except:
            feat_imp_df = pd.DataFrame()
                                                                        
        test['pred'] = pred
        test.loc[:,"key"] = Key
        train.loc[:,'pred'] = train_pred
        train.loc[:,"key"] = Key

        if self.index_rate.empty==False:
            train = self.get_bpm(df_to_update=train, original_df=self.original_df)
            test = self.get_bpm(df_to_update=test, original_df=self.original_df)
        
        train.loc[:,'Model_Type'] = suffix
        test.loc[:,'Model_Type'] = suffix
        return train, test, feat_imp_df, forecast_data


    def run(self, df, Key):
            """
            This is the final function(trigger function) to generate the live ml forecast
            for all the models and a specified keys

            Arguments:

                df: pandas dataframe
                - dataframe which contains the sales data along with all the demand drivers &
                transformed features(dataframe/data for modelling)
                
                Key: str
                - contains the Key for which validation results needs to be calculated
                

            Return:
            train_final: pandas dataframe
            - contains the training data along with prediction for all models & key specified

            forecast_final: pandas dataframe
            - contains the testing/forecast data along with prediction for all models & key specified

            fi_final: pandas dataframe
            - contains the feature importance for all models and key specified
            """
            try:
                train_final, forecast_final, fi_final = [],[],[]
                vif_final, pca_final, pca_mst_imp_final= [],[],[]
                tr_shap_values, te_shap_values =  [], []

                data_key = df[df.key == Key]
                if self.features_to_take.empty==True:
                    features_to_take_key = None
                else:
                    features_to_take_key = self.features_to_take[self.features_to_take['key']==Key]['k_best_features_name'].values.tolist()[0]
                    data_key = data_key[['key',self.DATE_COL,self.target_column]+features_to_take_key]
                
                train = data_key[data_key[self.DATE_COL] <=self.di_model_input['train_till_date']]
                test = data_key[data_key[self.DATE_COL].isin(self.actual_forecast_period)]
                ml_models = self.ml_models_list.get(Key, {})

                if len(ml_models)>0:
                    if self.di_model_input['ML_Modeling'] == 1:
                        if self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Model_Selected'] == np.nan:
                            model_list = self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Default_Choice'].split(',')
                        else:
                            model_list = self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Model_Selected'].split(',')
                    
                    for ml_model_type in model_list:
                        suffix = self.suffix_dict[ml_model_type]
                        best_model = ml_models.get(suffix, None)
                        if best_model:
                            train_lr, test_lr, fi_lr, fct_data_lr = self.run_forecast(best_model=best_model, 
                                                                                train = train.copy(), 
                                                                                test = test.copy(), 
                                                                                Key=Key, 
                                                                                suffix=suffix,
                                                                            )
                            train_final.append(train_lr)
                            forecast_final.append(test_lr)
                            fi_final.append(fi_lr)
                            if self.di_model_input['VIF']==1:
                                vif_final.append(fct_data_lr['vif'])
                            if self.di_model_input['PCA']==1:
                                pca_final.append(fct_data_lr['pca'])
                                pca_mst_imp_final.append(fct_data_lr['pca_mst_imp_feat'])
                            if self.di_model_input['SHAP']==1:
                                tr_shap_values.append(fct_data_lr['train_shap_values_df'])
                                te_shap_values.append(fct_data_lr['test_shap_values_df'])

                    train_final = concatenate_pandas_dataframe(data_list=train_final)
                    forecast_final = concatenate_pandas_dataframe(data_list=forecast_final)
                    fi_final = concatenate_pandas_dataframe(data_list=fi_final)
                    vif_final = concatenate_pandas_dataframe(data_list=vif_final)
                    pca_final = concatenate_pandas_dataframe(data_list=pca_final)
                    pca_mst_imp_final = concatenate_pandas_dataframe(data_list=pca_mst_imp_final)
                    tr_shap_values = concatenate_pandas_dataframe(data_list=tr_shap_values)
                    te_shap_values = concatenate_pandas_dataframe(data_list=te_shap_values)


                return train_final, forecast_final, fi_final, vif_final, pca_final, pca_mst_imp_final, tr_shap_values, te_shap_values
            except Exception as e:
        
                err  = str(traceback.format_exc())
                with open(f"{self.path}/{Key}_ml_forecast_errors.txt", 'w+') as f:
                    f.write(str(err))