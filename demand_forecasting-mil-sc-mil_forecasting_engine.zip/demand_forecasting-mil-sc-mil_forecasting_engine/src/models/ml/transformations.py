"""
Author: Aishwarya Verma
Version: 0.0.1
Description: This file contains all the functions to generate all the features(like lags, lead, moving average, trend, 
seasonality) for ml pipeline.
"""

from ...helper import pd, np, auto_arima, Prophet, calendar, logger_1, logger_2, logger_3, tqdm
from ...helper import run_parallel_functions, concatenate_pandas_dataframe
from ...helper import GetGeneralPipelineInput
from ...features import GetRecencyFactorClass

class GetMlFeatureTransformationsClass(GetGeneralPipelineInput):
    """
    This class contains all kinds of transformation methods required for ml
    modeling.
    """
    def __init__(self, input_dict):
        """
        """
        super().__init__(input_dict)
        self.add_recency_factor_obj = GetRecencyFactorClass(input_dict=input_dict)

                                
    def inter_cts_model(self, train, valid):
        """
        This function will run the arima model to give the forecast for valid data

        Arguments:

            train: pandas dataframe
            - contains the training data

            valid: pandas dataframe
            - contains the validation data

        Return:
            forecast: numpy array
            - contains the forecasted values for valid data
        """
        try:
            stepwise_model = auto_arima(train.drop(["key"],axis=1),start_p=self.di_cts_inputs['ARIMA']["start_p"], 
                                        start_q=self.di_cts_inputs['ARIMA']["start_q"],
                            max_p=self.di_cts_inputs['ARIMA']["max_p"], 
                            max_q=self.di_cts_inputs['ARIMA']["max_q"], 
                            seasonal=False,
                            test=self.di_cts_inputs['ARIMA']["stationarity_test"],
                            trace=False,error_action='ignore',
                            suppress_warnings=True,stepwise=True)
        except:
            stepwise_model = auto_arima(train.drop(["key"],axis=1),start_p=self.di_cts_inputs['ARIMA']["start_p"], 
                                        start_q=self.di_cts_inputs['ARIMA']["start_q"],
                            max_p=self.di_cts_inputs['ARIMA']["max_p"], 
                            max_q=self.di_cts_inputs['ARIMA']["max_q"], 
                            seasonal=False,
                            test="kpss",
                            suppress_warnings=True,stepwise=True)
        forecast = stepwise_model.predict(n_periods=valid.shape[0]).tolist()
        return forecast

    def inter_prophet_model(self, train, valid, validation_period):
        """
        This function will run the prophet model to give the forecast for valid data

        Argumets:

            train: pandas dataframe
            - contains the training data

            valid: pandas dataframe
            - contains the validation data

            validation_period: list
            - contains the validation period dates

        Return:
            forecast: numpy array
            - contains the forecasted values for valid data

        """
        train[self.DATE_COL] = train.index
        train = train.reset_index(drop=True)
        train = train.rename(columns={self.DATE_COL:"ds",
                                            self.target_column:"y"})
        m = Prophet()
        m.fit(train.drop(["key"],axis=1))
        future = m.make_future_dataframe(periods=valid.shape[0], freq ='M')
        forecast = m.predict(future)
        forecast = forecast[forecast['ds'].isin(validation_period)].sort_values(['ds'], ascending=True)
        forecast = forecast['yhat'].tolist()
        return forecast

    def replacing_valid_months_sales(self, df, Key, cutoff, validation_period, model_type=None):
            """
            This function will give the forecasted values from ARIMA for a single key

            Arguments:

                df: pandas dataframe
                - sales dataframe

                Key: str
                - contains which key to be processed/filtered upon

                cutoff: datetime
                - defines the date till which we have to take the data for training

                validation_period: list of datetime of values
                - defines the dates for which we have to generate the forecast for.

                model_type: string
                - contains the model to run(arima/prophet). Default is arima

            Return:
                valid: pandas dataframe
                - forecasted values of a key

            """
            data_key = df[(df['key']==Key)]
            
            train = data_key[data_key[self.DATE_COL]<=cutoff]
            train.index = train[self.DATE_COL]
            train.drop([self.DATE_COL],axis=1,inplace=True)
            valid = data_key[data_key[self.DATE_COL].isin(validation_period)]
            valid.index = valid[self.DATE_COL]
            valid.drop([self.DATE_COL],axis=1,inplace=True)
            
            if model_type==None:

                try:
                    forecast = self.inter_cts_model(train=train, valid=valid)
                except:
                    forecast = self.inter_prophet_model(train, valid, validation_period)
                
            if model_type=="cts":
                forecast = self.inter_cts_model(train, valid)
            
            if model_type=="prophet":
                forecast = self.inter_prophet_model(train=train, valid=valid, validation_period=validation_period)

            valid['pred'] = forecast
            valid[self.DATE_COL] = valid.index
            valid.reset_index(drop=True,inplace=True)
            valid = valid[valid[self.DATE_COL].isin(validation_period)]
            valid['key'] = Key
            return valid


    def create_lag_n_lead_features(self, df, lower, upper, var, colu, feat_type):
        """
        This function will create the lag features for the variable defined in the 
        input template for all combinations.

        Arguments:

            df: pandas dataframe


        """
        for i in range(lower, upper + 1):
            new_col = str(var)+'_'+str(feat_type)+'_'+str(i)
            if feat_type=="Lag":
                df[new_col] = df.groupby(['key'],as_index = False)[colu].shift(i)
                df[new_col] = df.groupby(['key'],as_index = True,group_keys = False)[new_col]\
                            .apply(lambda x:x.bfill().ffill())  
            else:
                if feat_type=="Lead":
                    df[new_col] = df.groupby(['key'],as_index = False)[colu].shift(-i)
                    df[new_col] = df.groupby(['key'],as_index = True,group_keys = False)[new_col]\
                                .apply(lambda x:x.ffill().bfill())    

        return df
    
    def calculate_moving_average(self, df, new_col, col, lag, wdw):
        """
        """
        df[new_col] = df.groupby(['key'],as_index = False,group_keys = False)[col].shift(1)\
                                .rolling(window=wdw, min_periods=1).mean()
        df[new_col] = df.groupby(['key'],as_index = True,group_keys = False)[new_col]\
                                .apply(lambda x:x.bfill().ffill())

        return df


    def create_mv_features(self, df, lower, upper, var, colu, window, feat_type):
        """
        """
        

        for wdw in window:
            wdw = int(wdw)
            if feat_type=="Moving_Average":
                new_col = str(var)+"_"+feat_type+'_W'+str(wdw)
                df = self.calculate_moving_average(df, 
                                                    new_col, 
                                                    col = colu, 
                                                    lag = 1, 
                                                    wdw = wdw)
                   
            if feat_type in ["Moving_Average_Lag","Moving_Average_Lead"]:
                for i in range(lower, upper + 1):
                    new_col = str(var)+"_"+feat_type+str('_'+str(i)+'_W'+str(wdw))
                    if feat_type=="Moving_Average_Lag":
                        lag = i
                    if feat_type=="Moving_Average_Lead": 
                        lag = -i
                    df = self.calculate_moving_average(df, 
                                                    new_col, 
                                                    col = colu, 
                                                    lag = lag, 
                                                    wdw = wdw)
        return df

    def create_transformed_features(self, df):
        """
        This function will create for derived features - Lags, Leads, Moving Averages at all the Granularity Specified 
        (for each combination) in the input template

        Arguments:

            DATA: pandas dataframe
            - dataframe which contains the features/column on which these transformation needs to be applied

        Return:

            DATA: pandas dataframe
            - updated dataframe which all the transformed features appended.
        """
        for var in set(self.Input_Transformation.index.levels[0]) & set(df.columns):
            if var==self.target_column:
                colu = f"{self.target_column}_transformed"
            else:
                colu = var

            try:
                for transformation in self.Input_Transformation.loc[var].index:
                    if self.Input_Transformation.loc[(var,transformation),'Flag'] == 1:
                        lower = int(self.Input_Transformation.loc[(var,transformation),'Lower_Limit'])
                        upper = int(self.Input_Transformation.loc[(var,transformation),'Upper_Limit'])
                        if pd.isnull(lower)==False:
                            lower = int(lower)
                        if pd.isnull(upper)==False:
                            upper = int(upper)
                        
                        window = self.Input_Transformation.loc[(var,transformation),'Window']
                        if pd.isnull(window)==False:
                            window = str(window)
                            window = window.split(",")
                            window = list(map(int, window))
                        else:
                            window = []
                        if transformation in ['Moving_Average','Moving_Average_Lag','Moving_Average_Lead']:
                            df = self.create_mv_features(df=df, 
                                                        lower=lower, 
                                                        upper=upper, 
                                                        var=var, 
                                                        colu=colu, 
                                                        window=window, 
                                                        feat_type=transformation) 
                        
                        if transformation in ['Lag','Lead']:
                            df = self.create_lag_n_lead_features(df=df, 
                                                                lower=lower, 
                                                                upper=upper, 
                                                                var=var, 
                                                                colu=colu, 
                                                                feat_type=transformation)

            except:
                print(f"Feature transformation failed of feature {var}.")
                print(var)
        return df


    def fit_trend_line(self, df, Key, cutoff, validation_period, val):
        """
        This function will fit the trend line on the given data
        
        Arguments:

            df: pandas dataframe
            - sales data (single dataframe)

            Key: string
            - define the key combination to filter df

            cutoff: datetime
            - defines the cutoff(train_till_date) 

            validation_period: list of datetime
            - defines the validation period

            val: string
            - defines the granularity name at which the trend line is being
            fitted.

        Return:

            data_key: pandas dataframe
            - dataframe at key x date col level containg the trend values
        """
        data_key = df[(df['key'] == Key)]
        data1 = data_key[(data_key[self.DATE_COL]<=cutoff)].index.values
        y1 = data_key[(data_key[self.DATE_COL]<=cutoff)][self.target_column]
        z1=  np.polyfit(data1, y1, 1)
        p1 = np.poly1d(z1)
        updated_data1 = np.concatenate([data1, np.arange(max(data1)+1, max(data1)+len(validation_period)+1)])
        col_name = val.replace(',','_')+'_trend'
        data_key.loc[data_key['key'] == Key, col_name] = p1(updated_data1)
        data_key.loc[data_key['key'] == Key, col_name]\
        = data_key.loc[data_key['key'] == Key,col_name].ffill().bfill()
        return data_key[['key',self.DATE_COL,col_name]]

    def calculate_trend(self, df, cutoff, validation_period):
        """
        This function will calculate the trend for all the combinations at all granularities specified 
        in input template

        Arguments:

            df: pandas dataframe
            - sales data (single dataframe)

            cutoff: datetime
            - defines the cutoff(train_till_date) 

            validation_period: list of datetime
            - defines the validation period

        Return:

            df: pandas dataframe
            - updated dataframe with trend features on different granularities

        """
        df['original_key'] = df['key']
        
        for idx,val in enumerate(pd.Series(self.Input_trend_seas.loc['trend_var'][self.trend_col]).values,1):
                LEVEL = val.split(',')
                df['key'] = df[LEVEL].astype(str).agg('_'.join, axis=1)
                data = df.copy()                              
                data = data.groupby(['key',self.DATE_COL],as_index=False).agg({self.target_column:sum})
                data = data.sort_values([self.DATE_COL],ascending=True)
                trend_argument_dict= {
                                        "cutoff":cutoff,
                                        "validation_period":validation_period,
                                        "val":val
                                    }
                trend_output_val = run_parallel_functions(func = self.fit_trend_line,
                                                        df=data,
                                                        argument_dict=trend_argument_dict, 
                                                        desc=f"Creating Trend at {val} level",
                                                        iter_col='key', 
                                                        is_iter_idx=False, 
                                                        is_df_arg=True
                                                        )
                trend_output_val_df = [res for res in trend_output_val]
                trend_output_val_df = concatenate_pandas_dataframe(data_list=trend_output_val_df)
                df = pd.merge(df, trend_output_val_df, on=['key',self.DATE_COL], 
                                how="left")
                df.drop('key',axis = 1,inplace = True)
        df['key'] = df['original_key']
        df.drop(['original_key'], axis=1, inplace=True)
        return df


    def calculate_seasonality(self, data, cutoff):
        """
        This function will calculate the seasonality of data(excluding covid months)
        on key level

        Arguments:

            data: pandas dataframe
            - sales data (single dataframe)

        Return:

            data: pandas dataframe
            -  updated dataframe with seasonality features on key level

        """
        data["month"] = data[self.DATE_COL].dt.month.astype(int)
        data_copy = data.copy()
        data_copy = data_copy[data_copy[self.DATE_COL]<=cutoff]

        if "covid_flag" in data.columns:
            data_copy = data_copy[data_copy["covid_flag"]==0]
           
        monthly_sales = data_copy.groupby(['key','month'],as_index = False).\
                        agg(Sum_Monthly_Sales = (self.target_column,'sum'))
        yearly_sales = data_copy.groupby(['key'],as_index = False).\
                        agg(Sum_Yearly_Sales = (self.target_column,'sum'))

        monthly_sales = pd.merge(monthly_sales, yearly_sales, on=['key'], how="left")
        monthly_sales['seasonality'] = monthly_sales['Sum_Monthly_Sales']/monthly_sales['Sum_Yearly_Sales']
        monthly_sales['key'] = monthly_sales['key'].astype(data['key'].dtype)
        monthly_sales['month'] = monthly_sales['month'].astype(int)

        data = pd.merge(data, monthly_sales[['key','month','seasonality']],
                how = 'left',
                on = ['key','month'])
        data['seasonality'].fillna(0, inplace=True)
        data.drop(['month'], axis=1,inplace=True)
        return data
    

    # def encode_categorical_columns(self, data, brand_col):
    #     """
    #     This function will binary encode all the categorical variables

    #     Arguments:

    #         data: pandas dataframe
    #         - sales data (single dataframe)

    #         DATE_COL: str
    #         - contains the name of date column

    #         brand_col: str
    #         - contains the name of brand column

    #     Return:

    #         data: pandas dataframe 
    #         - updated dataframe in which all the categorical variables have been binary
    #         encoded
            
    #         encoder_dict: dict
    #         - dictionary which contains the all the mapping of encoded columns(original to binary encoded)
    #         in order to reverse the process.

    #     """
    #     encoder_dict = {}
    #     for col in data.columns:
    #         if (data[col].dtype == "object") & (col != self.DATE_COL) & (col != 'key') & (col!=brand_col):
    #                 print(col)
    #                 encoder = BinaryEncoder(cols = [col])
    #                 encoded_df = encoder.fit_transform(data[col])
    #                 data = pd.concat([data, encoded_df], axis = 1)
    #                 data = data.drop(col,axis = 1)
    #                 encoder_dict[encoder] = encoded_df
    #     return data, encoder_dict

    def convert_months_into_columns(self, data):
        """
        This function will convert month mentioned in month column to 
        individual columns like January, February, March, etc.

        Arguments:

            data: pandas dataframe
            - sales data (single dataframe)

        Return:

            data: pandas dataframe
            - updated dataframe which contains month as individual columns

        """
        if "month" in data.columns:
                pass
        else:
            data['month'] = data[self.DATE_COL].dt.month

        di_months = dict(zip(sorted(data["month"].unique()),calendar.month_name[1:]))
        for idx,mon in di_months.items():
            data[mon] = np.where(data["month"] == idx,1,0)
        data.drop(['month'], axis=1, inplace=True)
        return data

    def replace_target_column_sales(self, df_validation, cutoff, validation_period):
        """
        This function will replace the target column sales(only for validation period) 
        for creating lags and leads.
        Also it will forecast the column for which future data is not available.

        Arguments:

                df_validation: pandas dataframe
                - The dataframe on which all the operations to be performed

                cutoff: datetime
                - cutoff date for the dataframe passed
                
                validation_period: list of datetime value
                - defines the validation period
            
        Return: 

                df_validation: pandas dataframe
                - df_validation with target sales replaced by forecasted value(only for validation period)
        """
        df_validation_cts = df_validation[['key', self.DATE_COL, self.target_column]]
        replacing_valid_months_sales_dict = {
                                            "cutoff":cutoff,
                                            "validation_period":validation_period,
                                            "model_type":None}
        outputs = []

        for i in tqdm(range(0,df_validation_cts.key.nunique(),self.no_of_keys_to_process)):
            keys = df_validation_cts.key.unique()[i:i+self.no_of_keys_to_process]
            df_validation_batch = df_validation_cts[df_validation_cts['key'].isin(keys)]
            replacing_valid_months_sales_output = run_parallel_functions(func = self.replacing_valid_months_sales, 
                                                                        df=df_validation_batch, 
                                                                        argument_dict=replacing_valid_months_sales_dict, 
                                                                        desc="Replacing target column with forecast value to create lags",
                                                                        iter_col='key', 
                                                                        is_iter_idx=False, 
                                                                        is_df_arg=True)                                  
            valid = [res for res in replacing_valid_months_sales_output]
            outputs.extend(valid)
            
        valid_df = concatenate_pandas_dataframe(data_list=outputs)
        valid_df[f"{self.target_column}_transformed"] = valid_df["pred"]
        df_validation = pd.merge(df_validation,valid_df[["key",self.DATE_COL,f"{self.target_column}_transformed"]],
                                how="left", left_on = ["key",self.DATE_COL],
                                right_on=["key",self.DATE_COL])
        df_validation[f"{self.target_column}_transformed"].fillna(df_validation[self.target_column],inplace=True)
        #forecasting the column for validation period if mentioned in input template data
        if len(self.cols_to_pred)>0:
            for col,model_type in self.cols_to_pred.items():
                if col in df_validation.columns:
                    df_validation_cts = df_validation[['key', self.DATE_COL, col]]


                    predicting_valid_months_col_dict = {
                                            "cutoff":cutoff,
                                            "validation_period":validation_period,
                                            "model_type":model_type}
                    predicting_valid_months_col_output = run_parallel_functions(func = self.replacing_valid_months_sales, 
                                                                                df=df_validation_cts, 
                                                                                argument_dict=predicting_valid_months_col_dict, 
                                                                                desc=f"Predicting {col} with forecast value to create lags",
                                                                                iter_col='key', 
                                                                                is_iter_idx=False, 
                                                                                is_df_arg=True)    

                    valid = [res for res in predicting_valid_months_col_output]
                    valid_df = concatenate_pandas_dataframe(data_list=valid)
                    valid_df[f"{col}_transformed"] = valid_df["pred"]
                    df_validation = pd.merge(df_validation,valid_df[["key",self.DATE_COL,f"{col}_transformed"]],
                                            how="left", left_on = ["key",self.DATE_COL],
                                            right_on=["key",self.DATE_COL])
                    df_validation[f"{col}_transformed"].fillna(df_validation[col],inplace=True)
                    df_validation.loc[:,col] = df_validation[f"{col}_transformed"]
                    df_validation.drop([f"{col}_transformed"],axis=1,inplace=True)
        df_validation = df_validation.reset_index(drop=True)
        df_validation = df_validation.sort_values(['key',self.DATE_COL], ascending=True)
        return df_validation

    def run(self, df_validation, cutoff, validation_period):
            """
            This function creates all the features required for ml modelling and remove the unnecessary ones.
            Main function to execute all the functions mentioned above.

            Arguments:

                df_validation: pandas dataframe
                - The dataframe on which all the operations to be performed

                cutoff: datetime
                - cutoff date for the dataframe passed
                
                validation_period: list of datetime value
                - defines the validation period
            
            Return: 
                    df_validation: pandas dataframe
                    - df_validation along with all the required features

            """

            #replacing validation tar
            # get column value with cts forecasted value
            df_validation = self.replace_target_column_sales(df_validation, cutoff, validation_period)
            #creating lead, lags & MA for the features mentioned in input templates

            df_validation = self.create_transformed_features(df_validation)
            df_validation.drop([f"{self.target_column}_transformed"],axis=1,inplace=True)
            ##adding trend on different cuts mentioned in input templates    
            df_validation = self.calculate_trend(df_validation, cutoff, validation_period)
            #adding and seasonality value on key level mentioned in input templates
            df_validation = self.calculate_seasonality(df_validation, cutoff)
            #dropping the inessential columns
            df_validation.drop(self.hierarchy_features,axis=1,inplace=True)
            df_validation.drop(['brand_code'], axis=1, inplace=True)
            #converting month mentioned in month column to individual columns like January, February, March, etc.
            df_validation = self.convert_months_into_columns(df_validation)
            #adding recency factor based on the type mentioned in input template
            if self.di_model_input['Model_Weights'] == 1:

                if self.Input_model_vars.loc[('Model_Recency_Factor','Model_Weights'),'Model_Selected'] == np.nan:
                    weights = self.Input_model_vars.loc[('Model_Recency_Factor','Model_Weights'),'Default_Choice'].split(',')
                else:
                    weights = self.Input_model_vars.loc[('Model_Recency_Factor','Model_Weights'),'Model_Selected'].split(',')

                df_validation = self.add_recency_factor_obj.run(_type=weights[0], df=df_validation)
            df_validation = df_validation.fillna(0)
            return df_validation