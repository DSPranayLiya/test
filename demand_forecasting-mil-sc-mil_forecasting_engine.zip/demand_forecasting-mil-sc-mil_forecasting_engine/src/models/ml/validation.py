"""
Author: Aishwarya Verma
Version: 0.0.1
Description: This file contains all the function to generate ml validation results.
"""

from ...helper import os, np, pd, scope, hp, XGBRegressor, LGBMRegressor, RandomForestRegressor, \
    STATUS_OK, Trials, fmin, partial, tpe, LinearRegression, Lasso, Ridge, ElasticNet, BayesianRidge, MLPRegressor, \
         patsy,  traceback, pickle #pm, GLM, 
from ...helper import concatenate_pandas_dataframe, record_model_runtime
from ...helper import GetMlPipelineInput

class MlValidationClass(GetMlPipelineInput):
    """
    This class will generate the ml validation results for 
    alls the ml models mentioned in input template
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        self.path = input_dict["ml_valid_dir"]

    def search_space(self):
        """
        This function contains all the search spaces for all the ml models required for hyperparameters 
        optimization by hyperopt 

        Arguments:

            None

        Return:

            hyperparameter_spaces_dict: dict
            - contains the paramters search space all ml models
        """
        hyperparameter_spaces_dict = {}
        space_xgb = {
                'n_estimators': hp.choice('n_estimators', range(10, 20)),           # Number of boosting rounds
                'max_depth':  scope.int(hp.quniform('max_depth', 3, 15, 1)),                      # Maximum tree depth
                'learning_rate': hp.loguniform('learning_rate', 0, 0.001),               # Learning rate
                'subsample': hp.uniform('subsample', 0.5, 0.8),                         # Subsample ratio of the training instance
                'colsample_bytree': hp.uniform('colsample_bytree', 0.5, 0.8),           # Subsample ratio of columns when constructing each tree
                'gamma': hp.loguniform('gamma', -5, 5),                               # Minimum loss reduction required to make a further partition on a leaf node
                'min_child_weight': hp.quniform('min_child_weight', 1, 10, 1),        # Minimum sum of instance weight (hessian) needed in a child
                'reg_alpha': hp.loguniform('reg_alpha', -5, 1),                       # L1 regularization term on weights
                'reg_lambda': hp.loguniform('reg_lambda', -5, 1)                       # L2 regularization term on weights
                }

        space_lgbm = {
                    'boosting_type': hp.choice('boosting_type', ['gbdt', 'dart', 'goss']),  # Gradient Boosting Decision Tree or Dropouts Meet Multiple Additive Regression Trees
                    'objective':'regression',
                    'metrics':'rmse',
                    'num_leaves': scope.int(hp.quniform('num_leaves', 10, 50, 1)),  # Number of leaves in one tree
                    'learning_rate': hp.loguniform('learning_rate', 0, 0.01),  # Learning rate (log scale)
                    'max_depth':scope.int( hp.quniform('max_depth', 2, 6, 1)),  # Maximum depth of a tree
                    'min_child_samples': hp.quniform('min_child_samples', 5, 10, 1),  # Minimum number of data in one leaf
                    'subsample': hp.uniform('subsample', 0.5, 0.8),  # Subsample ratio of training data
                    'colsample_bytree': hp.uniform('colsample_bytree', 0.6, 0.8),  # Subsample ratio of columns when constructing each tree
                    'reg_alpha': hp.loguniform('reg_alpha', -5, 0),  # L1 regularization term on weights
                    'reg_lambda': hp.loguniform('reg_lambda', -5, 0),  # L2 regularization term on weights
                    'min_data_in_leaf': scope.int(hp.quniform('min_data_in_leaf', 1, 5, 1)),  # Minimal number of data in one leaf
                    'n_estimators': scope.int(hp.quniform('n_estimators',10, 50, 1)),  # Number of boosting rounds
                    # 'early_stopping_rounds': scope.int(hp.quniform('early_stopping_rounds', 5, 20, 1))  # Early stopping rounds if using early_stopping

                }

        space_rf = {'n_estimators':hp.choice('n_estimators',np.arange(10,220,20)),
                    'max_depth':hp.choice('max_depth',np.arange(2,20,2)),
                    'n_jobs':hp.choice('n_jobs',[-4]),
                    'max_features':hp.choice('max_features',['sqrt',None])
        }
        space_lr = {}
        space_lasso = {'alpha':hp.choice('alpha', [1e-15, 1e-10, 1e-8, 1e-4, 1e-3,1e-2, 1, 5, 10, 20, 50, 100])}
        space_ridge = {'alpha':hp.choice('alpha', [1e-15, 1e-10, 1e-8, 1e-4, 1e-3,1e-2, 1, 5, 10, 20, 50, 100])}
        space_elasticnet = {'alpha':hp.choice('alpha', [1e-15, 1e-10, 1e-8, 1e-4, 1e-3,1e-2, 1, 5, 10, 20, 50, 100])}
        space_bayesian_ridge = {}
        bayesian_lr = {}
        mlp_2layer = {}
        hyperparameter_spaces_dict = {
                            "LinearRegression":space_lr,
                            "Lasso":space_lasso,
                            "Ridge":space_ridge,
                            "ElasticNet":space_elasticnet,
                            "BayesianRidge":space_bayesian_ridge,
                            "XGBoost":space_xgb,
                            "RandomForest":space_rf,
                            "LightGBM":space_lgbm,
                            "BayesianLinearRegression":bayesian_lr,
                            "MLP_2layer":mlp_2layer,
                        }
        return hyperparameter_spaces_dict


    def run_bayesian_linear_regression(self, train, test):
        """
        """
        pass
        # features = train.columns.tolist()
        # features = list(set(features) - set(self.to_drop))
        # formula = f'{self.target_column} ~ ' + ' + '.join(['%s' % variable for variable in features])

        # to_drop_copy = self.to_drop.copy()
        # to_drop_copy.remove(self.target_column)

        # y, x = patsy.dmatrices(formula_like=formula, data=train.drop(to_drop_copy,axis=1))
        # y = np.asarray(y).flatten()
        # labels = x.design_info.column_names
        # x = np.asarray(x)


        # with pm.Model() as model:
        #     # Set data container.
        #     data = pm.Data("data", x)
        #     # Define GLM family.
        #     # Set priors.
        #     # Specify model.
        #     family = pm.glm.families.Normal()

        #     GLM(y=y, x=data,intercept=False, family=family,labels=labels)
        #     # Configure sampler.
        #     trace = pm.sample()

        #     ppc_test = pm.sample_posterior_predictive(trace, model=model, samples=1000)
        #     train_pred = ppc_test["y"].mean(axis=0)

        #     # Update data reference.
        #     pm.set_data({"data": test.drop(self.to_drop,axis=1)}, model=model)
        #     # Generate posterior samples.
        #     ppc_test = pm.sample_posterior_predictive(trace, model=model, samples=1000)
        #     pred = ppc_test["y"].mean(axis=0)

            # return train_pred, pred

    def get_results_in_dict(self, cv_error_train, cv_r2_score_train, cv_error_valid,
                            cv_wape_valid, cv_validation_bias):
        """
        This function will put all the metrics in a dictionary format:

        Arguments:

            cv_error_train: list
            - contains training errors(wape)

            cv_r2_score_train: list
            - contains training r2 scores

            cv_error_valid: list
            - contains validation errors(rmse)

            cv_wape_valid: list
            - contains validation wape

            cv_validation_bias: list
            - contains the validation bias dataframe
        
        Return:

            metrics_dict: dict
            - contains all the mean of erros and validation bias list
        """

        metrics_dict = {
                        'train':
                                {
                                    'rmse':np.mean(cv_error_train),
                                    'r2':np.mean(cv_r2_score_train)
                                },
                        
                        'valid':
                                {
                                    'rmse':np.mean(cv_error_valid),
                                    'wape':np.mean(cv_wape_valid),
                                    'validation_bias':cv_validation_bias
                                }
                        }
        return metrics_dict

    def rolling_cross_validation_ml(self, validation_data, model, model_type):
            """
            This function will generate the validation results for all the validation sets
            for a key.

            Arguments:

                validation_data: list of dataframe
                - contains the list of all dataframe for cross validation

                model: dict
                - contains the parameters for the specified model

                model_type: string
                - defines the type of ml model to run

            Return:

                results: dict
                - contains all the validation results like, train accuracy, validation biases,
                validation accuracies & validation data sets

            """
            cv_r2_score_train_volume,cv_error_train_volume,cv_error_valid_volume = [],[],[]
            cv_wape_valid_volume,cv_validation_bias_volume = [],[]
            cv_error_train_value,cv_r2_score_train_value,cv_error_valid_value = [],[],[]
            cv_wape_valid_value,cv_validation_bias_value = [],[]
            validation_data_list = []
            results = {}
            #looping over cv periods
            for i in range(0,len(self.cv_periods)):
                cvm = self.cv_periods[i]
                cutoff = self.cutoffs_periods[i]
                df_validation = validation_data[i]
                Key = df_validation['key'].values[0]
                if self.features_to_take.empty==True:
                    features_to_take_key = None
                else:
                    features_to_take_key = self.features_to_take[self.features_to_take['key']==Key]['k_best_features_name'].values.tolist()[0]
                    df_validation = df_validation[['key',self.DATE_COL,self.target_column]+features_to_take_key]
                
                train_split = df_validation[df_validation[self.DATE_COL]<=cutoff]
                valid_split = df_validation[df_validation[self.DATE_COL].isin(cvm)]

                if model_type in ['lr','lasso','ridge','elasticnet','bayesian_ridge','xgb','rf','lgbm', 'mlp_2layer']:
                    #fitting the model
                    model.fit(train_split.drop(self.to_drop,axis=1),train_split[self.target_column])
                    #prediction for train data
                    train_pred = model.predict(train_split.drop(self.to_drop,axis = 1))
                    #prediction for valid data
                    valid_pred = model.predict(valid_split.drop(self.to_drop,axis = 1))
                
                if model_type in ['bayesian_lr']:
                    train_pred, valid_pred = self.run_bayesian_linear_regression(train=train_split,test=valid_split)
                #metrics
                metrics = self.calculate_forecasting_metrics(train=train_split, train_pred=train_pred, 
                                                    valid=valid_split,   valid_pred=valid_pred, 
                                                    original_df=self.original_df,vb_value=True)
            
                train_split['pred'] = train_pred
                train_split['Data_Type'] = "Training"
                valid_split['pred'] = valid_pred
                valid_split['Data_Type'] = "Validation"
                
                validation_data_to_append = concatenate_pandas_dataframe(data_list=[train_split,valid_split])
                validation_data_to_append['cutoff'] = cutoff
                validation_data_list.append(validation_data_to_append)
                vol_metrics = self.get_metric_values(metric=metrics, idx=i, if_vol=True)
                
                cv_error_train_volume.append(vol_metrics[0])
                cv_r2_score_train_volume.append(vol_metrics[1])                
                cv_error_valid_volume.append(vol_metrics[2])
                cv_wape_valid_volume.append(vol_metrics[3])
                cv_validation_bias_volume.append(vol_metrics[4])
                
                if self.index_rate.empty==False:
                    val_metrics = self.get_metric_values(metric=metrics, idx=i, if_vol=False)
                    cv_error_train_value.append(val_metrics[0])
                    cv_r2_score_train_value.append(val_metrics[1])
                    cv_error_valid_value.append(val_metrics[2])
                    cv_wape_valid_value.append(val_metrics[3])
                    cv_validation_bias_value.append(val_metrics[4])

            validation_data_list = pd.concat(validation_data_list)

            results['vol'] = self.get_results_in_dict(cv_error_train=cv_error_train_volume, cv_r2_score_train=cv_r2_score_train_volume, 
                            cv_error_valid=cv_error_valid_volume, cv_wape_valid=cv_wape_valid_volume, cv_validation_bias=cv_validation_bias_volume)
            results['data'] = validation_data_list

            if self.index_rate.empty==False:
                results['val'] = self.get_results_in_dict(cv_error_train=cv_error_train_value, cv_r2_score_train=cv_r2_score_train_value, 
                            cv_error_valid=cv_error_valid_value, cv_wape_valid=cv_wape_valid_value, cv_validation_bias=cv_validation_bias_value)
            return results

    def hyperparameter_tuning(self, space, data):
        """
        This function will do the hyperparamter optimization for different models(random forest,
        xgboost, lightgbm) for a key

        Arguments:

            space: dict
            - contains the paramters search space for specified model

            data: dict
            - contains all the data like  list of cross valdiation dataframe, bpm dataframe, name of the date column,
            name of the target column, cutoff periods, validation periods, original dataframe, list of to drop column 
            while training the data

        Return:

            final_results: dict
            - contains all the validation results like loss, models parameteres, train accuracy, validation biases,
            validation accuracies.
        """
        if data['model_type']=="xgb":
            model = XGBRegressor(**space)
        elif data['model_type']=="rf":
            model = RandomForestRegressor(**space)
        elif data['model_type']=="lgbm":
                model = LGBMRegressor(**space)
        elif data['model_type']=="lr":
            model = LinearRegression()
        elif data['model_type']=="lasso":
            model = Lasso(**space)
        elif data['model_type']=="ridge":
            model = Ridge(**space)
        elif data['model_type']=="elasticnet":
                model = ElasticNet(**space)
        elif data['model_type']=="bayesian_ridge":
                model = BayesianRidge()
        else:
             
            if data['model_type']=="mlp_2layer":
                model = MLPRegressor(hidden_layer_sizes=(100,100), max_iter=300)
        model_type = data['model_type']
        validation_data = data["data"]
        results =  self.rolling_cross_validation_ml(validation_data=validation_data,
                                                    model=model,
                                                    model_type=model_type)
        loss = {'loss':results['vol']['valid']['rmse'],
            'model':model,
            'status': STATUS_OK}
        final_results = {**loss, **results}
        return final_results


    @record_model_runtime( function_name= 'ml_model_validation')
    def run_validation_model(self, hyperparameter_tuning_func, space, max_evals, validation_data, Key, suffix):
        """
        This function will trigger the ml validation modelling process by passing required parameters to the 
        corresponding functions for a key

        Arguments:

            hyperparameter_tuning_func: function
            - This function will do the hyperparameter optimization for different models(random forest,
            xgboost, lightgbm)

            space: dict
            - search space for hyperparamters of the model

            max_evals:  int
            - maximum iteration for the cross validation to run

            validation_data: list of dataframe 
            - list of dataframe that contains all the validation dataframe

            Key: str
            - contains the Key for which validation results needs to be calculated

            suffix: str
            - contains the model type

        Return:

            reg_model: dict
            - contains the hyperparameters of the best model for a key

            model_summary: pandas dataframe
            - contains the validation accuracy, bias for a key

            validation_data_list: list of dataframe
            - contains the list of dataframes of validation sets(training+validation) 
            along with predictions
        """
        trials = Trials()
        data = {'data':validation_data,
                'model_type':suffix,
            }
        if suffix in ['lr','bayesian_ridge','mlp_2layer']:
            min_error_model = hyperparameter_tuning_func(space, data)
        else:  
            best = fmin(partial(hyperparameter_tuning_func,data=data),
                                space = space,
                                algo = tpe.suggest,
                                max_evals = max_evals,
                                trials = trials,
                                show_progressbar=False)
            min_error_model = trials.results[np.argmin([r['loss'] for r in trials.results])]
        reg_model = min_error_model['model']

        train_error_volume = min_error_model['vol']["train"]["rmse"]
        train_acc_volume = 100-train_error_volume
        r2_score_train_volume = min_error_model['vol']["train"]["r2"]
        valid_error_volume = min_error_model['vol']["valid"]["rmse"]
        valid_wape_acc_volume = 100-min_error_model['vol']["valid"]["wape"]
        
        validation_data_list = min_error_model['data']

        validation_bias_volume = min_error_model["vol"]["valid"]['validation_bias']
        validation_bias_volume = concatenate_pandas_dataframe(data_list=validation_bias_volume, axis=1,
                                ignore_index=False)
        validation_bias_volume["CV_Train_Acc_Volume"] = train_acc_volume
        validation_bias_volume["CV_Train_R2_Volume"] = r2_score_train_volume
        validation_bias_volume["CV_RMSE_Volume"] = valid_error_volume
        validation_bias_volume["CV_WAPE_Volume"] = valid_wape_acc_volume
        
        if self.index_rate.empty==False:
            train_error_value = min_error_model['val']["train"]["rmse"]
            train_acc_value = 100-train_error_value
            r2_score_train_value = min_error_model['val']['train']['r2']
            valid_error_value = min_error_model['val']["valid"]["rmse"]
            valid_wape_acc_value = 100-min_error_model['val']["valid"]["wape"]
            validation_bias_value = min_error_model["val"]["valid"]['validation_bias']
            validation_bias_value = concatenate_pandas_dataframe(data_list=validation_bias_value, axis=1,
                                    ignore_index=False)        
            validation_bias_value["CV_Train_Acc_Value"]= train_acc_value
            validation_bias_value["CV_Train_R2_Value"] = r2_score_train_value
            validation_bias_value["CV_RMSE_Value"] = valid_error_value
            validation_bias_value["CV_WAPE_Value"] = valid_wape_acc_value
        else:
            validation_bias_value = pd.DataFrame()

        model_summary = concatenate_pandas_dataframe(data_list=[validation_bias_volume,validation_bias_value],
                                                        axis=1,
                                                        ignore_index=False)
        model_summary['key'] = Key        
        return reg_model, model_summary, validation_data_list


    def run(self, df_validation, Key):
        """
        This function will calculate the validation results for all the ml models of a key

        Arguments:

            df_validation: 
            -list of dataframe that contains all the validation dataframe

            Key:str
            - contains the Key for which validation results needs to be calculated

        Return:

            model_summary_final: pandas dataframe
            - contains the cross validation summary for all ml models for a key

            ml_models_list: list
            - contains the best parameters of all ml models for a key

            validation_data_final: pandas dataframe
            - contains the training + validation data along with predictions for all validation sets
            for a key
        """
        try:
            #print(Key)    
            validation_data = []
            for idx in range(len(df_validation)):
                val = df_validation[idx][df_validation[idx]['key']==Key]
                validation_data.append(val)
            model_summary_final, validation_data_final = [],[]
            models, ml_models_list = {}, {}
            hyperparameter_spaces_dict = self.search_space()
            if self.di_model_input['ML_Modeling'] == 1:
                if self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Model_Selected'] == np.nan:
                    model_list = self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Default_Choice'].split(',')
                else:
                    model_list = self.Input_model_vars.loc[('Model_Choice','ML_Modeling'),'Model_Selected'].split(',')

            for ml_model_type in model_list:
                    suffix = self.suffix_dict[ml_model_type]
                    space = hyperparameter_spaces_dict[ml_model_type]
                    max_evals = 30
                    best_model, model_summary, validation_data_list = self.run_validation_model(hyperparameter_tuning_func=self.hyperparameter_tuning,
                                                        space=space,
                                                        max_evals=max_evals,
                                                        validation_data=validation_data,
                                                        Key=Key,
                                                        suffix = suffix)
                    model_summary.loc[:,'Model_Type'] = suffix
                    validation_data_list.loc[:,'Model_Type'] = suffix

                    model_summary_final.append(model_summary)    
                    validation_data_final.append(validation_data_list)
                    models[suffix] = best_model

            model_summary_final = concatenate_pandas_dataframe(data_list=model_summary_final)
            validation_data_final = concatenate_pandas_dataframe(data_list=validation_data_final)
            ml_models_list[Key] = models
            return model_summary_final, ml_models_list, validation_data_final
        except Exception as e:
            err  = str(traceback.format_exc())
            with open(f"{self.path}/{Key}_ml_valid_errors.txt", 'w+') as f:
                    f.write(str(err))