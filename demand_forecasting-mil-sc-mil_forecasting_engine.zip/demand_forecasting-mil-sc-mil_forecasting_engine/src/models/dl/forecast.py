"""
Author: Pranjal Soni
Version: 0.0.1
Description: This file perform forecasting for deep learning model on train and test data.
"""

from ...helper import pd, np, os, read_pickle_file, torch, warnings, traceback, Path
from .validation import DlValidationClass

class DlForecastClass(DlValidationClass):
    """
        This class perform the forecasting for the deep
        learning model ( currently only LSTM model is used.)
    """
    def __init__(self, input_dict) -> None:
        super().__init__(input_dict=input_dict)
        self.path = os.path.join(self.location_to_save, "dl_model_results")

    def get_model_pred( self, model, dataloader, target_sc_obj):
        """
            This function perform generate the results on the
            dataloader object.

            model: pytorch dl model object
            - dl trained model to predict forecast 

            dataloader: pytorch dataloader object
            - loads the batch_wise data for the prediction output

            target_sc_obj: sklearn standard scaler object 
            - this helps in inverse transformation of the predicted values
        """
        # forecasting on training data
        forecast_result = []
        model.eval()
        with torch.no_grad():
            for inputs, targets in dataloader:
                if self.model_type != 'UNIVARIATE':
                    inputs = inputs.unsqueeze(1)
                    targets = targets.unsqueeze(1)
                outputs = model(inputs)
                forecast_result.extend( target_sc_obj.inverse_transform(outputs))
        return forecast_result 

    def univariate_result_forecast(self, train_data, model, train_dl,  target_sc_obj):
        """
            This function perform the forecasting activity for the multivariate 
            deep learning model forecasting.

            Args:
                model: pytorch dl model object
                - dl trained model to predict forecast 

                train_data: list
                - list containing data points for the training period

                train_dl: pytorch dataloader object
                - loads the batch_wise train data for the prediction output

                target_sc_obj: sklearn standard scaler object 
                - this helps in inverse transformation of the predicted values
            Return:

                train_forecast: list
                - the contains the forecast for the training data period

                test_forecast: list
                - list of test period forecast predictions
        """
        train_forecast, test_forecast = [], []
        train_forecast = self.get_model_pred( train_dl, target_sc_obj)
        # forecasting on test period
        test_data = train_data[-self.lookback :]
        test_forecast = self.univariate_model_pred(
            model, test_data, len(self.actual_forecast_period)
        )
        train_forecast = [val[0] for val in train_forecast]
        test_forecast = list( target_sc_obj.inverse_transform( np.array(test_forecast).reshape(-1,1)).reshape(1,-1)[0])
        return train_forecast, test_forecast

    def multivariate_result_forecast(self, model, train_dl, test_dl, target_sc_obj):
        """
            This function perform the forecasting for the multivariate
            deep learning model forecasting.

            Args:
                model: pytorch dl model object
                - dl trained model to predict forecast 

                train_dl: pytorch dataloader 
                - dataloader object to load the training data

                test_dl: pytorch dataloader 
                - dataloader object to load the test data

                target_sc_obj: sklearn standard scaler object
                - standard scaler object to inverse transform prediction data

            Return:
                train_forecast: list
                - the contains the forecast for the training data period

                test_forecast: list
                - list of test period forecast predictions
        """
        # forecasting on training data
        print(" Training Period Forecast:....")
        train_forecast = self.get_model_pred( model, train_dl, target_sc_obj)
        train_forecast = [val[0] for val in train_forecast]
        print(" Test Period Forecast:....")
        test_forecast = self.get_model_pred( model, test_dl, target_sc_obj)
        test_forecast = [val[0] for val in test_forecast]
        return train_forecast, test_forecast

    
    def run(self, df, Key=False):
        """
            This function perform forecasting and return the pandas 
            dataframe containing the forecast and actual values.
        """

        try:
            df = df[df["key"] == Key]
            df[self.DATE_COL] = pd.to_datetime(df[self.DATE_COL])
            
            model = read_pickle_file( os.path.join( self.path, f'{Key}_dl_model.pkl'))
            train_data = read_pickle_file( os.path.join( self.path, f'{Key}_dl_model.pkl'))
            train_dl = read_pickle_file( os.path.join( self.path, f'{Key}_train_dataloader.pkl'))
            test_dl = read_pickle_file( os.path.join( self.path, f'{Key}_test_dataloader.pkl'))
            target_sc_obj = read_pickle_file( os.path.join( self.path, f'{Key}_scaler_objs.pkl'))[1]

            print(" Generating Forecasting Results...")
            if self.model_type == "UNIVARIATE":

                train_forecast, test_forecast = self.univariate_result_forecast(train_data, model, train_dl,  target_sc_obj)

                train_data, test_data, forecast_date_range = (
                    df[df[self.DATE_COL]<= self.di_model_input['train_till_date']][self.target_column][self.lookback:].tolist(),
                    df[df[self.DATE_COL].isin(self.actual_forecast_period)][ self.target_column].tolist(),
                    pd.date_range(start=min(df[self.DATE_COL]), end=max(self.actual_forecast_period), freq="D")[self.lookback :]
                )
            else:
                train_forecast, test_forecast = self.multivariate_result_forecast( model,train_dl, test_dl, target_sc_obj)
                train_data = df[df[self.DATE_COL]<= self.di_model_input['train_till_date']][self.target_column].tolist()
                test_data = df[df[self.DATE_COL].isin(self.actual_forecast_period)][ self.target_column ].tolist()
                forecast_date_range = df[ self.DATE_COL].tolist()

            forecast_data = pd.DataFrame(
                {
                    "month_date": forecast_date_range,
                    "actual_val": train_data + test_data,
                    "forecast_val": train_forecast + test_forecast,
                }
            )

            forecast_data['key'] = Key
            return [forecast_data]
        except:
            error_path = os.path.join(self.path, "dl_forecast_errors")
            Path(error_path).mkdir(parents=True, exist_ok=True)
            warnings.warn(f" Deep learning model forecast task has failed for {Key} \n Please check \
                            the error in folder {error_path}")
            with open( os.path.join(error_path, f"{Key}_dl_model_forecast_error.txt"), 'w+') as file:
                file.write( str(traceback.format_exc()))
            pass
        
