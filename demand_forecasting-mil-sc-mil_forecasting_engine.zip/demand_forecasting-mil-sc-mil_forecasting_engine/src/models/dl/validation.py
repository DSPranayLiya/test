"""
Author: Pranjal Soni
Version: 0.0.1
Description: This file perform the cross validation, and train the deep learning model.
"""

from ...helper import GetGeneralPipelineInput
from ...helper import pd, np, os, pickle, Path, datetime, StandardScaler, DataLoader, \
    torch, optuna, nn, warnings, traceback
from .dataloader import UniVariateTimeSeriesDataset, MultiVariateTimeSeriesDataset
from .model import LSTMModel
from ...models import GetMlFeatureTransformationsClass

class DlValidationClass(GetGeneralPipelineInput):
    """
    This class will generate the dl validation results for
    deep learning ( currently only LSTM implemented)
    """

    def __init__(self, input_dict):
        """ 
        """
        super().__init__(input_dict=input_dict)
        self.input_dict = input_dict
        self.dl_model_inputs = input_dict["dl_model_params"]
        self.model_type = self.dl_model_inputs["model_type"]["value"]
        self.lookback = self.dl_model_inputs["look_back"]["value"]
        self.batch_size = self.dl_model_inputs["batch_size"]["value"]
        self.horizon = self.dl_model_inputs["Horizon"]["value"]
        self.hyperparameter_tuning = self.dl_model_inputs["Hyperparameter_Tuning"][
            "value"
        ]
        self.num_trails = self.dl_model_inputs['num_trails']['value']
        self.ml_transformation_class = GetMlFeatureTransformationsClass(input_dict=input_dict)

    def standard_scaling(self, train_data, val_data):
        """
            This function perform the standard scaling on the train_data
            and validation data.

            Args:
                train_data:  pd.DataFrame
                - pandas dataframe contains the training data

                valid_data: pd.DataFrame
                - pandas dataframe contains validation object

            Return:
                train_data:
                - if model type in univariate then train data will be 
                  transformed object of train data otherwise a list 
                  contains transformed feature and target variable of 
                  train data

                val_data:
                - if model type in univariate then train data will be 
                  transformed object of train data otherwise a list 
                  contains transformed feature and target variable of 
                  validation data

                sc_objects: list
                - list containing sklearn standard scaling object for 
                    train and test data
        """
        train_target = train_data[self.target_column].values
        val_target = val_data[self.target_column].values

        train_data = train_data.drop([self.DATE_COL, self.target_column], axis=1)
        val_data = val_data.drop([self.DATE_COL, self.target_column], axis=1)

        feature_sc = StandardScaler()
        target_sc = StandardScaler()

        # train_data = feature_sc.fit_transform( train_data)
        # val_data = feature_sc.transform( val_data)

        train_target = target_sc.fit_transform(train_target.reshape(-1, 1))
        val_target = target_sc.transform(val_target.reshape(-1, 1))

        sc_objects = [feature_sc, target_sc]

        if self.model_type != "UNIVARIATE":
            train_data = [train_data.values, train_target]
            val_data = [val_data.values, val_target]
        else:
            train_data = train_target
            val_data = val_target

        return train_data, val_data, sc_objects

    def prepare_lstm_cv_data(self, df):
        """
        Create the validation data for the model training

        Arg:
            df: pandas dataframe
            - dataframe contains the master data with all the demand drivers

        Return:
            train_val_set: dictionary
            - dictionary of the cross validation datasets
        """
        df_validation = []
        for idx in range(len(self.cutoffs_periods)):
            print(f"Corss Validation DF  Set: {idx}")
            df_validation_subset = df[
                df[self.DATE_COL] <= max(self.cv_periods[idx])
            ].copy()

            if self.model_type != "UNIVARIATE":
                df_validation_subset = self.ml_transformation_class.run(
                    df_validation=df_validation_subset,
                    cutoff=self.cutoffs_periods[idx],
                    validation_period=self.cv_periods[idx],
                )
            df_validation.append(df_validation_subset)

        train_val_set = {}

        for idx, cutoff in enumerate(self.cutoffs_periods):
            train_data = df_validation[idx][df_validation[idx][self.DATE_COL] < cutoff]
            val_data = df_validation[idx][df_validation[idx][self.DATE_COL] > cutoff]

            train_data, val_data, _ = self.standard_scaling(train_data, val_data)

            if self.model_type != "UNIVARIATE":
                train_dataset = MultiVariateTimeSeriesDataset(train_data)
            else:
                train_dataset = UniVariateTimeSeriesDataset(
                    train_data, lookback=self.lookback, horizon=self.horizon
                )
            train_dl = DataLoader(
                train_dataset, batch_size=self.batch_size, shuffle=False
            )

            if self.model_type != "UNIVARIATE":
                val_dataset = MultiVariateTimeSeriesDataset(val_data)
                val_dl = DataLoader(
                    val_dataset, batch_size=self.batch_size, shuffle=False
                )
            else:
                val_data = val_data.reshape(1, -1)[0]
                train_data = train_data.reshape(1, -1)[0]
                val_dl = {
                    "actuals": val_data,
                    "model_input": train_data[-self.lookback :],
                }

            train_val_set["cv_set_" + str(idx)] = {
                "train_dl": train_dl,
                "val_dl": val_dl,
            }

        return train_val_set

    def lstm_cross_validation(self, model, train_val_dl_dict, num_epochs, lr):
        """
        This function train and evaluate the lstm model on cross validation
        datasets.

        Args:
            model: LSTM model object
            - pytorch LSTM model object

            train_val_dl_dict: dictionary
            - dictionary containing training and validation data loaders

            num_epochs: int
            - number of epochs to train the model

            lr: float
            - learning rate for the optimizer

        Return:
            cv_loss: float
            - average loss of the model on the cross validation sets
        """
        cv_loss = []
        for cv_set in train_val_dl_dict.keys():
            train_loader = train_val_dl_dict[cv_set]["train_dl"]
            valid_loader = train_val_dl_dict[cv_set]["val_dl"]
            model, train_loss, val_loss = self.train_eval_model(
                model, train_loader, valid_loader, num_epochs, lr
            )
            cv_loss.append(val_loss)
        cv_loss = np.mean(cv_loss)
        return cv_loss

    def objective(self, trial, df, input_dim):
        """
        This function contains all the hyperparameter for the
        LSTM model and helps in performing hyperparameter of the model.

        """
        # Set up hyperparameters to tune
        hidden_dim = trial.suggest_int(
            "hidden_dim",
            self.dl_model_inputs["hidden_dim"]["min"],
            self.dl_model_inputs["hidden_dim"]["max"],
        )
        num_layers = trial.suggest_int(
            "num_layers",
            self.dl_model_inputs["num_lstm_layers"]["min"],
            self.dl_model_inputs["num_lstm_layers"]["max"],
        )
        dropout = trial.suggest_uniform(
            "dropout",
            self.dl_model_inputs["dropout"]["min"],
            self.dl_model_inputs["dropout"]["max"],
        )
        learning_rate = trial.suggest_loguniform(
            "learning_rate",
            self.dl_model_inputs["learning_rate"]["min"],
            self.dl_model_inputs["learning_rate"]["max"],
        )
        num_epochs = trial.suggest_int(
            "num_epochs",
            self.dl_model_inputs["num_epochs"]["min"],
            self.dl_model_inputs["num_epochs"]["max"],
        )

        model = LSTMModel(
            model_type=self.model_type,
            input_dim=input_dim,
            hidden_dim=hidden_dim,
            output_dim=1,
            num_layers=num_layers,
            dropout=dropout,
        )
        # model.to(device)

        loss = self.lstm_cross_validation(model, df, num_epochs, learning_rate)
        return loss

    def univariate_model_pred(self, model, data, num_forecast_points):
        """
            Forecast for univariate deep learning model(LSTM) predictions.

            Args:
                model: pytroch dl model obj
                - deep model to get the predictions

                data: list
                - contains the daa for which forecasts have to be generated

                num_forecast_point: int
                - horizon for forecast
        """
        inputs = torch.FloatTensor(data)
        forecast = []
        with torch.no_grad():
            for idx in range(num_forecast_points):
                inputs = inputs.unsqueeze(1).reshape(1, self.lookback, 1)
                outputs = model(inputs)
                inputs = torch.FloatTensor(list(inputs[0])[:-1] + list(outputs[0]))
                forecast.extend(outputs)
        return forecast

    def train_eval_model(self, model, train_loader, valid_loader, num_epochs, lr):
        """
        Training and evaluate the deep learning model.

        Args:
            model: LSTM model object
            - pytorch LSTM model object

            train_loader: pytorch data loader
            - data loader to fetch the batches of the training data

            valid_loader: pytorch data loader
            - data loader to fetch the batches of the validation data

            num_epochs: int
            - number of epochs to train the model

            lr: float
            - learning rate for the optimizer

        Return:
            model: LSTM model object
            - pytorch LSTM model object after training on the training data

            cv_loss: float
            - average loss of the model on the cross validation sets
        """
        criterion = nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)

        for epoch in range(num_epochs):
            train_loss = 0.0
            target_len = 0
            for features, target in train_loader:
                if self.model_type != "UNIVARIATE":
                    features = features.unsqueeze(1)
                    target = target.unsqueeze(1)

                output = model(features)
                # print(output)
                loss = criterion(output, target.squeeze())
                train_loss += loss.item() * features.size(0)
                target_len = target_len + len(target)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            train_loss /= target_len

            # Evaluate the model on the valid set
            valid_loss = 0.0
            target_len = 0

            if self.model_type != "UNIVARIATE":
                with torch.no_grad():
                    for features, target in valid_loader:
                        features = features.unsqueeze(1)
                        output = model(features)
                        loss = criterion(output, target.unsqueeze(1))
                        valid_loss += loss.item() * features.size(0)
                        target_len = target_len + len(target)
                    valid_loss /= target_len
            else:
                output = self.univariate_model_pred(
                    model, valid_loader["model_input"], len(valid_loader["actuals"])
                )
                loss = criterion(
                    torch.FloatTensor(valid_loader["actuals"]),
                    torch.FloatTensor(output),
                )
                valid_loss = loss

            # Print the loss for each epoch
            if (epoch + 1) % 100 == 0:
                print(
                    f"Epoch {epoch+1}/{num_epochs}, Train Loss: {train_loss:.4f}, valid Loss: {valid_loss:.4f}"
                )

        return model, train_loss, valid_loss

    def train_lstm_model(self, df):
        """
            This function fits the deep leaning model on the df.

            Args:
                df: pandas dataframe
                - dataframe with all the required columns

            Return:
                model: pytorch deep learning model object
                - pytorch deep learning model object after training has been done

                train_data: numpy array
                - contains the standard scaled data for the training period 

                train_loader: pytorch dataloader obj
                - dataloader object for the training data

                test_loader: pytorch dataloader obj
                - dataloader object for the test data

                sc_objs: list
                - list containing the sklearn standard scaler object for the 
                features and targets
        """
        dates = df[self.DATE_COL]

        if self.model_type == "UNIVARIATE":
            input_dim = 1
            df_updated = df.copy()
        else:
            print( " Feature Transformation Original Dataframe" )
            df_updated = self.ml_transformation_class.run(
                df.copy(),
                cutoff=self.di_model_input["train_till_date"],
                validation_period=self.actual_forecast_period,
            )
            input_dim = df_updated.drop(
                [self.DATE_COL, self.target_column], axis=1
            ).shape[1]
            output_dim = 1

        train_df = df[
            df[self.DATE_COL] <= self.di_model_input["train_till_date"]
        ].sort_values(by=[self.DATE_COL])

        train_val_dl_dict = self.prepare_lstm_cv_data(train_df)

        # perform_hyperparameter_tuning

        if self.hyperparameter_tuning == True:
            print( 'Performing Hyperparameter Tuning....')
            obj_func = lambda trial: self.objective(trial, train_val_dl_dict, input_dim)
            study = optuna.create_study(
                direction="minimize", sampler=optuna.samplers.TPESampler()
            )
            study.optimize(obj_func, n_trials=self.num_trails)
            params = study.best_trial.params

        else:
            params = {
                "hidden_dim": self.dl_model_inputs["hidden_dim"]["value"],
                "num_layers": self.dl_model_inputs["num_lstm_layers"]["value"],
                "dropout": self.dl_model_inputs["dropout"]["value"],
                "learning_rate": self.dl_model_inputs["learning_rate"]["value"],
                "num_epochs": self.dl_model_inputs["num_epochs"]["value"],
            }

        model = LSTMModel(
            model_type=self.model_type,
            input_dim=input_dim,
            hidden_dim=params["hidden_dim"],
            output_dim=output_dim,
            num_layers=params["num_layers"],
            dropout=params["dropout"],
        )

        train_data = df_updated[
            df_updated[self.DATE_COL] <= self.di_model_input["train_till_date"]
        ]
        forecast_data = df_updated[
            df_updated[self.DATE_COL].isin(self.actual_forecast_period)
        ]
        train_data, test_data, sc_objs = self.standard_scaling(train_data, forecast_data)
        target_sc = sc_objs[1]

        if self.model_type == "UNIVARIATE":
            train_loader = DataLoader(
                UniVariateTimeSeriesDataset(train_data, self.lookback, self.horizon),
                batch_size=self.batch_size,
                shuffle=False,
            ) 
            test_loader = {
                "actuals": test_data,
                "model_input": train_data[-self.lookback :],
            }
        else:
            train_loader = DataLoader(
                MultiVariateTimeSeriesDataset(train_data),
                batch_size=self.batch_size,
                shuffle=False,
            )
            test_loader = DataLoader(
                MultiVariateTimeSeriesDataset(test_data),
                batch_size=self.batch_size,
                shuffle=False,
            )
        # model, train_loader, valid_loader, num_epochs, lr
        model.train()
        model, train_loss, test_loss = self.train_eval_model(
            model,
            train_loader,
            test_loader,
            params["num_epochs"],
            params["learning_rate"],
        )

        return model, train_data, train_loader, test_loader, sc_objs


    def run( self, df, Key):
        """
            This function perform the cross validation on the cross validation
            sets, fit the deep learning model on training period data and saves
            # all the necessary columns.
        """
        path = os.path.join(self.location_to_save, "dl_model_results")
        Path(path).mkdir(parents=True, exist_ok=True)
        try:
            df = df[df['key'] == Key]
            model, train_data, train_dl, test_dl, sc_objs = self.train_lstm_model(df)
        
            with open( os.path.join( path, f'{Key}_train_data.pkl'), 'wb') as file:
                pickle.dump( train_data, file)

            with open( os.path.join( path, f'{Key}_train_dataloader.pkl'), 'wb') as file:
                pickle.dump(  train_dl, file)

            with open( os.path.join( path, f'{Key}_test_dataloader.pkl'), 'wb') as file:
                pickle.dump(  test_dl, file)

            with open( os.path.join( path, f'{Key}_scaler_objs.pkl'), 'wb') as file:
                pickle.dump( sc_objs, file)

            with open( os.path.join( path, f'{Key}_dl_model.pkl'), 'wb') as file:
                pickle.dump( model, file)
        except:
            error_path = os.path.join(self.location_to_save, "dl_model_results", "dl_validation_errors")
            Path(error_path).mkdir(parents=True, exist_ok=True)
            warnings.warn(f" Deep learning model validation task has failed for {Key} \n Please check \
                            the error in folder {error_path}")
            with open( os.path.join(error_path, f"{Key}_dl_model_error.txt"), 'w+') as file:
                file.write( str(traceback.format_exc()))
            pass
        