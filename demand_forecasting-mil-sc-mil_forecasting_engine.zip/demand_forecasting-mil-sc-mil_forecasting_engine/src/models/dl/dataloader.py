"""
Author: Pranjal Soni
Version: 0.0.1
Description: This file contains the Dataset classed and dataloader functions for deep learning model.
"""

import numpy as np
from ...helper import np, DataLoader, Dataset



class MultiVariateTimeSeriesDataset(Dataset):
    """Class to fetch get the multivariate forecasting data."""

    def __init__(self, data):
        feature_vals, target_vals = data[0], data[1]
        self.target = target_vals.astype(np.float32)
        self.features = feature_vals.astype(np.float32)

    def __len__(self):
        return len(self.target)

    def __getitem__(self, idx):
        return self.features[idx], self.target[idx]


class UniVariateTimeSeriesDataset(Dataset):
    """ Class to fetch get the univariate forecasting data."""
    def __init__(self, data, lookback, horizon):
        self.data = data.astype(np.float32)
        self.lookback = lookback
        self.horizon = horizon

    def __getitem__(self, index):
        x = self.data[index : index + self.lookback]
        y = self.data[index + self.lookback : index + self.lookback + self.horizon]
        return x, y

    def __len__(self):
        return len(self.data) - self.lookback - self.horizon + 1

def multivariate_lstm_dl( train_data, val_data, batch_size, lookback, model_type):
    """
    Create the data loaders for model training.

    Args:
        train_data: pandas dataframe
        - dataframe contains the training data

        val_data: pandas dataframe
        - dataframe consisting validation period data

    Return:
        train_loader: pytorch data loader
        - data loader of the training data to load the data into batches

        va_loader: pytorch data loader
        - data loader of the validation data to load the data into batches
    """
    train_dataset = MultiVariateTimeSeriesDataset(train_data)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=False)
    val_dataset = MultiVariateTimeSeriesDataset(val_data)

    if model_type != 'UNIVARIATE':
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    else:
        val_loader = { 'actuals': val_data, 'model_input': train_data[-lookback]}
    
    return train_loader, val_loader


