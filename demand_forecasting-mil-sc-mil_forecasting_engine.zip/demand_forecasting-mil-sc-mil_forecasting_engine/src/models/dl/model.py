"""
Author: Pranjal Soni
Version: 0.0.1
Description: This file have defined Deep Learning model architecture. 
"""

from ...helper import torch, nn
class LSTMModel(nn.Module):
    """Defining the architecture of the LSTM model"""

    def __init__(self, model_type, input_dim, hidden_dim, output_dim, num_layers, dropout=0):
        super(LSTMModel, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.conv = nn.Conv1d( in_channels=input_dim, out_channels=32, kernel_size=2, )
        self.lstm = nn.LSTM(
           input_dim, hidden_dim, num_layers, dropout=dropout, batch_first=True
        )
        self.fc = nn.Linear(hidden_dim, output_dim)
        self.model_type = model_type

    def forward(self, x):
        if self.model_type != "UNIVARIATE":
            h0 = torch.zeros(
                self.num_layers, x.size(0), self.hidden_dim
            ).requires_grad_()
            c0 = torch.zeros(
                self.num_layers, x.size(0), self.hidden_dim
            ).requires_grad_()
            out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
            out = self.fc(out[:, -1, :])
        else:
            _, (h, _) = self.lstm(x)
            out = self.fc(h[-1, :, :])

        return out