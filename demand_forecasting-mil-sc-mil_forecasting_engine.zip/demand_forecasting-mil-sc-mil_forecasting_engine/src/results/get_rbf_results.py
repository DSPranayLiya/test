"""
Author: Pranjal Soni
Version : 0.0.2
Description: This file generate the residual bootstrapping results key-wise.
"""

from itertools import product
from ..helper import pd, os, np, traceback, tqdm, delayed, Parallel
from ..helper import GetGeneralPipelineInput
from ..rbf import (
    ProphetResidualBootstrapping,
    RegressionResidualBootstrapping,
    CTSResidualBootstrapping,
    RBFResultPreparation,
    HighVolatileBrandRange
)


class GetRBFResult(GetGeneralPipelineInput):
    """
    This class runs the methods and generate outputs for
    the range based forecasting.
    """

    def __init__(self, input_dict, df):
        """
            RBF Result Generation Constructor
            
            Initializes the GetRBFResult class. 

            Inputs:
            - input_dict ( dict): All inputs from the input template
            - df (df): Dataframe consisting all the demand derivers. 
        """
        super().__init__(input_dict=input_dict)
        day = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%d')
        month_name = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%b')
        year = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%Y')
        self.suffix = f"train_till_{day}_{month_name}_{year}"

        self.df = df
        self.input_dict = input_dict
        self.rbf_result_prep = RBFResultPreparation()
        self.model_summary = pd.read_csv(
            os.path.join(self.location_to_save, f"forecast_{self.suffix}.csv")
        )
        self.rbf_models = self.input_dict["rbf_params"]["Models"]
        self.forecast_months = self.input_dict["rbf_params"]["Forecast_Month"]
        self.SMOOTHENING_FLAG = self.input_dict["rbf_params"]["SMOOTHENING_FLAG"]
        self.smoothening_level = self.input_dict["rbf_params"]["SMOOTHENING_LEVEL"]
        self.shifting = self.input_dict["rbf_params"]["Shifting"]
        self.scaling = self.input_dict["rbf_params"]["Scaling"]
        self.high_volatile_brands = self.input_dict['high_volatile_brands']['brand_code'].tolist()

    def generate_bootstrap_results(
        self,
        Key,
        best_model,
        forecast_date,
        shifting,
        scaling,
        scaling_factor,
        use_smoothening,
        smoothening_level,
    ):
        """
        By using the best model input this function call the function to generate rbf results and generate the
        bootstrapping residuals.

        Input:
            Key: int | str
            - key value at the granularity level

            forecast_date: string
            - forecast month in format yyyy-mm-dd

            shifting: boolean
            - flag to apply shifting on the residuals

            scaling: boolean
            - flag for applying the scaling on small residual values

            scaling_factor: float
            - factor by which residuals to be scaled

        Return:
            test_predictions: list
            - list consisting test predictions for all the iterations
        """

        best_model = best_model.upper()
        if best_model == "RF":
            ml_residual_bootstrapping = RegressionResidualBootstrapping(
                df=self.df, input_dict=self.input_dict, model_type="RF"
            )
            test_predictions = ml_residual_bootstrapping.ml_residual_bootstrapping(
                key=Key,
                forecast_date=forecast_date,
                shifting=shifting,
                scaling=scaling,
                scaling_factor=scaling_factor,
                use_smoothening=use_smoothening,
                smoothening_level=smoothening_level,
            )

        elif best_model == "XGB":
            ml_rbf = RegressionResidualBootstrapping(
                df=self.df, input_dict=self.input_dict, model_type="XGB"
            )
            test_predictions = ml_rbf.ml_residual_bootstrapping(
                key=Key,
                forecast_date=forecast_date,
                shifting=shifting,
                scaling=scaling,
                scaling_factor=scaling_factor,
                use_smoothening=use_smoothening,
                smoothening_level=smoothening_level,
            )

        elif best_model == "PROPHET":
            prophet_rbf = ProphetResidualBootstrapping(
                df=self.df, input_dict=self.input_dict
            )
            test_predictions = prophet_rbf.prophet_residual_bootstrapping(
                Key=Key,
                forecast_date=forecast_date,
                shifting=shifting,
                scaling=scaling,
                scaling_factor=scaling_factor,
                use_smoothening=use_smoothening,
                smoothening_level=smoothening_level,
            )

        elif (best_model == "SARIMA") or (best_model == "ARIMA"):
            cts_rbf = CTSResidualBootstrapping(
                df=self.df,
                input_dict=self.input_dict,
                model_type=best_model,
                forecast_date=forecast_date,
            )
            test_predictions = cts_rbf.cts_residual_bootstrapping(
                Key=Key,
                forecast_date=forecast_date,
                shifting=shifting,
                scaling=scaling,
                scaling_factor=scaling_factor,
                use_smoothening=use_smoothening,
                smoothening_level=smoothening_level,
            )

        return test_predictions

    def get_rbf_results(
        self,
        row,
        forecast_date,
        scaling_factor,
        shifting,
        use_smoothening,
        smoothening_level,
    ):
        """
        Prepare the residuals forecasting results and calculate the percentiles for
        the test predictions of the provided iterations.

        Input:
            df: pandas dataframe
            - dataframe having training data for the model

            row: list
            - row having the information of the key wise best model, actual and pt est values

            scaling_factor: bool | float
            - False if scaling not to apply else value for scaling factor

            shifting: boolean
            - flag to apply shifting on the residuals

        Return:
            output: list
            - list of rbf result percentile values along with key info like actual, prediction values etc.

        """
        # try:
        Key, best_model = row[0], row[-1]
        if (scaling_factor == False) or pd.isna(scaling_factor) == True:
            scaling = False
        else:
            scaling = True

        test_predictions = self.generate_bootstrap_results(
            Key,
            best_model,
            forecast_date,
            shifting,
            scaling,
            scaling_factor,
            use_smoothening,
            smoothening_level,
        )

        percentile_vals = [
            np.percentile(test_predictions, 5),
            np.percentile(test_predictions, 10),
            np.percentile(test_predictions, 15),
            np.percentile(test_predictions, 20),
            np.percentile(test_predictions, 80),
            np.percentile(test_predictions, 85),
            np.percentile(test_predictions, 90),
            np.percentile(test_predictions, 95),
        ]

        output = [
            forecast_date,
            Key,
            best_model,
            row[3],
        ] + percentile_vals

        return output

    def get_iteration_combinations(self):
        """
        This function prepare the list of combinations for the scaling factor,
        smoothening levels, and shifting.
        Returns:
            combinations: list
            - list of all possible combinations with at first positions of each
            combinations contains model name followed by  forecast_month,
            smoothening level, shifting flag, scaling factor.
        """
        if type(self.smoothening_level) != list:
            self.smoothening_level = [self.smoothening_level]

        if type(self.scaling) != list:
            self.scaling = [self.scaling]

        if type(self.shifting) != list:
            self.shifting = [self.shifting]

        if type(self.forecast_months) != list:
            self.forecast_months = [self.forecast_months]

        if type(self.rbf_models) != list:
            self.rbf_models = [self.rbf_models]

        self.scaling = [int(val) for val in self.scaling]
        combinations = list(
            product(
                self.rbf_models,
                self.forecast_months,
                self.smoothening_level,
                self.shifting,
                self.scaling,
            )
        )
        return combinations

    def run(self):
        """
            This function generate range based forecasting results and
            save them to output folder.
        """
        range_forecast = []
        model_summary = self.model_summary[
            ["key", "month_date", "Best_Model", "pred", "Model_Type"]
        ]
        model_summary = model_summary[model_summary["pred"] > 0]

        self.df['month_date'] = pd.to_datetime(self.df['month_date'])

        if len(set(self.high_volatile_brands).intersection(set(self.df['brand_code'])))>0:
            high_vol_brand_range_obj = HighVolatileBrandRange()
            high_vol_brand_ranges = high_vol_brand_range_obj.prepare_high_volatile_brands_results( data=self.df,
                                                                                                high_vol_brands= self.high_volatile_brands,
                                                                                                    forecast_months=self.forecast_months )
                                                                                            
            high_volatile_keys = self.df[self.df['brand_code'].isin(self.high_volatile_brands)]['key'].unique()
        else:
            high_vol_brand_ranges = pd.DataFrame()
        
        if len(high_vol_brand_ranges)>0:
            if type(model_summary.loc[:,'key'].iloc[0])==str:
                high_volatile_keys = [str(col) for col in high_volatile_keys]
                high_vol_brand_ranges.loc[:,'key'] = high_vol_brand_ranges['key'].astype(str)
            else:
                high_volatile_keys = [int(col) for col in high_volatile_keys]
                high_vol_brand_ranges.loc[:,'key'] = high_vol_brand_ranges['key'].astype(int)
        
            model_summary  = model_summary[~(model_summary['key'].isin(high_volatile_keys))]
        # model_summary = model_summary[ model_summary['key'].isin([720794,720797,718409,718606])][['key','pred','month_date','Model_Type']]
        iteration_combinations = self.get_iteration_combinations()
        print( iteration_combinations)
        for combination in tqdm(iteration_combinations):
            (
                best_model,
                forecast_date,
                smoothening_level,
                shifting,
                scaling_factor,
            ) = combination
            best_model_df = model_summary[
                (model_summary["Model_Type"] == best_model.lower().strip())
                & (pd.to_datetime(model_summary["month_date"] )== pd.to_datetime(forecast_date))
            ]
            if pd.isna(self.smoothening_level) == True:
                use_smoothening = False
            else:
                use_smoothening = True
            
            # best_model_df = best_model_df[best_model_df['key']==721061]
            # List_Output = [self.get_rbf_results( row,
            #             forecast_date,
            #             scaling_factor,
            #             shifting,
            #             use_smoothening,
            #             smoothening_level) for row in tqdm(best_model_df.values)]
            try:
                List_Output = Parallel(n_jobs=os.cpu_count() - 2)(
                    delayed(self.get_rbf_results)(
                        row,
                        forecast_date,
                        scaling_factor,
                        shifting,
                        use_smoothening,
                        smoothening_level,
                    )
                    for row in tqdm(best_model_df.values)
                )
            except:
                print(traceback.print_exc())

            best_model_range_forecast = self.rbf_result_prep.prepare_range_base_results(
                                                                                        List_Output,
                                                                                        use_smoothening,
                                                                                        forecast_date,
                                                                                        smoothening_level,
                                                                                        shifting,
                                                                                        scaling_factor,
                                                                                    )
                                                               
            range_forecast.append(best_model_range_forecast)

        final_range_forecast = pd.concat( range_forecast, ignore_index=True,axis=0 )
        final_range_forecast = pd.concat([final_range_forecast, high_vol_brand_ranges], ignore_index=True,axis=0)

        best_model_df = model_summary[self.model_summary['Model_Type'] == 'Best_Model'].rename(columns={'month_date':'forecast_date'})
        best_model_df = best_model_df[['key','forecast_date', 'Best_Model']].drop_duplicates(subset=['key', 'forecast_date'], keep='first')
        

        best_model_df.loc[:,'forecast_date'] = best_model_df['forecast_date'].astype(final_range_forecast['forecast_date'].dtype)
        final_range_forecast  = pd.merge(final_range_forecast, best_model_df, on=['key', 'forecast_date'], how= 'left')
        final_range_forecast.loc[final_range_forecast['model']=='High_COV','Best_Model'] = 'High_COV'

        final_range_forecast.loc[:,'Best_Model_Flag'] = final_range_forecast['Best_Model']==final_range_forecast['model']
        final_range_forecast.to_excel(  os.path.join( self.location_to_save, 'rbf_results.xlsx'), index=False)
