"""
Author: Aishwarya Verma
Version : 0.0.2
Description: This file contain the class to run the full cts pipeline(validation+forecast)
"""
from ..helper import np, pd, os, tqdm, ChainMap, pickle
from ..helper import run_parallel_functions, concatenate_pandas_dataframe, create_dir
from ..helper import GetCtsPipelineInput
from ..models import CtsForecastClass


class GetCtsModelResultsClass(GetCtsPipelineInput):
    """
    This class will run all the cts models mentioned in
    input template(validation + forecast)
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        self.df = df
        self.input_dict = input_dict

    
    def get_cts_forecast_results(self, model_type):
        """
        This function will run the validation + forecast for 
        defined cts model

        Arguments:

            model_type: string
            - defines the type of cts models to run
        """
        print(f"{model_type} Forecasting in progress")
        cts_dir = f"{self.location_to_save}/cts/{model_type}/forecast/"
        self.input_dict[f'{model_type}_dir'] = cts_dir
        create_dir(location=cts_dir, message="CTS")
        cts_forecast_obj = CtsForecastClass(df=self.df, df_cts_data=self.df_cts_data,input_dict = self.input_dict, model_type=model_type)
        for i in tqdm(range(0,self.df_cts_data.key.nunique(),self.no_of_keys_to_process)):
                keys = self.df_cts_data.key.unique()[i:i+self.no_of_keys_to_process]
                df_model_batch = self.df_cts_data[self.df_cts_data['key'].isin(keys)]
                model_forecast = [cts_forecast_obj.run( 'AURG_D3A4_718288')]
                model_forecast = run_parallel_functions(func=cts_forecast_obj.run,
                                                            df=df_model_batch,
                                                            argument_dict={},
                                                            desc=f"{model_type} Forecasting for Batch {i+1}",
                                                            iter_col = "key",
                                                            is_iter_idx=False, 
                                                            is_df_arg=False
                                                            )
               
                train = [res[0] for res in model_forecast if res!=None]
                test = [res[1] for res in model_forecast if res!=None]
                cts_models_list = [res[2] for res in model_forecast if res!=None]     
                train_df = concatenate_pandas_dataframe(data_list=train)   
                test_df = concatenate_pandas_dataframe(data_list=test)  
                cts_models_list = dict(ChainMap(*cts_models_list))
                
                train_df.to_csv(f"{cts_dir}/{model_type}_Train_Data_{i}.csv",
                                        index=False)
                
                test_df.to_csv(f"{cts_dir}/{model_type}_Forecasting_Results_{i}.csv",
                                        index=False)
                
                if not os.path.isfile(f"{cts_dir}/{model_type}_models.pkl"):
                    with open(f"{cts_dir}/{model_type}_models.pkl", 'wb') as f:
                        pickle.dump(cts_models_list, f)
                else:
                    #reopen and unpickle the pickled content and read to obj
                    with open(f"{cts_dir}/{model_type}_models.pkl","rb") as f:
                        obj = pickle.load(f)

                    #add to the dictionary object 
                    final_obj = {**obj, **cts_models_list}
                    with open(f"{cts_dir}/{model_type}_models.pkl","wb") as f:
                        pickle.dump(final_obj, f)
        del cts_forecast_obj

        print(f"{model_type} Forecasting completed")

    def run(self):
        """
        This function will run all the classical time series models(ARIMA & SARIMA) with its validation.

        Arguments:

                location_to_save: str
                - location of the directory where all the intermediate/final results are saved
        
        Return: True
            Indicating the process is completed
        """

        if self.di_model_input['TS'] == 1:
            if self.Input_model_vars.loc[('Model_Choice','TS'),'Model_Selected'] == np.nan:
                cts_model_list = self.Input_model_vars.loc[('Model_Choice','TS'),'Default_Choice'].split(',')
            else:
                cts_model_list = self.Input_model_vars.loc[('Model_Choice','TS'),'Model_Selected'].split(',')

            df_cts_data = self.df.groupby(['key',self.DATE_COL],as_index = False).agg({self.target_column:sum})
            df_cts_data_updated = []
            if self.input_dict['treat_covid_months_flag_cts']==True:
                for i in tqdm(range(0,df_cts_data.key.nunique(),self.no_of_keys_to_process)):

                    keys = df_cts_data.key.unique()[i:i+self.no_of_keys_to_process]
                    df_model_batch = df_cts_data[df_cts_data['key'].isin(keys)]
                    output = run_parallel_functions(func=self.treat_covid_months, 
                                                    df=df_model_batch, 
                                                    argument_dict={},
                                                    desc=f"Replacing Covid Months with p3m for CTS key from {i+1}", 
                                                    iter_col="key", 
                                                    is_iter_idx=False, 
                                                    is_df_arg=True)

                    df_cts_data_updated.extend([res[0] for res in output])
                self.df_cts_data =concatenate_pandas_dataframe(data_list=df_cts_data_updated)
            else:
                self.df_cts_data = df_cts_data  
            del df_cts_data

            if "ARIMA" in cts_model_list:
                self.get_cts_forecast_results(model_type="ARIMA")
            
            if "SARIMA" in cts_model_list:
                self.get_cts_forecast_results(model_type="SARIMA")
                
            return True
        