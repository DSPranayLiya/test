"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains the class to run the full ml pipeline
(validation +forecast)
"""
from ..helper import pd, os, tqdm, ChainMap, pickle
from ..models import GetMlFeatureTransformationsClass
from ..helper import run_parallel_functions, concatenate_pandas_dataframe, create_dir
from ..helper import GetGeneralPipelineInput
from ..models import MlValidationClass
from ..models import MlForecastClass


class GetMlModelsResultsClass(GetGeneralPipelineInput):
    """
        This class will give the validation + forecast for all 
        the ml models defined in the input template.
    """
    def __init__(self, df, input_dict, feature_selection_module_obj):
        """
        """
        super().__init__(input_dict=input_dict)
        self.df = df
        self.input_dict = input_dict
        self.ml_transformation_obj = GetMlFeatureTransformationsClass(input_dict=input_dict)
        self.feature_selection_module_obj = feature_selection_module_obj

    def get_ml_validation_data(self):
        """
        This function will give the validation data for ml models
        defined in the input template.

        Arguments:
            None

        Return:
            df_validation: list
            - list of cross validation sets for ml modelling.
        """
        df_validation = []
        final_fs_data = []
        
        for idx in range(len(self.cutoffs_periods)):
            
            file_name = f"cross_validation_set_{idx+1}.csv"
            
            if file_name not in os.listdir(f"{self.location_to_save}/ml_results/validation"):
                df_validation_subset = self.df[self.df[self.DATE_COL]<=max(self.cv_periods[idx])].copy()
                df_validation_subset = self.ml_transformation_obj.run(df_validation=df_validation_subset,
                                                                            cutoff=self.cutoffs_periods[idx],
                                                                            validation_period=self.cv_periods[idx],
                                                                        )
                if self.di_model_input['Model_Feature_Selection']==1:
                    feature_selection_output = run_parallel_functions(func = 
                                            self.feature_selection_module_obj.run_advanced_feature_selection_methods,
                                            df=df_validation_subset,
                                            argument_dict={},
                                            desc = "Advanced Feature Selection",
                                            iter_col='key', 
                                            is_iter_idx=False, 
                                            is_df_arg=True)
                    feature_selection_data = pd.DataFrame(feature_selection_output)
                else:

                    feature_selection_data = pd.DataFrame()
                feature_selection_data['set'] = idx
                df_validation.append(df_validation_subset)
                df_validation_subset.to_csv(f"{self.location_to_save}/ml_results/validation/cross_validation_set_{idx+1}.csv", index=False)
                final_fs_data.append(feature_selection_data)
            else:
                df_validation_subset = pd.read_csv(f"{self.location_to_save}/ml_results/validation/cross_validation_set_{idx+1}.csv")
                df_validation_subset.loc[:, self.DATE_COL] = pd.to_datetime( df_validation_subset.loc[:, self.DATE_COL])
                df_validation.append(df_validation_subset)

        # final_fs_data = concatenate_pandas_dataframe(data_list=final_fs_data)
        # if final_fs_data.shape[0]>0:
        #     final_fs_data.to_csv(f"{self.location_to_save}/advanced_feature_selection_raw_data.csv",index=False)
        #     final_fs_data['k_best_features_name'] = final_fs_data['k_best_features_name'].apply(lambda x : set(x))
        #     final_fs_data = final_fs_data.groupby(['key','type'],as_index=False)['k_best_features_name'].agg(lambda x: set.intersection(*x))
        #     final_fs_data['k_best_features_name'] = final_fs_data['k_best_features_name'].apply(lambda x: list(set(x)))
        #     final_fs_data.to_csv(f"{self.location_to_save}/advanced_feature_selection_final_data.csv",index=False)
        
        return df_validation

    def get_ml_validation_results(self):
        """
        This function will give you the ml validation results

            1. It will create all the validation sets
            2. Then it will create al lthe features required for modelling for all the sets
            3. Then it will run the ml pipeline to get the results for all the sets    
        Return: True
            Indicating the process is completed
        """
        print("ML Validation Pipeline in progress !!")
        ml_validation_dir = f"{self.location_to_save}/ml_results/validation/"
        self.input_dict['ml_valid_dir'] = ml_validation_dir
        create_dir(location = ml_validation_dir, message="ML Validation")
       
        df_validation = self.get_ml_validation_data()
        ml_validation_obj = MlValidationClass(df=self.df, input_dict=self.input_dict)

        for i in tqdm(range(0, self.df.key.nunique(),self.no_of_keys_to_process)):

            keys = self.df.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = self.df[self.df['key'].isin(keys)]

            ml_validation_output = run_parallel_functions(func=ml_validation_obj.run,
                                                        df = df_model_batch,
                                                        argument_dict={"df_validation":df_validation},
                                                        desc=f"ML Validation Batch {i+1}",
                                                        iter_col = "key",
                                                        is_iter_idx=False,
                                                        is_df_arg=False)
        
            model_summary = [res[0] for res in ml_validation_output if res!=None]
            ml_models_list = [res[1] for res in ml_validation_output if res!=None]        
            validation_data_final = [res[2] for res in ml_validation_output if res!=None]

            ml_models_dict = dict(ChainMap(*ml_models_list))
            model_df_ml = concatenate_pandas_dataframe(data_list=model_summary)
            validation_data_final= concatenate_pandas_dataframe(data_list=validation_data_final)

            model_df_ml.to_csv(f"{ml_validation_dir}/model_summary_ml_validation_{i}.csv",index=False)
            validation_data_final.to_csv(f"{ml_validation_dir}/validation_df_{i}.csv",index=False)

            if not os.path.isfile(f'{ml_validation_dir}/ml_models.pkl'):
                with open(f'{ml_validation_dir}/ml_models.pkl', 'wb') as f:
                    pickle.dump(ml_models_dict, f)
            else:
                #reopen and unpickle the pickled content and read to obj
                with open(f'{ml_validation_dir}/ml_models.pkl',"rb") as f:
                    obj = pickle.load(f)

                #add to the dictionary object 
                final_obj = {**obj, **ml_models_dict}
                with open(f'{ml_validation_dir}/ml_models.pkl',"wb") as f:
                    pickle.dump(final_obj, f)
        del ml_validation_obj
        return True

                                                                
    def get_ml_live_forecast(self):
        """
        This function will give you ml live forecast

            1. It will create all the features required for modelling
            2. Then it will run the ml pipeline to get the live forecast
        Return: True
            Indicating the process is completed
        
        """
        print("ML Forecast Pipeline in progress !!")
        ml_forecast_dir = f"{self.location_to_save}/ml_results/forecast/"
        self.input_dict['ml_forecast_dir'] = ml_forecast_dir
        create_dir(location = ml_forecast_dir, message="ML Forecast")
        
        forecast_data_file_name = f"{self.location_to_save}/ml_results/forecast/forecast_data.csv"

        try:
            df_updated = pd.read_csv(forecast_data_file_name)
            df_updated[self.DATE_COL] = pd.to_datetime(df_updated[self.DATE_COL])
        except:
            df_updated = self.ml_transformation_obj.run(df_validation=self.df.copy(),
                                            cutoff=self.di_model_input['train_till_date'],
                                            validation_period=self.actual_forecast_period,
                                            )
            df_updated.to_csv(forecast_data_file_name,index=False)

        ml_forecast_obj = MlForecastClass(df=self.df, input_dict=self.input_dict)
        for i in tqdm(range(0,df_updated.key.nunique(),self.no_of_keys_to_process)):

            keys = df_updated.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = df_updated[df_updated['key'].isin(keys)]
            ml_forecast_output = run_parallel_functions(func=ml_forecast_obj.run,
                                                df = df_model_batch,
                                                argument_dict={},
                                                iter_col = "key",
                                                desc=f"ML Forecast Batch {i}",
                                                is_iter_idx=False,
                                                is_df_arg=True,
                                                backend='threading')
            train = [res[0] for res in ml_forecast_output if res!=None]
            test = [res[1] for res in ml_forecast_output if res!=None]
            feat_imp = [res[2] for res in ml_forecast_output if res!=None]
            vif_final = [res[3] for res in ml_forecast_output if res!=None]
            pca_final = [res[4] for res in ml_forecast_output if res!=None]
            pca_mst_feat = [res[5] for res in ml_forecast_output if res!=None]
            train_shap_values_df = [res[6] for res in ml_forecast_output if res!=None]
            test_shap_values_df = [res[7] for res in ml_forecast_output if res!=None]

            train_df = concatenate_pandas_dataframe(data_list=train)
            test_df = concatenate_pandas_dataframe(data_list=test)
            feat_imp_df = concatenate_pandas_dataframe(data_list=feat_imp)
            vif_final = concatenate_pandas_dataframe(data_list=vif_final)
            pca_final = concatenate_pandas_dataframe(data_list = pca_final)
            pca_mst_feat = concatenate_pandas_dataframe(data_list = pca_mst_feat)
            train_shap_values_df =concatenate_pandas_dataframe(data_list = train_shap_values_df)
            test_shap_values_df =concatenate_pandas_dataframe(data_list = test_shap_values_df)
           
            train_df.to_csv(f"{ml_forecast_dir}/ML_Train_Data_{i}.csv",index=False)
            test_df.to_csv(f"{ml_forecast_dir}/ML_Forecasting_Results_{i}.csv",index=False)
            feat_imp_df.to_csv(f"{ml_forecast_dir}/ML_Feature_Importance_{i}.csv",index=False) 

            if vif_final.shape[0]>0: 
                vif_final.to_csv(f"{ml_forecast_dir}/VIF_{i}.csv",index=False)

            if pca_final.shape[0]>0: 
                pca_final.to_csv(f"{ml_forecast_dir}/PCA_{i}.csv",index=False)
                pca_mst_feat.to_csv(f"{ml_forecast_dir}/PCA_imp_{i}.csv",index=False)
                
            if train_shap_values_df.shape[0]>0:
                train_shap_values_df.to_csv(f"{ml_forecast_dir}/ml_train_shap_values_{i}.csv",index=False)
                test_shap_values_df.to_csv(f"{ml_forecast_dir}/ml_test_shap_values_{i}.csv",index=False)

        del ml_forecast_obj
        return True


    def run(self):
        """
        This is the final function to run the full ML pipeline

            1. First it does the validation
            2. Then saves the validation results
            3. Second it generates the live forecast
            4. Then save live forecast results as well
        
        Return: True
            Indicating the process is completed

        """
        if self.di_model_input['ML_Modeling'] == 1:
            validation_output = self.get_ml_validation_results()
            if validation_output==True:
                forecast_output = self.get_ml_live_forecast()
                if forecast_output==True:
                    print("ML Results Generated!")
            return True