from ..helper import pd, os, tqdm, ChainMap, pickle
from ..helper import run_parallel_functions, concatenate_pandas_dataframe, create_dir
from ..helper import GetProphetPipelineInput
from ..models import ProphetValidationClass
from ..models import ProphetForecastClass


class GetProphetModelResultsClass(GetProphetPipelineInput):
    """
    """
    def __init__(self, df, input_dict):
        """
        """
        super().__init__(df=df, input_dict=input_dict)
        self.df = df
        self.input_dict = input_dict

    def get_prophet_validation_results(self):
        """
        This function will give you the prophet validation results

        Return: True
            Indicating the process is completed
        """
        prophet_validation_dir = f"{self.location_to_save}/prophet_results/validation/"
        self.input_dict['prophet_valid_dir'] = prophet_validation_dir
        create_dir(location=prophet_validation_dir, message="Prophet Validation")
       
        prophet_validation_obj= ProphetValidationClass(df=self.df, input_dict=self.input_dict)
        for i in tqdm(range(0,self.df_prophet_model.key.nunique(),self.no_of_keys_to_process)):
            keys = self.df_prophet_model.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = self.df_prophet_model[self.df_prophet_model['key'].isin(keys)]
            prophet_validation_output = run_parallel_functions(func=prophet_validation_obj.run,
                                                                df = df_model_batch,
                                                                argument_dict={},
                                                                desc=f"Prophet Validation Batch {i+1}",
                                                                iter_col='key', 
                                                                is_iter_idx=False, 
                                                                is_df_arg=False
                                                                )
            model_summary =  [res[0] for res in prophet_validation_output if res!=None]
            prophet_model_list = [res[1] for res in prophet_validation_output if res!=None]
            model_df_prophet = concatenate_pandas_dataframe(data_list=model_summary)
            prophet_model_dict = dict(ChainMap(*prophet_model_list))

            model_df_prophet.to_csv(f"{prophet_validation_dir}/model_summary_prophet_{i}.csv",index=False)
            if not os.path.isfile(f'{prophet_validation_dir}/prophet_models.pkl'):
                with open(f'{prophet_validation_dir}/prophet_models.pkl', 'wb') as f:
                    pickle.dump(prophet_model_dict, f)
            else:
                #reopen and unpickle the pickled content and read to obj
                with open(f'{prophet_validation_dir}/prophet_models.pkl',"rb") as f:
                    obj = pickle.load(f)
                #add to the dictionary object 
                final_obj = {**obj, **prophet_model_dict}
                with open(f'{prophet_validation_dir}/prophet_models.pkl',"wb") as f:
                    pickle.dump(final_obj, f)
        del prophet_validation_obj
        return True
        

    def get_prophet_live_forecast(self):
        """
        This function will give the live prophet forecast
        
        Return: 
            True
            Indicating the process is completed
        """
        prophet_forecast_dir = f"{self.location_to_save}/prophet_results/forecast/"
        self.input_dict['prophet_forecast_dir'] = prophet_forecast_dir
        create_dir(location=prophet_forecast_dir, message="Prophet Forecast")

        prophet_forecast_obj = ProphetForecastClass(df=self.df, input_dict=self.input_dict)

        for i in tqdm(range(0,self.df_prophet_model.key.nunique(),self.no_of_keys_to_process)):

            keys = self.df_prophet_model.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = self.df_prophet_model[self.df_prophet_model['key'].isin(keys)]

            prophet_validation_output = run_parallel_functions(func=prophet_forecast_obj.run,
                                                                df = df_model_batch,
                                                                argument_dict={},
                                                                desc=f"Prophet Forecast Batch {i+1}",
                                                                iter_col='key', 
                                                                is_iter_idx=False, 
                                                                is_df_arg=False
                                                                )
            result = [res[0] for res in prophet_validation_output if res!=None]
            forecast_prophet = concatenate_pandas_dataframe(data_list=result)
            forecast_prophet.to_csv(f"{prophet_forecast_dir}/prophet_forecast_{i}.csv",
                                    index=False)
        del prophet_forecast_obj
        return True
        
    def run(self):
        """
        This is the final function to run the full Prophet pipeline

            1. First it does the validation
            2. Then saves the validation results
            3. Second it generates the live forecast
            4. Then save live forecast results as well
        
        Arguments:
            None
        
        Return: True
            Indicating the process is completed

        """
        if self.di_model_input['Prophet'] == 1:
         
            validation_output =  self.get_prophet_validation_results()
            if validation_output==True:
                forecast_prophet = self.get_prophet_live_forecast()
                if forecast_prophet==True:
                    print("Prophet Results Generated")
                    return True
