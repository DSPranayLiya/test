"""
Author: Pranjal Soni
Version: 0.0.2
Description: This file contains the class to run the full dl pipeline
(validation +forecast)
"""
from ..models import DlValidationClass, DlForecastClass
from ..helper import GetGeneralPipelineInput, run_parallel_functions, tqdm, os, concatenate_pandas_dataframe

class GetDLResultsClass(GetGeneralPipelineInput):
    """
        This class will have the contains the functionalities for validation
        and forecast for deep learning model.
    """

    def __init__(self, input_dict, df):
        """
            
        """
        super().__init__(input_dict=input_dict)
        self.input_dict = input_dict
        self.dl_result_path = os.path.join(self.location_to_save, "dl_model_results")
        self.df = df

    def run_dl_validation(self):
        """
            This method is for train the deep learning model and 
            saves the results.
        """
        dl_validation_obj = DlValidationClass(self.input_dict)
        for i in tqdm(range(0,self.df.key.nunique(),self.no_of_keys_to_process)):

            keys = self.df.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = self.df[self.df['key'].isin(keys)]
            run_parallel_functions(func=dl_validation_obj.run,
                                                        df = df_model_batch,
                                                        argument_dict={},
                                                        iter_col = "key",
                                                        desc=f"DL Forecast Batch {i}",
                                                        is_iter_idx=False,
                                                        is_df_arg=True,)
        return True
    
    def run_dl_forecast(self):
        """
            This method forecast and save the results for deep learning model. 
        """
        dl_forecast_object = DlForecastClass(self.input_dict)
        for i in tqdm(range(0,self.df.key.nunique(),self.no_of_keys_to_process)):

            keys = self.df.key.unique()[i:i+self.no_of_keys_to_process]
            df_model_batch = self.df[self.df['key'].isin(keys)]
            ml_forecast_output = run_parallel_functions(func=dl_forecast_object.run,
                                                        df = df_model_batch,
                                                        argument_dict={},
                                                        iter_col = "key",
                                                        desc=f"DL Forecast Batch {i}",
                                                        is_iter_idx=False,
                                                        is_df_arg=True,)

            result = [res[0] for res in ml_forecast_output if res!=None]
            ml_forecast_output = concatenate_pandas_dataframe(data_list=result)
            ml_forecast_output.to_csv(os.path.join( self.dl_result_path, "dl_model_forecast_result.csv"), 
                            index=False)
        return True
    
    def run(self):
        """
        This function will execute the above listed function in sequence
        """
        if self.di_model_input['DL_Modeling'] == 1: 
            validation_output = self.run_dl_validation()
            if validation_output==True:
                forecast_output = self.run_dl_forecast()
                return forecast_output



