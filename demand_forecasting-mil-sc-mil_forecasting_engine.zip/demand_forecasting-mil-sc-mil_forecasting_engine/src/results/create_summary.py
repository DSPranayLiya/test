from ..helper import pd, np, relativedelta, MonthEnd, os, itertools, tqdm
from ..helper import run_parallel_functions, concatenate_pandas_dataframe, read_files, calculate_wape, calculate_bias
from ..helper import GetGeneralPipelineInput

class CreateSummary(GetGeneralPipelineInput):
    """
    """
    def __init__(self, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)
        self.input_dict = input_dict
        self.original_df = read_files(input_file_path=f"{self.location_to_save}/data.csv")
        self.original_df['key'] =  self.original_df['key'].astype(str)
        self.original_df[self.DATE_COL] =  pd.to_datetime(self.original_df[self.DATE_COL])
        if self.index_rate.empty==False:
            self.index_rate_col = 'qtr_ind_rate'
            original_df_updated = self.get_bpm(df_to_update= self.original_df.copy())
        #     rm_cols = list(set(original_df_updated.columns)-set(self.original_df.columns))
        #     # if len(rm_cols)>0:
        #     #     rm_cols.remove(f"{self.target_column}_value")
        #     if len(rm_cols)==1:
        #         self.index_rate_col = rm_cols[0]
        #     else:
        #         print("Please specify bpm cols from remaining cols",rm_cols)
            self.original_df = original_df_updated
        # else:
        #     self.index_rate_col= None

        self.no_of_cross_validation = self.di_model_input['no_of_cross_validations']

        self.cols_to_filter_ms = ['key','Model_Type']
        for n in range(self.no_of_cross_validation):
            ncv = n+1
            self.cols_to_filter_ms = self.cols_to_filter_ms + [f'Validation_Date_{ncv}_vol',
                                                                f'Validation_Bias_{ncv}_actual_vol', 
                                                                f'Validation_Bias_{ncv}_pred_vol',
                                                                f'Validation_Bias_{ncv}_vol',
                                                                ]
            if self.index_rate.empty==False:
                cols_to_append = [
                                f'Validation_Date_{ncv}_val',
                                f'Validation_Bias_{ncv}_actual_val', 
                                f'Validation_Bias_{ncv}_pred_val',
                                f'Validation_Bias_{ncv}_val',
                                ]
                self.cols_to_filter_ms = self.cols_to_filter_ms+cols_to_append
        
        self.outlier_treated_data = read_files(input_file_path=f"{self.location_to_save}/data_after_outlier_treatment.csv")
        self.outlier_treated_data['key'] =  self.outlier_treated_data['key'].astype(str)
        self.outlier_treated_data[self.DATE_COL] =  pd.to_datetime(self.outlier_treated_data[self.DATE_COL])
        cols_to_filter = ['key', self.DATE_COL, self.target_column]
        if self.index_rate.empty==False:
            self.outlier_treated_data = self.get_bpm(df_to_update= self.outlier_treated_data)
            cols_to_filter.append(f"{self.target_column}_value")
        self.outlier_treated_data = self.outlier_treated_data[cols_to_filter]
        self.outlier_treated_data = self.outlier_treated_data.rename(columns=
                                    {self.target_column:f"{self.target_column}_treated",
                                    f"{self.target_column}_value":f"{self.target_column}_value_treated"})
        
        day = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%d')
        month_name = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%b')
        year = pd.to_datetime(self.di_model_input['train_till_date']).strftime('%Y')
        self.suffix = f"train_till_{day}_{month_name}_{year}"

        
       
    def loop_over_func(self, loc, keyword):
        """
        """
        concat_data  = pd.DataFrame()
        for file in tqdm(os.listdir(loc),  colour='green', desc=f'Reading {keyword}'):
            if keyword in file:
                data = read_files(input_file_path = f"{loc}/{file}")
                concat_data = pd.concat([concat_data, data], axis=0, ignore_index=True)
        return concat_data


    def process_ml_results(self):
        """
        """
        curr_loc = f"{self.location_to_save}/ml_results"

        ml_valid_dir = f"{curr_loc}/validation"
        ml_forecast_dir =f"{curr_loc}/forecast"
        if os.path.exists(ml_valid_dir) and os.path.exists(ml_forecast_dir):
            ml_cv_results = self.loop_over_func(loc=ml_valid_dir, keyword="model_summary_ml_validation")
            ml_cv_results['train_till'] = self.di_model_input['train_till_date']
            ml_cv_results.to_csv(f"{curr_loc}/cross_validation_summary_{self.suffix}.csv", index=False)
            ml_cv_results = ml_cv_results.loc[:,ml_cv_results.columns.isin(self.cols_to_filter_ms)]


            ml_fr_results = self.loop_over_func(loc=ml_forecast_dir, keyword="ML_Forecasting_Results")
            ml_fr_results['type'] = 'testing'

            ml_train_data = self.loop_over_func(loc=ml_forecast_dir, keyword="ML_Train_Data")
            ml_train_data['type'] = 'training'

            ml_data = concatenate_pandas_dataframe(data_list=[ml_train_data, ml_fr_results])
            ml_data['train_till'] = self.di_model_input['train_till_date']
            ml_data.to_csv(f"{curr_loc}/ml_data_{self.suffix}.csv", index=False)

            cols_to_filter = ['key',self.DATE_COL,"Model_Type","type","pred"]
            ml_data_ret = ml_data[cols_to_filter]



            ml_fi = self.loop_over_func(loc=ml_forecast_dir, keyword="ML_Feature_Importance")
            ml_fi['train_till'] = self.di_model_input['train_till_date']
            ml_fi.to_csv(f"{curr_loc}/feature_importance_{self.suffix}.csv", index=False)
        
        else:

            ml_cv_results = pd.DataFrame()
            ml_data_ret = pd.DataFrame()

        return ml_cv_results, ml_data_ret
    
    def process_prophet_results(self):
        """
        """
        curr_loc = f"{self.location_to_save}/prophet_results"

        prophet_valid_dir = f"{curr_loc}/validation/"
        prophet_forecast_dir = f"{curr_loc}/forecast/"

        if os.path.exists(prophet_valid_dir) and os.path.exists(prophet_forecast_dir):
            prophet_cv_results = self.loop_over_func(loc=prophet_valid_dir, keyword="model_summary_prophet")
            prophet_cv_results['Model_Type'] = "prophet"
            prophet_cv_results['train_till'] = self.di_model_input['train_till_date']
            prophet_cv_results.to_csv(f"{curr_loc}/cross_validation_summary_{self.suffix}.csv", index=False)
            prophet_cv_results =  prophet_cv_results.loc[:,prophet_cv_results.columns.isin(self.cols_to_filter_ms)]

            prophet_data = self.loop_over_func(loc=prophet_forecast_dir, keyword="prophet_forecast")
            prophet_data['ds'] = pd.to_datetime(prophet_data['ds'])
            prophet_data['Model_Type'] = "prophet"
            prophet_data.loc[prophet_data['ds'].isin(self.actual_forecast_period),'type'] = 'testing'
            prophet_data['type'].fillna('training', inplace=True)
            prophet_data['train_till'] = self.di_model_input['train_till_date']
            prophet_data.to_csv(f"{curr_loc}/prophet_data_{self.suffix}.csv", index=False)
            prophet_data_ret = prophet_data[['key','ds','Model_Type','type','yhat']]
            prophet_data_ret = prophet_data_ret.rename(columns={"ds":self.DATE_COL, "yhat":"pred"})
        else:

            prophet_cv_results = pd.DataFrame()
            prophet_data_ret = pd.DataFrame()


        return prophet_cv_results, prophet_data_ret
    
    def process_cts_results(self):
        """
        """
        cts_models = ['ARIMA', 'SARIMA']
        curr_loc = f"{self.location_to_save}/cts"

        cts_data = []
        ms_data = []
        

        for model in cts_models:
            curr_loc_model = f"{curr_loc}/{model}/forecast"
            if os.path.exists(curr_loc_model):

                train_data = self.loop_over_func(loc=curr_loc_model, keyword=f"{model}_Train_Data")
                train_data['Model_Type'] = model
                train_data['type'] = 'training'
                train_data = train_data.loc[:,train_data.columns.isin(['key',self.DATE_COL, 'Model_Type','m',
                                        'type','pred',self.target_column])]
                test_data = self.loop_over_func(loc=curr_loc_model, keyword=f"{model}_Forecasting_Results")
                test_data['train_till'] = self.di_model_input['train_till_date']
                test_data.to_csv(f"{curr_loc_model}/cross_validation_summary_{self.suffix}.csv", index=False)
                test_data[self.DATE_COL] = pd.to_datetime(test_data[self.DATE_COL])
                test_data['Model_Type'] = model
                test_data['type'] = 'testing'
                ms_data.append(test_data.loc[:,test_data.columns.isin(self.cols_to_filter_ms)])
                test_filtered = test_data.loc[:,test_data.columns.isin(['key',self.DATE_COL, 'Model_Type','m',
                                        'type','pred'])]


                model_data = concatenate_pandas_dataframe(data_list  =[train_data,test_filtered])
                model_data['train_till'] = self.di_model_input['train_till_date']
                model_data.to_csv(f"{curr_loc_model}/{model}_data_{self.suffix}.csv", index=False)
                cts_data.append(model_data)
               
        
        cts_data = concatenate_pandas_dataframe(data_list=cts_data)
        ms_data = concatenate_pandas_dataframe(data_list=ms_data)
        if cts_data.empty==False:
            cts_data['train_till'] = self.di_model_input['train_till_date']
            cts_data.to_csv(f"{curr_loc}/cts_data_{self.suffix}.csv", index=False)
            cts_data_ret = cts_data[['key',self.DATE_COL,'Model_Type','type','m','pred']]
            cts_cv_results = ms_data.loc[:,ms_data.columns.isin(self.cols_to_filter_ms)]
            cts_cv_results = cts_cv_results[~cts_cv_results['Validation_Date_1_vol'].isna()]
        else:

            
            cts_cv_results = pd.DataFrame()
            cts_data_ret = pd.DataFrame()


        return cts_cv_results, cts_data_ret

    def process_dl_results(self):
        """
        """
        pass

    def calculate_train_accuracy(self, df, Key, actual, pred):
        """
        """
        train = df[df['key']==Key]
        acc_list = []
        for model_type in train['Model_Type'].unique():
            train_data = train[train['Model_Type']==model_type]
            train_acc_value = 100-(calculate_wape(y_true=train_data[actual],y_pred=train_data[pred]))*100
            acc_list.append([Key,train_acc_value,model_type])
        return acc_list

    def get_train_accuracy(self, full_forecast):
        """
        """
        cols_to_filter = ['key', self.DATE_COL, "Model_Type"]
        if self.index_rate.empty==False:
            cols_to_filter = cols_to_filter + ['pred_value',f"{self.target_column}_value"]
            actual = f"{self.target_column}_value"
            pred = "pred_value"
        else:
            cols_to_filter = cols_to_filter + ['pred',self.target_column]
            actual = self.target_column
            pred = "pred"


        train_data = full_forecast[full_forecast['type']=='training'][cols_to_filter]
        argument_dict = {"actual":actual,
                        "pred":pred}
        train_acc_output = run_parallel_functions(func=self.calculate_train_accuracy,
                                                    df=train_data,
                                                    argument_dict=argument_dict,
                                                    desc=f"Calculate Training Accuracy",
                                                    iter_col = "key",
                                                    is_iter_idx=False, 
                                                    is_df_arg=True)
       
        train_acc_output = list(itertools.chain.from_iterable(train_acc_output))
        train_acc_output = pd.DataFrame(train_acc_output,columns=['key','train_accuracy','Model_Type'])
        train_acc_output['key'] = train_acc_output['key'].astype(str)
        return train_acc_output


    def calculate_validation_accuracy(self, model_summary):
        """
        """
        model_summary['key'] = model_summary['key'].astype(str)
        cols_to_filter = ['key','Model_Type']
        if self.index_rate.empty==False:
            col = "val"
        else:
            col = "vol"
        
        for n in range(self.no_of_cross_validation):
            ncv = n+1
            cols_to_filter = cols_to_filter + [f'Validation_Date_{ncv}_{col}',
                                                                f'Validation_Bias_{ncv}_actual_{col}', 
                                                                f'Validation_Bias_{ncv}_pred_{col}',
                                                                f'Validation_Bias_{ncv}_{col}',
                                                                ]
        validation_bias = model_summary.loc[:,model_summary.columns.isin(cols_to_filter)]

        valid_data_dict = {}

        for grp_key,grp in validation_bias.groupby(['key','Model_Type']):
            key = grp_key[0]
            model_type =  grp_key[1]
            grp_key = str(grp_key[0])+"_"+str(grp_key[1])
            key = grp['key'].unique().tolist()[0]
            valid_flag = []
            valid_data = []
            for n in range(self.no_of_cross_validation):
                ncv = n+1
                validation_gp_df = grp.loc[:, grp.columns.isin([f"Validation_Date_{ncv}_{col}",
                                                            f"Validation_Bias_{ncv}_pred_{col}",
                                                            f"Validation_Bias_{ncv}_actual_{col}"
                                                            ]    
                                                            )]
                if (validation_gp_df.shape[0]>0) and (validation_gp_df.shape[1]>0):
                    if (validation_gp_df[f"Validation_Date_{ncv}_{col}"].isnull().sum()==0):
                        validation_gp_df = validation_gp_df.rename(columns={f"Validation_Bias_{ncv}_actual_{col}":"actual",
                                                            f"Validation_Bias_{ncv}_pred_{col}":"pred",
                                                            f"Validation_Date_{ncv}_{col}":self.DATE_COL})
                        if validation_gp_df.shape[0]>0:
                            valid_flag.append(f"Val_{ncv}")
                    else:
                        validation_gp_df = pd.DataFrame()
                    valid_data.append(validation_gp_df)
                valid_data.append(pd.DataFrame())
            
            if len(valid_flag)>0:
                valid_data_df = concatenate_pandas_dataframe(data_list=valid_data)
                valid_data_df = calculate_bias(data=valid_data_df, target_column='actual', pred_column='pred')
                avg_bias = valid_data_df['bias'].sum()/len(valid_data_df)
                accuracy = 100-(calculate_wape(y_true=valid_data_df['actual'],y_pred=valid_data_df['pred']))*100
            else:
                avg_bias = 0
                accuracy = 0

            if len(valid_flag)==self.no_of_cross_validation:
                flag_value = "Both"
                valid_data_dict[grp_key] = [flag_value,avg_bias,accuracy,key,model_type]
            if len(valid_flag)<self.no_of_cross_validation:
                flag_value = ",".join(valid_flag)
                valid_data_dict[grp_key] = [flag_value,avg_bias,accuracy,key,model_type]
            if len(valid_flag)==0:
                flag_value = "None"
                valid_data_dict[grp_key] = ["None",0,0]
            
        return valid_data_dict

    def get_validation_accuracy(self, model_summary):
        """
        """
        valid_data_dict = self.calculate_validation_accuracy(model_summary=model_summary)
        valid_data_df = pd.DataFrame(valid_data_dict).T
        valid_data_df.columns = ["Flag","validation_bias","validation_accuracy",'key','Model_Type']
        valid_data_df = valid_data_df.reset_index(drop=True)

        return valid_data_df

    def get_best_model(self, valid_data_df):
        """
        """
        
        best_model_df = []
        for grp_key, grp in valid_data_df.groupby(by = ['key']):
            if len(grp[grp['validation_accuracy']>0]) == 0:
                sort_by_col, asc_col = 'validation_bias',  True
            else:
                sort_by_col, asc_col = 'validation_accuracy',  False
            if len(grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 60)])>0:
                best_model = grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 60)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 50)])>0:
                best_model = grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 50)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 40)])>0:
                best_model = grp[(grp.validation_bias > -5)&(grp['train_accuracy']>= 40)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 60)])>0:
                best_model = grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 60)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 50)])>0:
                best_model = grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 50)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 40)])>0:
                best_model = grp[(grp.validation_bias > -10)&(grp['train_accuracy']>= 40)].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            elif len(grp[grp.validation_bias > -5])>0:
                best_model = grp[grp.validation_bias > -5].sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            else:
                best_model = grp.sort_values(by = sort_by_col, ascending=asc_col)['Model_Type'].iloc[0]
            grp['Best_Model'] = [best_model]*len(grp)

            best_model_df.append(grp)
        best_model_df = concatenate_pandas_dataframe(data_list=best_model_df)
        best_model_df['Label'] = best_model_df['Model_Type'] == best_model_df['Best_Model'] 
        return best_model_df
    
    def create_trend_file(self, forecast):
        """
        """
        pivot_vals = ['pred']
        if "pred_value" in forecast.columns:
            pivot_vals.append('pred_value')

        pivoted = forecast.pivot(index=['key',self.DATE_COL], 
                                columns=['Model_Type'], 
                                values=pivot_vals).reset_index()
        pivoted.columns = [f'{i}_{j}' for i, j in pivoted.columns]
        pivoted = pivoted.rename(columns={"key_":"key",
                                        f"{self.DATE_COL}_":self.DATE_COL})
        pivoted['key'] = pivoted['key'].astype(str)
        trend_data = pd.merge(pivoted, self.original_df[['key', self.DATE_COL, 'parent_material_code', 
                                                        'brand_code', 'sec_vol_actuals_rum_month', 'qtr_ind_rate',
                                                         'seasonal_month_flag', 'npd_flag', 'input_driven_month']], 
                            how="left",
                            on=["key",self.DATE_COL])
        trend_data = pivoted.copy()
        return trend_data
         
    
    def customer_rolling_function(self, df, x, suffix, target_col):
        cols = []
        for i in range(2,x+2):
            col_name = f"shift_{i}"
            cols.append(col_name)
            df[col_name] = df.sort_values(["key",self.DATE_COL],ascending=True).\
                        groupby(['key'],as_index = False)[target_col].shift(i)
        df[f'p{x}m_{suffix}']=(df.loc[:,cols].sum(axis=1,skipna=False))/len(cols)
        df.drop(cols,axis=1,inplace=True)
        return df
 
    def add_npds(self, forecast):
        """
        """

        keys_to_filter= list(set(self.original_df['key'].unique())-set(forecast['key'].unique()))
        npd_keys = self.original_df[self.original_df['npd_flag']==1]['key'].unique().tolist()
        npd_keys = list(set(npd_keys)-set(forecast['key'].unique()))

        # other keys are the keys which do no have regular sales
        other_keys = list(set(keys_to_filter)-set(npd_keys))

        npd_data = self.original_df[self.original_df['key'].isin(npd_keys)]
        other_data = self.original_df[self.original_df['key'].isin(other_keys)]

        cols_to_filter = ["key",self.DATE_COL,self.target_column]

        if self.index_rate.empty==False:
            cols_to_filter.append(f"{self.target_column}_value")

        npd_data = npd_data[cols_to_filter].drop_duplicates(keep="first")
        other_data = other_data[cols_to_filter].drop_duplicates(keep="first")

        npd_data = self.customer_rolling_function(npd_data, 3, suffix="vol", target_col=self.target_column)
        other_data_vol = other_data[other_data[self.target_column]!=0].groupby('key')[self.target_column].last().reset_index()
        if self.index_rate.empty==False:
            value_col = f"{self.target_column}_value"
            npd_data = self.customer_rolling_function(npd_data, 3, suffix="val", target_col=value_col)
            other_data_val = other_data[other_data[value_col]!=0].groupby('key')[value_col].last().reset_index()
            other_data = pd.merge( other_data_vol, other_data_val, how='left', on='key')
            other_data.columns = ['key', 'pred', 'pred_value']
        else:
            other_data = other_data_vol.copy()
            other_data.columns = ['key', 'pred']

        npd_data = npd_data[npd_data[self.DATE_COL]==min(self.actual_forecast_period)]
        npd_data.drop([self.DATE_COL, self.target_column, f"{self.target_column}_value"],axis=1,
                    inplace=True,
                    errors="ignore")
        data_range   = pd.DataFrame(pd.date_range(min(self.actual_forecast_period),
                                    max(self.actual_forecast_period),freq=self.input_dict['data_frequency']),
                                    columns=[self.DATE_COL])

        npd_data = npd_data.rename(columns={
                                 "p3m_vol":"pred",
                                 "p3m_val":"pred_value"
                                })
        npd_data = pd.merge(npd_data,data_range,how='cross',on=None)
        other_data = pd.merge(other_data,data_range,how='cross',on=None)

        npd_data = npd_data.drop_duplicates(keep="first")
        other_data = other_data.drop_duplicates(keep="first")
        npd_data["Model_Type"] = "p3m"
        other_data.loc[:, 'Model_Type'] = 'last_active_sale'
        updated_forecast = concatenate_pandas_dataframe(data_list=[forecast, npd_data, other_data])
        return updated_forecast
    
    def keys_without_forecast(self, forecast):
        """
        """
        keys_without_forecast = pd.DataFrame(set(self.original_df['key'].unique()) - set(forecast['key'].unique()),
                                            columns=['key'])
        date_range   = pd.DataFrame(self.actual_forecast_period,columns=[self.DATE_COL])
        keys_without_forecast = pd.merge(keys_without_forecast,date_range,how='cross',on=None)
        keys_without_forecast['Model_Type'] = "forecast_not_generated"
        updated_forecast = concatenate_pandas_dataframe(data_list=[forecast, keys_without_forecast])

        df_train =  self.original_df[~self.original_df[self.DATE_COL].isin(self.actual_forecast_period)]

        series_length = df_train.groupby(['key']).size().reset_index(name='series_length')
        updated_forecast = pd.merge(updated_forecast, series_length, 
                                    how="left",
                                    on=['key'])

        return updated_forecast
    
    def calculate_cov(self):
        """
        """
        cov_data = self.original_df[self.original_df[self.DATE_COL]<=self.di_model_input['train_till_date']]
        cov_data = cov_data[['key', self.DATE_COL, self.target_column]]
        cov_data = cov_data.groupby(['key'], as_index=False).agg({self.target_column:['mean','std']})
        cov_data.columns = ['key', 'mean', 'std']
        cov_data["cov"] = cov_data.apply(lambda x: x['std']/x['mean'] if x['mean'] != 0 else np.inf, axis=1)
        cov_data = cov_data[['key','cov']]
        return cov_data

    def run(self):
        """
        """
        prophet_cv_results, prophet_data = self.process_prophet_results()
        ml_cv_results, ml_data = self.process_ml_results()
        cts_cv_results, cts_data = self.process_cts_results()
        #ToDo: add dl results

        #creating cv summary
        cv_results = [prophet_cv_results, ml_cv_results, cts_cv_results]
        pipeline_cv_summary = concatenate_pandas_dataframe(data_list=cv_results)
        pipeline_cv_summary['key'] = pipeline_cv_summary['key'].astype(str)
        pipeline_cv_summary['train_till'] = self.di_model_input['train_till_date']

        if pipeline_cv_summary.empty==False:
            pipeline_cv_summary.to_csv(f"{self.location_to_save}/model_summary.csv", index=False)
        
        forecast = [prophet_data, ml_data, cts_data]
        pipeline_forecast = concatenate_pandas_dataframe(data_list=forecast)
        pipeline_forecast['key'] = pipeline_forecast['key'].astype(str)
        pipeline_forecast[self.DATE_COL] = pd.to_datetime(pipeline_forecast[self.DATE_COL])

        if self.index_rate_col:
            pipeline_forecast = pd.merge(pipeline_forecast, self.original_df[['key',self.DATE_COL,
                                                    self.index_rate_col]],
                                                    how="left",
                                                    on = ['key',self.DATE_COL])
            pipeline_forecast['pred_value'] = pipeline_forecast['pred'] * pipeline_forecast[self.index_rate_col]
            pipeline_forecast.drop([self.index_rate_col], axis=1, inplace=True)
        
        pipeline_forecast = pd.merge(pipeline_forecast, self.original_df, 
                        how="left",
                        on=['key',self.DATE_COL])

         #save trend file
        trend_data = self.create_trend_file(forecast = pipeline_forecast)
        
        test_forecast = pipeline_forecast[pipeline_forecast['type'].isin(['testing'])]
        
        #calculate train accuracy
        train_accuracy = self.get_train_accuracy(full_forecast=pipeline_forecast)
        #calculate validation accuracy
        validation_accuracy = self.get_validation_accuracy(model_summary = pipeline_cv_summary)
        #merging training and validation accuracies 
        if validation_accuracy.shape[0]==train_accuracy.shape[0]:
            cross_validation_accuracy_df = pd.merge(validation_accuracy,train_accuracy, 
                                            on=['key','Model_Type'],
                                            how="left")
        else:
            cross_validation_accuracy_df = pd.DataFrame()
        if cross_validation_accuracy_df.empty==False:
            #get best model from best model logic
            best_model_df = self.get_best_model(valid_data_df=cross_validation_accuracy_df)
            best_model_values = best_model_df[best_model_df['Best_Model']==best_model_df['Model_Type']]
            best_model_values = best_model_values[['key','Best_Model']]
            best_model_values['flag'] = 1
            best_model_values = best_model_values.rename(columns={"Best_Model":"Model_Type"})
            test_forecast = pd.merge(test_forecast,best_model_df,on=['key','Model_Type'],how="left")

            temp1 = pd.merge(test_forecast,best_model_values[['key','Model_Type','flag']],
                                on=['key','Model_Type'])
            temp1 = temp1[temp1['flag']==1]
            temp1['Model_Type'] = "Best_Model"
            temp1.drop(["flag"],axis=1,inplace=True)
            test_forecast = concatenate_pandas_dataframe(data_list=[test_forecast, temp1])
            cols_to_filter = ['key', self.DATE_COL,'pred']
            if 'pred_value' in test_forecast.columns:
                cols_to_filter.append('pred_value')
            temp2 = test_forecast[test_forecast['Model_Type']=="Best_Model"][cols_to_filter]
            temp2 = temp2.rename(columns={"pred":"pred_best_model",
                                "pred_value":"pred_value_best_model"})
            trend_data = pd.merge(trend_data,temp2,how="left",on=['key',self.DATE_COL])
        
        trend_data = pd.merge(trend_data, self.outlier_treated_data, how="left", on=['key', self.DATE_COL])
        trend_data['train_till'] = self.di_model_input['train_till_date']
        #adding coefficient of variance
        cov_data = self.calculate_cov()
        trend_data = pd.merge(trend_data, cov_data, how="left", on=['key'])
        trend_data.to_csv(f"{self.location_to_save}/trend_file_{self.suffix}.csv", index=False)

        #add npds 
        updated_test_forecast = self.add_npds(forecast=test_forecast)
        #add key for which forecast is not generated
        updated_test_forecast = self.keys_without_forecast(forecast=updated_test_forecast)
        #dropping the columns from updated test forecast 
        cols_to_drop = list(set(self.original_df.columns) - set(['key',self.DATE_COL])) 
        updated_test_forecast.drop(cols_to_drop, axis=1, inplace=True)
        updated_test_forecast = pd.merge(updated_test_forecast,
                                            self.original_df,
                                            how="left",
                                            on=['key',self.DATE_COL])
        #adding suffixes
        dates = sorted(updated_test_forecast[self.DATE_COL].unique())
        predicting_month = []
        for idx in range(len(dates)):
            if idx==0:
                val = "M"
            else:
                val = "M+"+str(idx)
            predicting_month.append(val)

        month_map = pd.DataFrame({self.DATE_COL:dates, "predicting_month":predicting_month})
        updated_test_forecast['train_till'] = self.di_model_input['train_till_date']                     
        updated_test_forecast = pd.merge(updated_test_forecast,month_map,on=self.DATE_COL,how="left")

        pipeline_forecast['train_till'] = self.di_model_input['train_till_date']
        pipeline_forecast = pd.merge(pipeline_forecast,month_map,on=self.DATE_COL,how="left")

        updated_test_forecast = pd.merge(updated_test_forecast, cov_data, how="left", on=['key'])
        updated_test_forecast.to_csv(f"{self.location_to_save}/forecast_{self.suffix}.csv", index=False)

        pipeline_forecast = pd.merge(pipeline_forecast, cov_data, how="left", on=['key'])
        pipeline_forecast.to_csv(f"{self.location_to_save}/forecast_with_training_predictions_{self.suffix}.csv", index=False)