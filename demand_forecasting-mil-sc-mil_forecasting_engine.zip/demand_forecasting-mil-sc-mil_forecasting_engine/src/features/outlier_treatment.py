"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains the outlier treatment methods.
"""
from ..helper import np, pd,os, tqdm
from ..helper import run_parallel_functions, concatenate_pandas_dataframe
from ..helper import GetGeneralPipelineInput 

class OutlierTreatmentClass(GetGeneralPipelineInput):
    """
    This function contains the function of different outlier treatment methods
    """
    def __init__(self, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)

    def outlier_treatment(self, df, Key):
        """
        This function will treat the outlier values by replacing them with the closest percentiles defined 
        in the input template on a key level

        Arguments:

            df: pandas datafrme
            - original dataframe (sales data with all the features & master data)

            Key: str
            - Defines the table name from which data to be fetched

        Return:

            data: pandas dataframe
            - contains the sales data along with all the demand drivers(treated outliers) for a key
            combination

        """
        data = df[df['key']==Key]
        selected_months = []
        for var in self.input_outlier_Values.index.levels[0]:
            lower_fence = self.input_outlier_Values.loc[var].loc['LB','Values']
            upper_fence = self.input_outlier_Values.loc[var].loc['UB','Values']
            if self.input_outlier_Values.loc[var].loc['Outlier_Treatment','Values'] == np.nan:
                Outlier_Strategy = self.input_outlier_Values.loc[var].loc['Outlier_Treatment_Default','Values']
            else:       
                Outlier_Strategy = self.input_outlier_Values.loc[var].loc['Outlier_Treatment','Values']
            if Outlier_Strategy=="Winsorization":
                cols_to_exclude_treatment = self.input_outlier_Values.loc[var].loc['Cols_to_Exclude','Values']
                if pd.isnull(cols_to_exclude_treatment)==True:
                    cols_to_exclude_treatment = []
                else:
                    cols_to_exclude_treatment = cols_to_exclude_treatment.split(",")
                if len(cols_to_exclude_treatment)>0:
                    for col in cols_to_exclude_treatment:
                        me =  data[data[col]==1][self.DATE_COL].tolist()
                        selected_months = selected_months + me
                selected_months = selected_months + self.actual_forecast_period
                selected_months = list(set(selected_months))
                lower_quantile = data[var].quantile(lower_fence)
                upper_quantile = data[var].quantile(upper_fence)
                selected_months_data = data[data[self.DATE_COL].isin(selected_months)]
                non_selected_month_data = data[~data[self.DATE_COL].isin(selected_months)]
                non_selected_month_data[var] = np.where(non_selected_month_data[var] > upper_quantile,upper_quantile,
                            np.where(non_selected_month_data[var] < lower_quantile,lower_quantile,non_selected_month_data[var]))
                data = pd.concat([selected_months_data, non_selected_month_data])
                data = data.reset_index(drop=True)
                data.sort_values([self.DATE_COL], ascending=True)
        return data

    def run(self, df):
        """
        This is the main function to execute the whole class

        Arguments:

            df: pandas dataframe
            - contains the sales data + dd

        """
        file_name = f"data_after_outlier_treatment.csv"
        outputs   = []
        if file_name not in os.listdir(self.location_to_save):
            for i in tqdm(range(0, df.key.nunique(),self.no_of_keys_to_process)):
                keys = df.key.unique()[i:i+self.no_of_keys_to_process]
                df_model_batch = df[df['key'].isin(keys)]
                output = run_parallel_functions(func = self.outlier_treatment, 
                                                df=df_model_batch, 
                                                argument_dict={},
                                                desc=f"Treating Outliers {i+1}",
                                                iter_col="key", 
                                                is_iter_idx=False, 
                                                is_df_arg=True)
                outputs.extend([res for res in output])
            df = concatenate_pandas_dataframe(data_list=outputs)
            df.to_csv(os.path.join(self.location_to_save, file_name), index=False)
        else:
            df = pd.read_csv(os.path.join(self.location_to_save, file_name))
            df[self.DATE_COL] = pd.to_datetime( df[self.DATE_COL])
            
        return df