"""
Author: Aishwarya Verma
Version: 0.0.2
Descrition: This file contains different type of method to add recency weights to the data
"""

from ..helper import np, pd
from ..helper import run_parallel_functions, concatenate_pandas_dataframe
from ..helper import GetGeneralPipelineInput

class GetRecencyFactorClass(GetGeneralPipelineInput):
    """
    This class contains different type of method to add recency weights to the data
    """
    def __init__(self, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)

    def add_exponential_recency(self, df, Key):
        """
        This function will calculate exponential recency factor for a key. 

        Arguments:

            df: pandas dataframe
            - single dataframe to be passed on to modelling phase

            Key: str
            - contains the key for which recency factor needs to be calculated

        Return:

            data_key: pandas dataframe
            - updated dataframe along with exponential recency factor for a key
        """
        # T Number of Data Points
        # x : (Current Month) - (Observed Month)
        # Current Month: M-1
        # Factor: exp(-c*x/T)

        # Without any factor
        # With exponential factor
        # Linear Factor
        # 2^-x
        df_key = df[df['key']==Key]
        df_key.sort_values([self.DATE_COL],ascending=True)
        start = 1
        end = len(df_key)
        recency_range = list(range(start, end+1))
        current_month = len(df_key)
        df_key['current_month'] = current_month
        df_key['observed_month'] = recency_range
        x_values = (df_key['current_month'] - df_key['observed_month']).tolist()
        recency = list(map(lambda x:pow(2,-x),x_values))
        df_key['recency_factor'] = recency
        df_key.drop(["current_month","observed_month"],axis=1,inplace=True)
        return df_key

    def add_linear_recency(self, df, Key):
        """
        This function will calculate linear recency factor for a key.

        Arguments:

            df: pandas dataframe
            - single dataframe to be passed on to modelling phase

            Key: str
            - contains the key for which recency factor needs to be calculated

        Return:

            data_key: pandas dataframe
            - updated dataframe along with exponential recency factor for a key
        """
        df_key = df[df['key']==Key]
        df_key.sort_values([self.DATE_COL],ascending=True)
        start = 1
        end = len(df_key)
        recency_range = list(range(start, end+1))
        df_key['recency_factor'] = recency_range
        return df_key

    def add_decay_recency(self, df, Key, c):
        """
        This function will calculate decay recency factor with C=2/4 for a key. Here,
        x ranges from  1 to total number of data points

        Arguments:

            df: pandas dataframe
            - single dataframe to be passed on to modelling phase

            Key: str
            - contains the key for which recency factor needs to be calculated

        Return:

            data_key: pandas dataframe
            - updated dataframe along with exponential recency factor for a key
        """
        # T Number of Data Points
        # x : (Current Month) - (Observed Month)
        # Current Month: M-1
        # Factor: exp(-c*x/T)
        df_key = df[df['key']==Key]
        df_key.sort_values([self.DATE_COL],ascending=True)
        start = 1
        end = len(df_key)
        recency_range = list(range(start, end+1))
    
        T = len(df_key)
        current_month = len(df_key)
        df_key['current_month'] = current_month
        df_key['observed_month'] = recency_range

        df_key['x'] = df_key['current_month'] - df_key['observed_month']

        df_key['recency_factor'] = np.exp(-c*df_key['x']/T)
        df_key.drop(['current_month','observed_month','x'],axis=1,inplace=True)
        return df_key

    def run(self, _type, df):
        """
        This is the main function to run the whole class/ different kinds of 
        recency factor methods

        Arguments:

            df: pandas dataframe
            - contains the sales + dd data
        """
        argument_dict = {}
        if _type=="Linear":
            func = self.add_linear_recency
        elif _type=="Exponential":
            func = self.add_exponential_recency
        elif _type=="C2_Decay":
            func = self.add_decay_recency
            argument_dict["c"] = 2
        else:
            if _type=="C4_Decay":
                func = self.add_decay_recency
                argument_dict["c"] = 4

        recency_factor_output = run_parallel_functions(func=func,
                                            df=df,
                                            argument_dict=argument_dict,
                                            desc="Calculating Recency Factor",
                                            iter_col = "key",
                                            is_iter_idx=False, 
                                            is_df_arg=True
                                            )
        
        df = [res for res in recency_factor_output]
        df = concatenate_pandas_dataframe(data_list=df)
        return df