
"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains all the feature selection methods
"""
from ..helper import pd, os, VarianceThreshold, mutual_info_regression, SelectPercentile
from ..helper import run_parallel_functions, concatenate_pandas_dataframe
from ..helper import GetGeneralPipelineInput

class FeatureSelectionModuleClass(GetGeneralPipelineInput):
    """
    This class will do the feature selection process
    """
    def __init__(self, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)

    def find_constant_features(self, data_key):
        """
        This function will return the columns names for which the std is zero

        Arguments:

            data_key: pandas dataframe
            - dataframe contains the sales data + dd for a single combination.
        
        Retrun:

            list: containing the name of all columns which std is zero
        """
        return [feat for feat in data_key.columns if data_key[feat].std() == 0]

    def find_quasi_constant_features(self, data_key, threshold):
        """
        This function will return the columns names for which the std <= threshold
        provided.

        Arguments:

            data_key: pandas dataframe
            - dataframe contains the sales data + dd for a single combination.

            threshold: float
            - threshold for variance which has to be taken into account

        Return:
            quasi_constant_features: list
            - names of the columns which has std<=threshold
        """
        sel = VarianceThreshold(threshold=threshold)  # 0.1 indicates 99% of observations approximately
        sel.fit(data_key)  # fit finds the features with low variance
        # Get the remaining features
        features_to_keep = data_key.columns[sel.get_support()]
        quasi_constant_features = set(data_key.columns) - set(features_to_keep)

        return quasi_constant_features

    def find_correlation(self, dataset, threshold):
        """
        this function finds and remove correlated features

        Arguments:

            dataset: pandas dataframe
            - dataframe contains the sales data + dd

            threshold: float
            - threshold to decide the correlation
        Return:

            col_corr: list
            - name of the correlated columns/or to drop


        """
        col_corr = set()  # Set of all the names of correlated columns
        corr_matrix = dataset.corr()
        for i in range(len(corr_matrix.columns)):
            for j in range(i):
                if abs(corr_matrix.iloc[i, j]) > threshold: # we are interested in absolute coeff value
                    colname = corr_matrix.columns[i]  # getting the name of column
                    col_corr.add(colname)
        return col_corr

    def basic_feature_selection_filter_methods(self, df, Key):
        """
        This function will do the basic feature selection for a key combination

        Arguments:

            df: pandas dataframe
            - contains the sales data + dd

            Key: string
            - defines the key combination for which df has to filtered for

        Return:
            
            fs_data: dictionary
            - contains the features to remove less important features for key
            combination. 

            data_key: pandas dataframe
            - updated dataframe at key level(without less important features)

        """
        data_key = df[df['key']==Key]

        data_key_copy = data_key.copy()
        data_key_copy = data_key_copy[data_key_copy[self.DATE_COL]<min(self.actual_forecast_period)]
        data_key_copy.drop([self.DATE_COL,"key",self.target_column]+\
                            self.hierarchy_features, axis=1, inplace=True)
        basic_filter_methods =  self.di_fs_input[self.di_fs_input['FS_Type']=="Filter"]

        cf_data = basic_filter_methods[basic_filter_methods['FS_Method_Choices']=="constant_features"].to_dict('records')[0]
        qcf_data = basic_filter_methods[basic_filter_methods['FS_Method_Choices']=="quasi_constant_features"].to_dict('records')[0]
        corr_data = basic_filter_methods[basic_filter_methods['FS_Method_Choices']=="correlated_features"].to_dict('records')[0]
        
        if (cf_data['Current_Value']==1) or (cf_data['Default_Value']==1):
            contant_features = list(self.find_constant_features(data_key_copy))
        else:
            contant_features = []
        
        if (qcf_data['Current_Value']==1) or (qcf_data['Default_Value']==1):
            threshold = qcf_data['Threshold']
            quasi_constant_features = list(self.find_quasi_constant_features(data_key_copy, threshold))
        else:
            quasi_constant_features = []
        
        if (corr_data['Current_Value']==1) or (corr_data['Default_Value']==1):
            threshold = corr_data['Threshold']
            correlated_features = list(self.find_correlation(data_key_copy, threshold = threshold))
        else:
            correlated_features = []


        features_to_drop = list(set(contant_features + quasi_constant_features + correlated_features))

        data_key.drop(features_to_drop, axis=1,inplace=True)

        fs_data = {
                    "key":Key,
                    "contant_features":contant_features,
                    "quasi_constant_features":quasi_constant_features,
                    "correlated_features":correlated_features,
                    "features_to_drop":features_to_drop
                }

        return fs_data, data_key



    def mutual_information_gain_filter_method(self, data, mig_data, to_drop):
        """
        This function will calculate the mutual information gain based on the percentile provided
        in the input template.
        (Selecting top percentile features for a key combination)
        Arguments:

            data: pandas dataframe
            - contains the sales data + dd

            mig_data: dictionary
            - paramter values for mutual information gain method

            to_drop: list
            - list of columns to drop while running mutual information gain method

        Return:

            fs_data: dictionary
            - contains the features to remove less important features for key
            combination. 
        """
        k_best_features = SelectPercentile(mutual_info_regression, percentile=mig_data['k_percentile']).fit(data.drop(to_drop,
                                        axis=1,), data[self.target_column])

        k_best_features_name = data.drop(to_drop,axis=1).columns[k_best_features.get_support()].tolist()
        fs_data = {
                    "key":data['key'].values[0],
                    "k_best_featues":k_best_features,
                    "k_best_features_name":k_best_features_name,
                    "type":"mutual_information_gain"
                }
        
        return fs_data


    def feature_selection_filter_methods(self, data, filter_methods, to_drop):
        """
        This function contains filter methods for feature selection

        Arguments:

            data: pandas dataframe
            - contains the sales data + dd

            filter_methods: pandas dataframe
            - contains the parameters value for different filter feature selection methods

            to_drop: list
            - list of columns to drop while running mutual information gain method

        Return:

            fs_data: dictionary
            - contains the features to remove less important features for key
            combination. 

        """


        mig_data = filter_methods[filter_methods['FS_Method_Choices']=="mutual_information_gain"].to_dict('records')[0]

        if (mig_data['Current_Value']==1) or (mig_data['Default_Value']==1):
            output = self.mutual_information_gain_filter_method(data=data, mig_data=mig_data, to_drop=to_drop)
        
        return output


    def feature_selection_wrapper_methods(self, data, wrapper_methods):
        """
        """
        pass


    def run_advanced_feature_selection_methods(self, df, Key):
        """
        This function contains the advanced methods of features selection for 
        a key combination

        Arguments:

            df: pandas dataframe
            - contains the sales + dd data

            Key: string
            - defines the key combination for which df has to be filtered for.
        """
        data_key = df[df['key']==Key]

        data_key_copy = data_key.copy()
        data_key_copy = data_key_copy.dropna(axis=1, how='all')
        data_key_copy = data_key_copy[data_key_copy[self.DATE_COL]<min(self.actual_forecast_period)]
        to_drop = [self.DATE_COL,"key",self.target_column]

        filter_methods =  self.di_fs_input[self.di_fs_input['FS_Type']=="Filter"]
        wrapper_methods = self.di_fs_input[self.di_fs_input['FS_Type']=="Wrapper"]

        if any(filter_methods['Current_Value']==1) or any(filter_methods['Default_Value']==1):
            output = self.feature_selection_filter_methods(data=data_key_copy, filter_methods=filter_methods, to_drop = to_drop)
        
        else:
            if any(wrapper_methods['Current_Value']==1) or any(wrapper_methods['Default_Value']==1):

                output = self.feature_selection_wrapper_methods(data=data_key_copy, wrapper_methods=wrapper_methods, to_drop = to_drop)
        return output


    def run_basic_feature_selection_process(self, df):
        """
        This function contains the basic feature selection method for all keys

        Arguments:

            df: pandas dataframe
            - contains the sales data + dd

        Return:

            df: pandas dataframe
            - updated dataframe with less features removed on key level.
        """
        if self.di_model_input['Model_Feature_Selection']==1:
            
            file_name = "data_after_feature_selection.csv"

            if file_name not in os.listdir(self.location_to_save):
                feature_selection_output = run_parallel_functions(func = self.basic_feature_selection_filter_methods, 
                                                                df = df, 
                                                                argument_dict={}, 
                                                                desc="Basic Feature Selection",
                                                                iter_col="key", 
                                                                is_iter_idx=False, 
                                                                is_df_arg=True
                                                                )

                feature_selection_data = [res[0] for res in feature_selection_output]
                feature_selection_data = pd.DataFrame(feature_selection_data)
                feature_selection_data =feature_selection_data.reset_index(drop=True)
                feature_selection_data.to_csv(f"{self.location_to_save}/basic_filter_feature_selection_data.csv",index=False)

                df_updated = [res[1] for res in feature_selection_output]
                df = concatenate_pandas_dataframe(data_list=df_updated)
                df.to_csv(os.path.join( self.location_to_save, file_name), index=False)
            else:
                df = pd.read_csv(os.path.join( self.location_to_save, file_name))
                df.loc[:, self.DATE_COL] = pd.to_datetime(df.loc[self.DATE_COL])
        return df