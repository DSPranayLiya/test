""" Prepare the training data from raw data to also add the demand derivers.
"""


from ..helper import os, pd, tqdm, Path, datetime, tqdm, \
                    MonthEnd, relativedelta, Parallel, delayed, cpu_count

from .fetch_snowflake_table_data import FetchSnowflakeData


class PrepMasterData:
    """
        Prepare the final MIL data for modelling.
    """
    def __init__(self, input_dict, config) -> None:
        """_summary_

        Args:
            input_dict ( dict): dictionary containing input template data
            config (_type_): _description_
        """
        self.MIL_DF_TABLE = config.MIL_DATA_SNOWFLAKE_TABLE
        self.RUN_MONTH = config.RUN_MONTH
        self.start_date = config.START_DATE
        self.channel = config.CHANNEL_NAME
        

        self.snowflake_conn  = FetchSnowflakeData()
        self.di_model_input = input_dict['input_template_data_processed']["di_model_input"]
        
        self.granularity = [ 'asm_area_code', 'depot_code', 'parent_material_code']
        self.end_date = str(self.di_model_input['train_till_date'].date())
        
        self.future_data_points = self.di_model_input['buffer_horizon'] + self.di_model_input['forecast_horizon']
        curr_month, curr_year = datetime.now().month, str(datetime.now().year)[-2:]
        curr_month = config.MONTH_DICT[curr_month] + "'" + curr_year
        self.path = f"./data/model_input_data/{curr_month}/"
        self.master_data_file = f"{self.channel.lower()}_mil_data_updated.csv"
        

    def realign_pskus( self, data):
        """
        Realign the old pskus to new pskus and return updated data.

        Args:
            data: pandas dataframe
            - master dataframe having all the pskus
        
        Return:
            data: pandas dataframe
            - dataframe 
        """
        realignment_data = self.snowflake_conn.fetch_mil_table_from_db( table_name='TRN_MIL_ASM_PSKU_REALIGNMENT')
        realignment_data = realignment_data[
            (realignment_data["channel"] == self.channel)
            | (realignment_data["channel"] == self.channel + " B2C")
        ]

        data["parent_material_code"] = data["parent_material_code"].astype(int)

        for grp, grp_data in realignment_data.groupby(by=["PSKU OLD", "asm"]):
            old_psku, old_asm = grp
            new_psku = grp_data["PSKU NEW"].values[0]
            if old_asm != "All":
                condition = (data["parent_material_code"] == old_psku) & (
                    data["asm_area_code"] == old_asm
                )
            else:
                condition = data["parent_material_code"] == old_psku

            data.loc[condition, "parent_material_code"] = new_psku


        data = data.groupby(
            ["asm_area_code", "depot_code", "parent_material_code", "month_date"],
            as_index=False,
        )[["sec_vol_actuals_rum_month", "sec_vol_apo_plan_rum_month"]].agg(sum)

        return data


    def discard_non_active_keys( self, data):
        """
        This function Remove the keys from the data which are
        not active in last 10 months or have very less data
        points.

        Args:
            data: pandas dataframe
            - master dataframe with all the keys
        Return:
            filtered_data: pandas dataframe
            - data after removing the keys from the main data
        """

        print("Discard Non Active Keys ...")
        print(f" Number of keys : { data['key'].nunique()}")

        cutoff_month = pd.to_datetime( self.end_date) - relativedelta(months=10)
        active_keys = data[
            (data["month_date"] >= cutoff_month) & (data["sec_vol_actuals_rum_month"] > 0)
        ]["key"].tolist()
        data = data[data["key"].isin(active_keys)]

        filtered_data = pd.DataFrame()
        discarded_keys = []

        for grp_name, df in tqdm(data.groupby("key")):
            df.reset_index(drop=True, inplace=True)
            # filtering the initial 0 sales values
            df = df.loc[df["sec_vol_actuals_rum_month"].ne(0).idxmax() :]
            if len(df) > 9 and len(df[df["sec_vol_actuals_rum_month"] == 0]) != len(df):
                filtered_data = pd.concat([filtered_data, df], axis=0, ignore_index=True)
            else:
                discarded_keys.append(grp_name)

        return filtered_data


    def impute_missing_month( self, active_sales: pd.DataFrame, Key: str, months_to_add: int) -> pd.DataFrame:
        """
        This function add the future missing months for each Key data.

        Args:
            active_sales: pandas dataframe
            - sales data consisting all Key's data

            Key: string
            - Key for which missing month to be added

            months_to_add: int
            - number of months to be added to the Key level data

        Return:
            data_key_updated: pandas dataframe
            - key level data with future months added
        """

        if pd.isna(Key) == False:
            data_key = active_sales[active_sales["key"] == Key]
            max_date = (
                active_sales["month_date"].max()
                + relativedelta(months=months_to_add)
                + pd.offsets.MonthEnd(0)
            )
            min_date = data_key["month_date"].min() + pd.offsets.MonthEnd(0)

            date_range = pd.DataFrame(
                pd.date_range(min_date, max_date, freq="M"), columns=["month_date"]
            )
            date_range["month_date"] = date_range["month_date"] + pd.offsets.MonthEnd(0)
            date_range["key"] = Key
            data_key_updated = pd.merge(
                date_range, data_key, how="left", on=["month_date", "key"]
            )

            # forward fill the columns
            for col in [
                "asm_area_code",
                "depot_code",
                "parent_material_code",
                "npd_flag"
            ]:
                data_key_updated[col] = data_key_updated[col].fillna(method="ffill")

            # fill the future months sales with 0
            data_key_updated["sec_vol_actuals_rum_month"].fillna(0, inplace=True)
        return data_key_updated


    def add_qtr_idx_col( self, data):
        """
        Fetch the quarter index data from the database and merge it with input data.

        Arg:
            data: pandas dataframe
            - dataframe consist the master data

        Return:
            data_with_qir: pandas dataframe
            - input data with quarter index rate added
        """

        material_master = self.snowflake_conn.get_material_master_table()
        qtr_ind_rate = self.snowflake_conn.read_qtr_ind_rate_table()

        material_master = material_master[
            ["PSKU", "material_group_code", "material_group_desc"]
        ].drop_duplicates(keep="first")
        
        material_master = material_master.drop_duplicates(subset=["PSKU"], keep="first")
        material_master = material_master.rename(columns={'PSKU':'parent_material_code', "material_group_code": "brand_code"})

        material_master["parent_material_code"] = material_master["parent_material_code"].astype(int)
        data["parent_material_code"] = data["parent_material_code"].astype(int)

        data["sec_vol_actuals_rum_month"] = data["sec_vol_actuals_rum_month"].apply(
            lambda x: 0 if x < 0 else x
        )
        data = pd.merge(
            data,
            material_master[["parent_material_code", "brand_code"]],
            on="parent_material_code",
            how="left",
        )

        qtr_ind_rate = qtr_ind_rate.rename(columns={"brand": "brand_code"})
        qtr_ind_rate = qtr_ind_rate.drop_duplicates(subset=["brand_code", "month_date"], keep="first")
        qtr_ind_rate["month_date"] = pd.to_datetime(qtr_ind_rate["month_date"]) + MonthEnd(0)
        data["month_date"] = pd.to_datetime(data["month_date"]) + MonthEnd(0)

        data_with_qir = pd.merge(
            data,
            qtr_ind_rate.drop(["fy_ind_rate"], axis=1, errors='ignore').rename(
                columns={"brand": "brand_code"}
            ),
            on=["brand_code", "month_date"],
            how="left",
        )

        assert len(data_with_qir) == len(data)
        return data_with_qir


    def add_raw_material_prices( self, df, raw_material_brand_code_mapping, raw_material_price_df):
        """
        Fetch the raw material prices from the raw material price file.

        Args:
            df: pandas dataframe
            - master data

            raw_material_brand_code_mapping: pandas dataframe
            - raw material mapped to the brands

            raw_material_price_df: pandas dataframe
            - raw material price information dataframe

        Return:
            final_df: pandas dataframe
            - dataframe having the raw material prices added to the input df
        """
        output_df = pd.DataFrame()
        initial_df_len = len(df)
        raw_material_price_df = raw_material_price_df.T.reset_index()
        raw_material_price_df = raw_material_price_df.rename(
            columns=raw_material_price_df.iloc[0]
        ).drop(raw_material_price_df.index[0])
        raw_material_price_df["Month"] = pd.to_datetime(
            raw_material_price_df["Month"]
        ) + pd.tseries.offsets.MonthEnd(0)

        raw_material_brand_code_mapping = raw_material_brand_code_mapping.dropna(
            subset=["brand_code", "raw_material"]
        )

        raw_material_price_col_mapping = {
            "LP": "LP Buying rate Rs. per Ltr",
            "Copra": "Copra Buying rate Rs. per KG",
            "RBO": "RBO Buying rate Rs. per KG",
        }

        for raw_material in raw_material_brand_code_mapping["raw_material"].unique():
            print("Working on raw material {} ...".format(raw_material))
            unique_brands = raw_material_brand_code_mapping[
                raw_material_brand_code_mapping["raw_material"] == raw_material
            ]["brand_code"].tolist()
            for brand_name in unique_brands:
                print("Adding Raw material Prices to brand : {}".format(brand_name))

                brand_data = df[df["brand_code"] == brand_name]

                rm_price_col = raw_material_price_col_mapping[raw_material]
                rm_prices_data = raw_material_price_df[["Month", rm_price_col]].rename(
                    columns={"Month": "month_date", rm_price_col: "rm_price"}
                )

                brand_data = pd.merge(
                    brand_data, rm_prices_data, on="month_date", how="left"
                )

                df.drop(df[df["brand_code"] == brand_name].index, inplace=True)
                df.reset_index(drop=True, inplace=True)

                output_df = output_df.append(brand_data.reset_index(drop=True))

        assert initial_df_len == (len(output_df) + len(df))
        final_df = pd.concat([output_df, df], ignore_index=True, axis=0)
        return final_df


    def add_ec_pc_data( self, data):
        """
        Merge the ec pc data to the data.

        Arg:
            data: pandas dataframe
            - monthly sales data

        Return:
            df: pandas dataframe
            - input dataframe with ec pc columns added
        """
        df = data.copy()
        ec_pc_data = self.snowflake_conn.get_ec_pc_data( start_date= self.start_date,\
                                                         end_date=self.end_date,\
                                                         CHANNEL_NAME=self.channel)
        ec_pc_data = ec_pc_data[~ec_pc_data["parent_material_code"].isna()]
        ec_pc_data["key"] = (
            ec_pc_data["asm_area_code"]
            + "_"
            + ec_pc_data["depot_code"]
            + "_"
            + ec_pc_data["parent_material_code"].astype(int).astype(str)
        )

        ec_pc_data = ec_pc_data[["key", "month_date", "ec", "pc"]]
        ec_pc_data["month_date"] = pd.to_datetime(ec_pc_data["month_date"])
        df["month_date"] = pd.to_datetime(df["month_date"])
        df = pd.merge(df, ec_pc_data, on=["key", "month_date"], how="left")

        assert len(df) == len(data)
        return df


    def classify_co_type( self, co_value):
        co_output = 0
        if pd.isna( co_value) == False:
            co_value = co_value.lower().strip()
            if " " in co_value:
                co_value = "".join( co_value.split(" "))

            if any([ '+' in co_value, 'combo' in co_value, 'extraquantity' in co_value]) :
                co_output = 'extra_qty_co'     
            
            elif 'priceoff' in co_value:
                co_output = 'price_off_co'
            
            elif pd.isna( co_value)== False:
                co_output = 'other_co'

        return co_output


    def add_co_to_cols( self, data):
        """
        Add the CO and TO columns to the master data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - input data with added CO and TO columns
        """
        df = data.copy()

        co_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_CO_DATA')
        co_data = co_data[co_data['channel'] == self.channel]
        co_data = co_data.rename( columns= {'regionhierarchy':'asm_area_code'})
        co_data = co_data.replace( { True:1 , False:0})
        co_data = co_data[[ "month_date", 'asm_area_code', "parent_material_code", 'extra_vol_co', 'price_off_co', 'other_co']]
        co_data = co_data.drop_duplicates(subset=["month_date", 'asm_area_code', "parent_material_code"], keep="first")

        co_data = co_data.fillna(0)
        co_data["month_date"] = pd.to_datetime(co_data["month_date"])
        data["month_date"] = pd.to_datetime(data["month_date"])

        co_data = co_data.drop_duplicates(
            subset=[
                "month_date",
                "parent_material_code",
            ],
            keep="first",
        )

        data = pd.merge(
            data,
            co_data,
            on=["month_date", 'asm_area_code',"parent_material_code"],
            how="left",
        )

        assert len(df) == len(data)

        
        if self.channel == 'GT':
            to_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_GT_BTL')
            print(to_data.head())
            to_data = to_data.drop_duplicates(subset=["month_date", 'asm_area_code',"parent_material_code"], keep="first" )
            to_data["month_date"] = pd.to_datetime(to_data["month_date"])
            to_data = to_data.drop_duplicates(subset=[
                                                    "month_date",
                                                    'asm_area_code',
                                                    "parent_material_code",
                                                ],
                                                keep="first")
            data = pd.merge(
                            data,
                            to_data,
                            on=["month_date", 'asm_area_code', "parent_material_code", ],
                            how="left",
                        )

        assert len(df) == len(data)
        return data


    def add_seasonal_month_col(self, data):
        """
        Add the seasonal month flag column to the master data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - input data with seasonal month flag column
        """
        len_data = len(data)
        seasonal_month_dict = {
            "Apr to June": [4, 5, 6],
            "Sep to Feb": [9, 10, 11, 12, 1, 2],
        }

        data["seasonal_month_flag"] = 0
        data["Month"] = pd.to_datetime(data["month_date"]).dt.month

        seasonal_data = self.snowflake_conn.fetch_mil_table_from_db('MST_MIL_SEASONAL_MONTHS')
        for key, grp in seasonal_data.groupby(by=["seasonal_month"]):
            pskus = grp["parent_material_code"].tolist()
            months = seasonal_month_dict[key]
            data.loc[
                (data["parent_material_code"].isin(pskus)) & (data["Month"].isin(months)),
                "seasonal_month_flag",
            ] = 1

        data.drop("Month", axis=1, inplace=True)
        assert len(data) == len_data
        return data


    def update_future_mrp( self, data, train_till_date):
        """
        Append the future month MRP changes to the historical MRP column.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

            train_till_date: string
            - date till the month data training will be done in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with updated MRP column for future months
        """
        future_mrp_data = future_mrp_data.dropna()
        future_mrp_data.rename(
            columns={"New.Parent.KU": "parent_material_code"}, inplace=True
        )
        future_mrp_data = future_mrp_data.drop_duplicates(
            subset=["asm_area_code", "parent_material_code"], keep="first"
        )
        for key, data in tqdm(
            future_mrp_data[["asm_area_code", "parent_material_code", "NEW_MRP"]].groupby(
                ["asm_area_code", "parent_material_code"]
            )
        ):
            asm, psku = key
            condition = [
                data["asm_area_code"] == asm,
                data["parent_material_code"] == psku,
                data["month_date"] > train_till_date,
            ]
            data.loc[all(condition), "Weighted_MRP"] = data["NEW_MRP"].iloc[0]
        return data


    def add_mrp_col( self, data, start_date, end_date):
        """
        Add the historical MRPs and future MRP's to the data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

            start_date: string
            - start date by which the MRP information needed to be fetched in yyyy-mm-dd format

            end_date: string
            - date till the MRP data is going to be fetched in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with MRP information added
        """

        historical_mrp_data = self.snowflake_conn.get_historical_mrp_data(
            start_date=start_date, end_date=end_date, channel="GT"
        )
        historical_mrp_data = historical_mrp_data.rename(columns={'parent_material1_code':'parent_material_code'})


        historical_mrp_data["month_date"] = pd.to_datetime(
            historical_mrp_data["month_date"]
        )

        historical_mrp_data['key'] = historical_mrp_data[self.granularity].astype(str).agg("_".join, axis=1)
        historical_mrp_data = historical_mrp_data.groupby(
            ["month_date", "key"],
            as_index=False,
        ).agg({"Total_Volume": "sum", "MRP_Sale_Vol": "sum", "AVG_MRP": "mean"})
        historical_mrp_data["Weighted_MRP"] = (
            historical_mrp_data["MRP_Sale_Vol"] / historical_mrp_data["Total_Volume"]
        )

        historical_mrp_data["month_date"] = historical_mrp_data["month_date"].astype(str)
        data["month_date"] = data["month_date"].astype(str)

        data = pd.merge(
            data,
            historical_mrp_data[["month_date", "key", "Weighted_MRP"]],
            on=["key", "month_date"],
            how="left",
        )
        # data = update_future_mrp(data=data.copy(), train_till_date=end_date)

        data = data.rename( columns= {'Weighted_MRP': 'MRP'})
        return data


    def add_grp_spends_data( self, data):
        """
        This function adds the information of GRP and Spends to the master data

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - master data with added GRP and Spends column
        """
        data_length = len(data)

        customer_master = self.snowflake_conn.get_customer_master_table( channel=self.channel)
        grp_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_GRP')

        grp_data.rename(
            columns={
                "material_group_code": "brand_code",
            },
            inplace=True,
        )
        
        data["depot_brand_comb"] = data["depot_code"] + "_" + data["brand_code"]
        grp_customer_master = customer_master[["depot_code", "depot_name"]]
        grp_customer_master["depot_name"] = grp_customer_master["depot_name"].str.upper()
        grp_customer_master = grp_customer_master.drop_duplicates( subset=["depot_code"], keep="first")

        data = pd.merge(data, grp_customer_master, on="depot_code", how="left")
        data["DEPOT_BRAND"] = data["depot_name"] + "_" + data["brand_code"]
        grp_data["DEPOT_BRAND"] = grp_data["depot_name"] + "_" + grp_data["brand_code"]

        data[ 'month_date'] = pd.to_datetime( data['month_date'])
        grp_data[ 'month_date'] = pd.to_datetime( grp_data['month_date'])

        data = pd.merge(
            data,
            grp_data.drop(["brand_code", "depot_name"], axis=1),
            on=["DEPOT_BRAND", "month_date"],
            how="left",
        )

        # merge spends data
        spends_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_SPENDS')
        spends_data["DEPOT_BRAND"] = (
            spends_data["depot_name"].astype(str)
            + "_"
            + spends_data["material_group_code"].astype(str)
        )
        spends_data['month_date'] = pd.to_datetime(spends_data['month_date'])
        data = pd.merge(
                        data,
                        spends_data.drop(["material_group_code", "depot_name"], axis=1),
                        on=["DEPOT_BRAND", "month_date"],
                        how="left",
                )
        
        data.drop(["DEPOT_BRAND"], axis=1, inplace=True)
        assert len(data) == data_length
        return data


    def fill_data_future_months( self, df, Key):
        """
        This function forward fill the demand derivers ( EC, PC, rm_price, qtr_ind_rate)
        for the forecasting months. EC, PC & fill_rate information is forward filled by
        P3M average value and qtr_ind_rate is forward filled simply.

        Args:
            df: pandas dataframe
            - master data having sales and other demand derivers

            Key: string
            - Key for which data is filtered and forward filling is done

            train_till_date: string
            - date till the month data training will be done in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with forward filled columns
        """
        train_till_date = pd.to_datetime(self.end_date)
        p3m_months = [
            str(date.date())
            for date in pd.date_range(
                train_till_date - relativedelta(months=3), train_till_date, freq="M"
            )
        ]
        data = df[df["key"] == Key].copy()

        if self.channel == "GT":
            ec_p3m = data[data["month_date"].isin(p3m_months)]["ec"].mean()
            pc_p3m = data[data["month_date"].isin(p3m_months)]["pc"].mean()
            data.loc[data["month_date"] > train_till_date, "ec"] = ec_p3m
            data.loc[data["month_date"] > train_till_date, "pc"] = pc_p3m
            data["MRP"] = (
                data["MRP"].fillna(method="ffill").fillna(method="bfill")
            )

        if self.channel != "GT":
            fillrate_p3m = data[data["month_date"].isin(p3m_months)]["fill_rate"].mean()
            data.loc[data["month_date"] > train_till_date, "fill_rate"] = fillrate_p3m

        # data["rm_price"] = data["rm_price"].fillna(method="ffill").fillna(method="bfill")
        data["qtr_ind_rate"] = (
            data["qtr_ind_rate"].fillna(method="bfill").fillna(method="ffill")
        )

        return data


    def add_fill_rate_data( self, data):
        """
        Add fill rate column to MT and ECOM data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - input data with added fill rate column

        """
        initial_data_length = len(data)
        channel = self.channel
        if channel == "ECOM":
            channel = "E-Commerce"

        # for fill_rate in
        fill_rate_df = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_FILL_RATE')

        fill_rate_df["month_date"] = pd.to_datetime(fill_rate_df["month_date"]) + MonthEnd(0)


        fill_rate = fill_rate_df[ fill_rate_df['channel'] == channel]
        fill_rate = fill_rate.drop_duplicates(keep="first")

        fill_rate["order_qty"], fill_rate["invoice_qty"] = fill_rate["order_qty"].astype(
            float
        ), fill_rate["invoice_qty"].astype(float)

        fill_rate["key"] = fill_rate[ self.granularity].astype(str).agg("_".join, axis=1)

        fill_rate = (
            fill_rate.groupby(["month_date", "key"])
            .agg({"order_qty": "sum", "invoice_qty": "sum"})
            .reset_index()
        )

        fill_rate["fill_rate"] = fill_rate["invoice_qty"] / fill_rate["order_qty"]
        fill_rate.loc[ fill_rate['fill_rate']>1,'fill_rate'] = 1

        data = pd.merge(data, fill_rate, how="left", on=["month_date", "key"])
        data.drop( [ 'invoice_qty', 'order_qty'], inplace=True, axis=1)
        assert( len(data) == initial_data_length)
        return data

    def add_festival_flags( self, master_data: pd.DataFrame):
        """
            Add festival flags into the data.
        """
        festivals_data = self.snowflake_conn.fetch_mil_table_from_db( table_name='MST_MIL_FESTIVAL_DATA')
        festivals_data['month_date'] = pd.to_datetime( festivals_data['month_date']) + MonthEnd(0)
        festivals = festivals_data['festival'].unique().tolist()
        for festival in festivals:
            master_data[festival] = 0
            festival_month = festivals_data[festivals_data['festival']==festival]['month_date']
            master_data.loc[master_data['month_date'].isin(festival_month), festival] = 1
        return master_data

    def fill_na_values(self, master_data: pd.DataFrame):
        """
        This function fill the na values of the columns
        Args:
            master_data (pd.DataFrame): data with all the demand derivers
        """
        
        final_data  = pd.DataFrame()
        for key in tqdm(master_data['key'].unique()):
            key_data = master_data[master_data['key']==key]
            for col in [ 'extra_vol_co', 'price_off_co', 'other_co']:
                key_data.loc[:,col] = key_data[col].fillna(0)
            if self.channel != 'GT':
                key_data.loc[:, 'fill_rate'] = key_data[ 'fill_rate'].fillna(method='ffill').fillna(method='bfill')
            if self.channel == 'GT':
                key_data.loc[:, 'MRP'] = key_data[ 'MRP'].fillna(method='ffill').fillna(method='bfill')
            final_data = pd.concat([final_data, key_data], ignore_index=True, axis=0)
        return final_data
    
    def prepare_master_data( self):
        """
            Prepare the final model training data.
        """

        # if the data is already present in the table of not.
        data_check_query = f"""SELECT DISTINCT("RUN_MONTH") FROM {self.MIL_DF_TABLE} where channel = '{self.channel}'"""
        run_months = self.snowflake_conn.fetch_mil_table_from_db(query=data_check_query)['run_month'].tolist()

        if self.RUN_MONTH in run_months:
            print("*"*100)
            print(f"Training Data Already Present For Run Month: {self.RUN_MONTH}")
            print("*"*100)
            return False

        else:
            non_active_pskus_data = self.snowflake_conn.fetch_mil_table_from_db( "TRN_MIL_INACTIVE_PSKU")
            non_active_pskus_list = list(non_active_pskus_data["parent_material_code"].unique())

            channel = self.channel
            if channel == "ECOM":
                channel = "E-Commerce"

            print(f"Fetching Historical Data...")
            sales_data = self.snowflake_conn.get_historical_sales( start_date=self.start_date, end_date= self.end_date, channel=channel)

            # data = sales_data.copy()
            print(sales_data.head())


            print(f"\n Realigning the SKUs...")
            sales_data = self.realign_pskus( data=sales_data.copy())

            filtered_sales_data = sales_data.copy()
            filtered_sales_data = filtered_sales_data[ ~filtered_sales_data["parent_material_code"].isin(non_active_pskus_list)]
            filtered_sales_data['key'] = filtered_sales_data[self.granularity].astype(str).agg("_".join, axis=1)
            filtered_sales_data = filtered_sales_data.drop_duplicates( subset=["month_date", "key"], keep="first" )

            # add npd flag
            npd_pskus = self.snowflake_conn.fetch_mil_table_from_db(table_name='TRN_MIL_NPD_PSKUS')
            npd_pskus_list = npd_pskus["new_psku"].astype(int).unique().tolist()

            filtered_sales_data["npd_flag"] = 0
            filtered_sales_data.loc[ filtered_sales_data["parent_material_code"].astype(int).isin(npd_pskus_list), "npd_flag"] = 1

            # removing non-active keys
            filtered_sales_data = self.discard_non_active_keys(filtered_sales_data)

            # impute future month sales data
            filtered_sales_data["month_date"] = pd.to_datetime( filtered_sales_data["month_date"])

            print(f"Imputing future months...")
            Impute_Missing_Months = Parallel(n_jobs=cpu_count() // 2, prefer="threads")(
                delayed(self.impute_missing_month)(filtered_sales_data, Key, self.future_data_points)
                for Key in tqdm(filtered_sales_data.key.unique())
            )
            filtered_sales_data = pd.concat(Impute_Missing_Months)

            # Add QTR IND RATE COL
            filtered_sales_data = self.add_qtr_idx_col(data=filtered_sales_data.copy())

            # Add raw material col
            # filtered_sales_data = add_raw_material_prices(
            #     filtered_sales_data.copy(),
            #     raw_material_brand_code_mapping,
            #     raw_material_price_df,
            # )

            filtered_sales_data.sort_values(by=["key", "month_date"], inplace=True)

            # Free Psku Tag
            filtered_sales_data["Free"] = 0
            free_pskus_list = self.snowflake_conn.fetch_mil_table_from_db( table_name='TRN_MIL_FREE_PSKU' )["psku_code"].tolist()
            filtered_sales_data.loc[ filtered_sales_data["parent_material_code"].isin(free_pskus_list), "Free"] = 1

            print( "Number of rows with free skus: {}".format( len(filtered_sales_data[filtered_sales_data["Free"] == 1]))) 

            # Add CO TO Cols
            filtered_sales_data = self.add_co_to_cols(filtered_sales_data.copy())

            # Add Seasonal Month Col
            filtered_sales_data = self.add_seasonal_month_col(filtered_sales_data.copy())

            # Adding historical MRP data
            if self.channel == "GT":
                filtered_sales_data = self.add_mrp_col(
                    data=filtered_sales_data.copy(), start_date= self.start_date, end_date=self.end_date
                )
                filtered_sales_data = self.add_grp_spends_data(filtered_sales_data.copy())
                filtered_sales_data = self.add_ec_pc_data(filtered_sales_data.copy())
            else:
                filtered_sales_data = self.add_fill_rate_data(filtered_sales_data.copy())

            # fill data for forecast months
            filtered_sales_data["month_date"] = pd.to_datetime(
                filtered_sales_data["month_date"]
            )

            print(f"Fill Null Values for future months...")
            Fill_forward_data = Parallel(n_jobs=cpu_count() // 2, prefer="threads")(
                delayed(self.fill_data_future_months)( filtered_sales_data,Key)
                for Key in tqdm(filtered_sales_data.key.unique())
            )
            
            master_data = pd.concat(Fill_forward_data, axis=0)
            
            master_data = self.fill_na_values(master_data=master_data.copy())

            to_drop_cols = [ "key", "ASM_PSKU", "PSKU", "DEPOT_BRAND", "sec_vol_apo_plan_rum_month",'order_qty', 'invoice_qty',
                            "Brand", "depo_brand_comb", "depot_name", "Unnamed: 0", "Channel", 'depot_brand_comb']
            master_data = master_data.drop(to_drop_cols, axis=1, errors = 'ignore')

            master_data = self.add_festival_flags( master_data.copy())
            master_data.columns = [ "_".join(col.split(" ")).lower()  if " " in col else col.lower() for col in master_data.columns]
            master_data['channel' ] = self.channel
            master_data.drop_duplicates(keep="first", inplace=True)
            Path(self.path).mkdir(parents=True, exist_ok=True)
            master_data.to_csv(os.path.join(self.path, self.master_data_file), index=False)

            return True

