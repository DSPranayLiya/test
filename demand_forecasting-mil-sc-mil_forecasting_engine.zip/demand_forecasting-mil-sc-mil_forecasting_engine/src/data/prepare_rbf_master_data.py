""" Prepare the training data from raw data to also add the demand derivers.
"""


from ..helper import os, pd, tqdm, Path, datetime, tqdm, \
                    MonthEnd, relativedelta, Parallel, delayed, cpu_count

from .fetch_snowflake_table_data import FetchSnowflakeData


class PrepRBFMasterData:
    """
        Prepare the final MIL data for modelling.
    """
    def __init__(self, input_dict, config) -> None:
        """_summary_

        Args:
            input_dict ( dict): dictionary containing input template data
            config (_type_): _description_
        """
        self.MIL_DF_TABLE = config.MIL_DATA_SNOWFLAKE_TABLE
        self.MIL_RBF_DATA_SNOWFLAKE_TABLE = config.MIL_RBF_DATA_SNOWFLAKE_TABLE
        self.RUN_MONTH = config.RUN_MONTH
        self.start_date = config.START_DATE
        self.channel = config.CHANNEL_NAME
        self.forecast_period  = input_dict['cutoffs']['actual_forecast_period']
        

        self.snowflake_conn  = FetchSnowflakeData()
        self.di_model_input = input_dict['input_template_data_processed']["di_model_input"]
        self.brands_data = input_dict['brands_data']
        
        self.granularity = [val.strip() for val in self.di_model_input['Granularity'].split(',')]
        self.end_date =  self.di_model_input['train_till_date'].date()
        
        self.future_data_points = self.di_model_input['buffer_horizon'] + self.di_model_input['forecast_horizon']
        curr_month, curr_year = datetime.now().month, str(datetime.now().year)[-2:]
        curr_month = config.MONTH_DICT[curr_month] + "'" + curr_year
        self.path = f"./data/model_input_data/{curr_month}/"
        self.master_data_file = f"{self.channel.lower()}_mil_rbf_data_updated.csv"
    

    def add_ec_pc_data( self, data):
        """
        Merge the ec pc data to the data.

        Arg:
            data: pandas dataframe
            - monthly sales data

        Return:
            df: pandas dataframe
            - input dataframe with ec pc columns added
        """
        df = data.copy()
        ec_pc_data = self.snowflake_conn.get_ec_pc_data( start_date= self.start_date,\
                                                         end_date=self.end_date,\
                                                         CHANNEL_NAME=self.channel)
        ec_pc_data = ec_pc_data[~ec_pc_data["parent_material_code"].isna()]
        ec_pc_data["key"] = ec_pc_data[self.granularity].astype(str).agg('_'.join, axis=1)
        ec_pc_data = ec_pc_data.groupby(by=['month_date', 'key'], as_index=False)[['ec', 'pc']].agg(sum)

        ec_pc_data = ec_pc_data[["key", "month_date", "ec", "pc"]]
        ec_pc_data["month_date"] = pd.to_datetime(ec_pc_data["month_date"])
        df["month_date"] = pd.to_datetime(df["month_date"])
        df = pd.merge(df, ec_pc_data, on=["key", "month_date"], how="left")
        return df


    def classify_co_type( self, co_value):
        co_output = 0
        if pd.isna( co_value) == False:
            co_value = co_value.lower().strip()
            if " " in co_value:
                co_value = "".join( co_value.split(" "))

            if any([ '+' in co_value, 'combo' in co_value, 'extraquantity' in co_value]) :
                co_output = 'extra_qty_co'     
            
            elif 'priceoff' in co_value:
                co_output = 'price_off_co'
            
            elif pd.isna( co_value)== False:
                co_output = 'other_co'

        return co_output


    def add_co_to_cols( self, data):
        """
        Add the CO and TO columns to the master data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - input data with added CO and TO columns
        """
        df = data.copy()

        co_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_CO_DATA')
        co_data = co_data[co_data['channel'] == self.channel]
        co_data = co_data.replace( { True:1 , False:0})
        co_data = co_data[[ "month_date", "parent_material_code", 'extra_vol_co', 'price_off_co', 'other_co']]
        co_data = co_data.drop_duplicates(subset=["month_date", "parent_material_code"], keep="first")
        co_data = co_data.fillna(0)

        co_data["month_date"] = pd.to_datetime(co_data["month_date"])
        data["month_date"] = pd.to_datetime(data["month_date"])

        co_data = co_data.drop_duplicates(
            subset=[
                "month_date",
                "parent_material_code",
            ],
            keep="first",
        )

        data = pd.merge(
            data,
            co_data,
            on=["month_date","parent_material_code"],
            how="left",
        )

        assert len(df) == len(data)

        
        if self.channel == 'GT':
            to_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_GT_BTL')
            print(to_data.head())
            to_data = to_data.drop_duplicates(subset=["month_date","parent_material_code"], keep="first" )
            to_data["month_date"] = pd.to_datetime(to_data["month_date"])
            to_data = to_data.drop_duplicates(subset=[
                                                    "month_date",
                                                    "parent_material_code",
                                                ],
                                                keep="first")
            data = pd.merge(
                            data,
                            to_data,
                            on=["month_date", "parent_material_code"],
                            how="left",
                        )

        assert len(df) == len(data)
        return data



    def update_future_mrp( self, data, train_till_date):
        """
        Append the future month MRP changes to the historical MRP column.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

            train_till_date: string
            - date till the month data training will be done in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with updated MRP column for future months
        """
        future_mrp_data = future_mrp_data.dropna()
        future_mrp_data.rename(
            columns={"New.Parent.KU": "parent_material1_code"}, inplace=True
        )
        future_mrp_data = future_mrp_data.drop_duplicates(
            subset=["asm_area_code", "parent_material1_code"], keep="first"
        )
        for key, data in tqdm(
            future_mrp_data[["asm_area_code", "parent_material1_code", "NEW_MRP"]].groupby(
                ["asm_area_code", "parent_material1_code"]
            )
        ):
            asm, psku = key
            condition = [
                data["asm_area_code"] == asm,
                data["parent_material1_code"] == psku,
                data["month_date"] > train_till_date,
            ]
            data.loc[all(condition), "Weighted_MRP"] = data["NEW_MRP"].iloc[0]
        return data


    def add_mrp_col( self, data, start_date, end_date):
        """
        Add the historical MRPs and future MRP's to the data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

            start_date: string
            - start date by which the MRP information needed to be fetched in yyyy-mm-dd format

            end_date: string
            - date till the MRP data is going to be fetched in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with MRP information added
        """

        historical_mrp_data = self.snowflake_conn.get_historical_mrp_data(
            start_date=start_date, end_date=end_date, channel="GT"
        )
        historical_mrp_data = historical_mrp_data.rename(columns={'parent_material1_code':'parent_material_code'})
        historical_mrp_data["month_date"] = pd.to_datetime( historical_mrp_data["month_date"] )

        historical_mrp_data['key'] = historical_mrp_data[self.granularity].astype(str).agg("_".join, axis=1)
        historical_mrp_data = historical_mrp_data.groupby(
            ["month_date", "key"],
            as_index=False,
        ).agg({"Total_Volume": "sum", "MRP_Sale_Vol": "sum", "AVG_MRP": "mean"})

        historical_mrp_data.loc[:, "Weighted_MRP"] =   historical_mrp_data["MRP_Sale_Vol"] / historical_mrp_data["Total_Volume"]
        historical_mrp_data["month_date"] = historical_mrp_data["month_date"].astype(str)
        data["month_date"] = data["month_date"].astype(str)

        data = pd.merge(
            data,
            historical_mrp_data[["month_date", "key", "Weighted_MRP"]],
            on=["key", "month_date"],
            how="left",
        )
        # data = update_future_mrp(data=data.copy(), train_till_date=end_date)

        data = data.rename( columns= {'Weighted_MRP': 'MRP'})
        return data


    def add_grp_spends_data( self, data):
        """
        This function adds the information of GRP and Spends to the master data

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - master data with added GRP and Spends column
        """
        data_length = len(data)

        customer_master = self.snowflake_conn.get_customer_master_table( channel=self.channel)
        grp_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_GRP')
        grp_data.rename(columns={ "material_group_code": "brand_code"}, inplace=True )
        grp_data = grp_data.drop('depot_name', axis=1).groupby(by=['month_date', 'brand_code'], as_index=False).agg(sum)
        # grp_customer_master = customer_master[["depot_code", "depot_name"]]
        # grp_customer_master["depot_name"] = grp_customer_master["depot_name"].str.upper()
        # grp_customer_master = grp_customer_master.drop_duplicates( subset=["depot_code"], keep="first")

        # data = pd.merge(data, grp_customer_master, on="depot_code", how="left")
        data[ 'month_date'] = pd.to_datetime( data['month_date'])
        grp_data[ 'month_date'] = pd.to_datetime( grp_data['month_date'])
        grp_data.columns = [ 'grp_'+ col if 'pt' in col.lower() else col for col in grp_data.columns ]
        data = pd.merge(
            data,
            grp_data,
            on=["brand_code", "month_date"],
            how="left",
        )

        # merge spends data
        spends_data = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_SPENDS')
        spends_data = spends_data.rename( columns={'material_group_code':'brand_code'})
        spends_data = spends_data.drop('depot_name', axis=1).groupby(by=['month_date', 'brand_code'], as_index=False).agg(sum)
        spends_data['month_date'] = pd.to_datetime(spends_data['month_date'])

        data = pd.merge(
                        data,
                        spends_data,
                        on=["brand_code", "month_date"],
                        how="left",
                )
        assert len(data) == data_length
        return data


    def fill_data_future_months( self, df, Key):
        """
        This function forward fill the demand derivers ( EC, PC, rm_price, qtr_ind_rate)
        for the forecasting months. EC, PC & fill_rate information is forward filled by
        P3M average value and qtr_ind_rate is forward filled simply.

        Args:
            df: pandas dataframe
            - master data having sales and other demand derivers

            Key: string
            - Key for which data is filtered and forward filling is done

            train_till_date: string
            - date till the month data training will be done in yyyy-mm-dd format

        Return:
            data: pandas dataframe
            - input data with forward filled columns
        """
        train_till_date = pd.to_datetime(self.end_date)
        p3m_months = [
            str(date.date())
            for date in pd.date_range(
                train_till_date - relativedelta(months=3), train_till_date, freq="M"
            )
        ]
        data = df[df["key"] == Key].copy()

        if self.channel == "GT":
            ec_p3m = data[data["month_date"].isin(p3m_months)]["ec"].mean()
            pc_p3m = data[data["month_date"].isin(p3m_months)]["pc"].mean()
            data.loc[data["month_date"] > train_till_date, "ec"] = ec_p3m
            data.loc[data["month_date"] > train_till_date, "pc"] = pc_p3m
            data["MRP"] = (
                data["MRP"].fillna(method="ffill").fillna(method="bfill")
            )

        if self.channel != "GT":
            fillrate_p3m = data[data["month_date"].isin(p3m_months)]["fill_rate"].mean()
            data.loc[data["month_date"] > train_till_date, "fill_rate"] = fillrate_p3m

        # data["rm_price"] = data["rm_price"].fillna(method="ffill").fillna(method="bfill")
        data["qtr_ind_rate"] = (
            data["qtr_ind_rate"].fillna(method="bfill").fillna(method="ffill")
        )

        return data


    def add_fill_rate_data( self, data):
        """
        Add fill rate column to MT and ECOM data.

        Args:
            data: pandas dataframe
            - master data having sales and other demand derivers

        Return:
            data: pandas dataframe
            - input data with added fill rate column

        """
        initial_data_length = len(data)
        channel = self.channel
        if channel == "ECOM":
            channel = "E-Commerce"

        # for fill_rate in
        fill_rate_df = self.snowflake_conn.fetch_mil_table_from_db( table_name= 'TRN_MIL_FILL_RATE')
        fill_rate_df["month_date"] = pd.to_datetime(fill_rate_df["month_date"]) + MonthEnd(0)


        fill_rate = fill_rate_df[ fill_rate_df['channel'] == channel]
        fill_rate = fill_rate.drop_duplicates(keep="first")

        fill_rate["order_qty"], fill_rate["invoice_qty"] = fill_rate["order_qty"].astype(
            float
        ), fill_rate["invoice_qty"].astype(float)

        # fill_rate = fill_rate.rename( columns= {'parent_material_code': 'parent_material1_code'})
        fill_rate["key"] = fill_rate[ self.granularity].astype(str).agg("_".join, axis=1)

        fill_rate = (
            fill_rate.groupby(["month_date", "key"])
            .agg({"order_qty": "sum", "invoice_qty": "sum"})
            .reset_index()
        )

        fill_rate["fill_rate"] = fill_rate["invoice_qty"] / fill_rate["order_qty"]
        fill_rate.loc[ fill_rate['fill_rate']>1,'fill_rate'] = 1

        data = pd.merge(data, fill_rate, how="left", on=["month_date", "key"])
        assert( len(data) == initial_data_length)
        return data

    def add_festival_flags( self, master_data: pd.DataFrame):
        """
            Add festival flags into the data.
        """

        festivals_data = self.snowflake_conn.fetch_mil_table_from_db( table_name='MST_MIL_FESTIVAL_DATA')
        festivals_data['month_date'] = pd.to_datetime( festivals_data['month_date']) + MonthEnd(0)
        festivals = festivals_data['festival'].unique().tolist()
        for festival in festivals:
            master_data[festival] = 0
            festival_month = festivals_data[festivals_data['festival']==festival]['month_date']
            master_data.loc[master_data['month_date'].isin(festival_month), festival] = 1
        return master_data
    

    def filter_brands_data( self, df):
        """
        """
        final_data = pd.DataFrame()
        brand_data = self.brands_data
        brand_data['start_date'] = pd.to_datetime(brand_data['start_date'].astype(str))
        df['month_date'] = pd.to_datetime(  df[ 'month_date'] )

        for brand in brand_data['brand_code'].unique():
            start_date = brand_data[brand_data['brand_code']==brand]['start_date'].iloc[0]
            if pd.isna(start_date)==False:
                sub_df = df[(df['month_date']>=start_date)&(df['brand_code']==brand)] 
            else:
                sub_df = df[(df['brand_code']==brand)] 
            final_data = pd.concat([final_data, sub_df], axis=0, ignore_index=True)

        return final_data

    def prepare_master_data( self):
        """
            Prepare the final model training data.
        """

        # if the data is already present in the table of not.
        data_check_query = f"""SELECT DISTINCT("RUN_MONTH") FROM {self.MIL_RBF_DATA_SNOWFLAKE_TABLE} where channel = '{self.channel}'"""
        run_months = self.snowflake_conn.fetch_mil_table_from_db(query=data_check_query)['run_month'].tolist()

        if self.RUN_MONTH not in run_months:
            print("*"*100)
            print(f"Preparing RBF Data For Run Month: {self.RUN_MONTH}")

            mil_master_data_query =  f"""SELECT * FROM {self.MIL_DF_TABLE} where run_month='{self.RUN_MONTH}' and channel ='{self.channel}' """
            mil_master_data = self.snowflake_conn.fetch_mil_table_from_db(query=mil_master_data_query)
            mil_master_data = mil_master_data.drop(['run_month', 'updated_timestamp_col'], axis=1, errors='ignore')
            
            channel = self.channel
            if channel == "ECOM":
                channel = "E-Commerce"
            
            mil_master_data = self.filter_brands_data( mil_master_data)
            mil_master_data['key'] = mil_master_data[self.granularity].astype(str).agg("_".join, axis=1)

            rbf_data = mil_master_data.groupby(by = [ 'month_date', 'parent_material_code'], as_index=False)['sec_vol_actuals_rum_month'].agg(sum)
            rbf_data = rbf_data.sort_values(by=[ 'parent_material_code','month_date',])

            rbf_data['key'] = rbf_data[self.granularity].astype(str).agg("_".join, axis=1)
            rbf_data = rbf_data.drop_duplicates( subset=["month_date", "key"], keep="first" )

            cols = ['parent_material_code', 'brand_code']
            rbf_data = pd.merge( rbf_data, mil_master_data.drop_duplicates( subset=cols, keep='first')[cols], how= 'left', on='parent_material_code' )

            # Add qtr_ind_rate to data
            cols = [ 'key', 'qtr_ind_rate']
            mil_master_data['month_date'] = pd.to_datetime(mil_master_data['month_date'])
            rbf_data = pd.merge( rbf_data, mil_master_data.drop_duplicates( subset='key', keep='first')[cols],
                                 how= 'left', on=[ 'key'] )
            
            # Add Free PSKU Flag
            cols = [ 'key', 'free']
            rbf_data = pd.merge( rbf_data, mil_master_data.drop_duplicates( subset='key', keep='first')[cols], how= 'left', on='key' )

            # Add Seasonal month flag
            cols = [ 'key', 'seasonal_month_flag']
            rbf_data = pd.merge( rbf_data, mil_master_data.drop_duplicates( subset='key', keep='first')[cols], how= 'left', on='key')

            # Add NPD Flags
            npd_pskus = mil_master_data[mil_master_data['npd_flag']==1]['parent_material_code'].unique().tolist()
            rbf_data['npd_flag'] = 0
            rbf_data.loc[rbf_data['parent_material_code'].isin(npd_pskus), 'npd_flag'] = 1


            # Add raw material col
            # filtered_sales_data = add_raw_material_prices(
            #     filtered_sales_data.copy(),
            #     raw_material_brand_code_mapping,
            #     raw_material_price_df,
            # )
            # Add CO TO Cols
            rbf_data = self.add_co_to_cols(rbf_data.copy())

            # Adding historical MRP data
            if self.channel == "GT":
                rbf_data = self.add_mrp_col(
                    data=rbf_data.copy(), start_date= self.start_date, end_date=self.end_date
                )
                rbf_data = self.add_grp_spends_data(rbf_data.copy())
                rbf_data = self.add_ec_pc_data(rbf_data.copy())
            else:
                rbf_data = self.add_fill_rate_data(rbf_data.copy())

            # fill data for forecast months
            rbf_data["month_date"] = pd.to_datetime(
                rbf_data["month_date"]
            )

            print(f"Fill Null Values for future months...")
            Fill_forward_data = Parallel(n_jobs=cpu_count() // 2, prefer="threads")(
                delayed(self.fill_data_future_months)( rbf_data,Key)
                for Key in tqdm(rbf_data.key.unique())
            )
            
            master_data = pd.concat(Fill_forward_data, axis=0)
            to_drop_cols = [ "key", "ASM_PSKU", "PSKU", "DEPOT_BRAND", "sec_vol_apo_plan_rum_month",'order_qty', 'invoice_qty',
                            "Brand", "depo_brand_comb", "depot_name", "Unnamed: 0", "Channel", 'depot_brand_comb', 'asm_area_code']
            master_data = master_data.drop(to_drop_cols, axis=1, errors = 'ignore')

            master_data = self.add_festival_flags( master_data.copy())
            master_data.columns = [ "_".join(col.split(" ")).lower()  if " " in col else col.lower() for col in master_data.columns]
            master_data.drop_duplicates(keep="first", inplace=True)
            master_data = master_data[master_data['month_date']<=max(self.forecast_period)]
            master_data.loc[:,'channel'] = self.channel
            Path(self.path).mkdir(parents=True, exist_ok=True)
            master_data.to_csv(os.path.join(self.path, self.master_data_file), index=False)
            
            print('RBF DATA IS Prepared')
            print('Min Date', min(master_data['month_date']))
            print('Max Date', max(master_data['month_date']))
            print('No of Brands: ', master_data['brand_code'].unique())
            print('*'*100)
            return True
        else:
            print('*'*100)
            print(f'RBF Training data of the {self.channel} for run month: {self.RUN_MONTH}')
            print('*'*100)
            return False

