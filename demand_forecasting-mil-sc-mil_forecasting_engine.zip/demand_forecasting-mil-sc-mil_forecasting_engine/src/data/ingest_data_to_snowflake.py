"""
Class to ingest the to snowflake tables.
"""

from ..helper import os, json, sqlalchemy, URL, pd, \
    np, tqdm, write_pandas, connector

class SnowflakeDataIngestion:

    def __init__( self):
        with open( os.path.join( './configs', 'server_credentials.json')) as file:
            self.db_credentials = json.load(file)

        db_name = 'snowflake_dev'

        # url = URL(
        #     account=  self.db_credentials.get(db_name).get('company'),
        #     user= self.db_credentials.get(db_name).get('username'),
        #     password= self.db_credentials.get(db_name).get('password'),
        #     database= self.db_credentials.get(db_name).get('db'),
        #     schema= self.db_credentials.get(db_name).get('schema'),
        #     warehouse= self.db_credentials.get(db_name).get('warehouse'),
        #     role= self.db_credentials.get(db_name).get('role'),
        # )
        # self.dbconnection = sqlalchemy.create_engine(url)
        # self.snowflake_engine = self.dbconnection.connect() 

        self.dbconnection = connector.connect( account=  self.db_credentials.get(db_name).get('company'),
            user= self.db_credentials.get(db_name).get('username'),
            password= self.db_credentials.get(db_name).get('password'),
            database= self.db_credentials.get(db_name).get('db'),
            schema= self.db_credentials.get(db_name).get('schema'),
            warehouse= self.db_credentials.get(db_name).get('warehouse'),
            role= self.db_credentials.get(db_name).get('role'))



    # def push_to_snowflake( self, df, snowflake_table_name, date, batch_process=True):
    #     """ """ 
    #     df["run_month"] = date
    #     if batch_process:
    #         df_array = np.array_split(df, (len(df)/15000) + 1) 
    #     else:
    #         df_array = np.array_split(df, len(df) + 1) 
    #     for x in tqdm(df_array):
    #         # x.columns = [col.upper() for col in x.columns]
    #         x.to_sql(snowflake_table_name, schema='DATA_SCIENCE', con=self.snowflake_engine, if_exists='append', index=False)
        
    #     return True
    
    def push_to_snowflake( self, df, snowflake_table_name, date, cap_cols = False, update_timestamp=None):
        """ """ 
        if date != None:
            df['run_month'] = date
        else:
            df['UPDATE_TIMESTAMP'] = update_timestamp
            df['UPDATE_TIMESTAMP'] = pd.to_datetime(df['UPDATE_TIMESTAMP']).dt.tz_localize('UTC')
        try:
            if cap_cols:
                df.columns = [col.upper() for col in df.columns]                
            print(f"Uploading Data to {snowflake_table_name} ")
            write_pandas(
                        self.dbconnection, 
                        df,
                        table_name=snowflake_table_name,
                        auto_create_table= True,
                        overwrite= False,
                    )

            total_rows = len(df)
            print(f"Uploaded Data to {snowflake_table_name} ")
            print(f"All {total_rows} rows uploaded successfully.")
            return True
        
        except Exception as e:
            #df.to_csv("acc_error_df.csv", index=False)
            print(f"Error pushing data to Snowflake: {str(e)}")
            raise