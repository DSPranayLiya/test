"""

"""
from ..helper import pd, os, datetime
from .ingest_data_to_snowflake import SnowflakeDataIngestion
from .fetch_snowflake_table_data import FetchSnowflakeData

class PushResultToSnowflake(SnowflakeDataIngestion):
    def __init__(self, input_dict, config):
        super().__init__()
        self.input_dict = input_dict
        self.location_to_save = self.input_dict["location_to_save"]
        self.input_dict["input_template_data_processed"]["di_model_input"][
            "train_till_date"
        ]

        self.config = config

    def push_rbf_results_to_snowflake(self):
        """
        This function push the training forecast result
        of rbf run to Snowflake.
        """

        df = pd.read_csv(os.path.join(self.location_to_save, "data.csv"))
        qtr_ind_rate_df = df[["month_date", "key", "qtr_ind_rate"]].drop_duplicates(
            subset=["month_date", "key"], keep="first"
        )

        rbf_results = pd.read_excel(
            os.path.join(self.location_to_save, "rbf_results.xlsx")
        )
        rbf_results.loc[:, "channel"] = self.config.CHANNEL_NAME
        rbf_results.loc[:, "forecast_date"] = pd.to_datetime(
            rbf_results["forecast_date"]
        )
        qtr_ind_rate_df.loc[:, "month_date"] = pd.to_datetime(
            qtr_ind_rate_df["month_date"]
        )

        rbf_results = pd.merge(
            rbf_results,
            qtr_ind_rate_df,
            left_on=["forecast_date", "key"],
            right_on=["month_date", "key"],
            how="left",
        )

        rbf_results = rbf_results[
            [
                "channel",
                "forecast_date",
                "key",
                "Pt Est",
                "qtr_ind_rate",
                "5%",
                "10%",
                "15%",
                "20%",
                "80%",
                "85%",
                "90%",
                "95%",
                "60% Interval Width",
                "70% Interval Width",
                "80% Interval Width",
                "90% Interval Width",
                "smoothen_level",
                "Shifting",
                "Scaling Factor",
                "model",
                "Best_Model",
            ]
        ]

        rbf_results.columns = [
            "channel",
            "month_date",
            "key",
            "point_est",
            "qtr_ind_rate",
            "five_percent",
            "ten_percent",
            "fifteen_percent",
            "twenty_percent",
            "eighty_percent",
            "eighty_five_percent",
            "ninety_percent",
            "ninety_five_percent",
            "sixty_percent_interval_width",
            "seventy_percent_interval_width",
            "eighty_percent_interval_width",
            "ninety_percent_interval_width",
            "smoothen_level",
            "shifting",
            "scaling_factor",
            "model",
            "best_model",
        ]

        rbf_results.loc[:, "run_type"] = self.config.RUN_TYPE
        rbf_results.loc[:, "month_date"] = rbf_results["month_date"].astype(str)
        self.push_to_snowflake(
            df=rbf_results,
            snowflake_table_name="TRN_MIL_RBF_DF_RESULTS",
            date=self.config.RUN_MONTH,
        )
        
        query_data = f""" SELECT DISTINCT("run_month") FROM TRN_MIL_RBF_RESULTS WHERE "channel" = '{self.config.CHANNEL_NAME}'"""
        existing_run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=query_data)

        if self.config.RUN_MONTH in existing_run_months['run_month'].tolist():
            print("RBF VALIDATE  is already present on snowflake")
        else:
            # push all model results validation + forecast
            for file in os.listdir(self.location_to_save):
                if "trend" in file:
                    data = pd.read_csv(os.path.join(self.location_to_save, file))

            data = data[
                [
                    "key",
                    "month_date",
                    "pred_prophet",
                    "pred_rf",
                    "sec_vol_actuals_rum_month",
                    "qtr_ind_rate",
                    "brand_code",
                    "sec_vol_actuals_rum_month_treated",

                ]
            ]
            data.loc[:, "channel"] = self.config.CHANNEL_NAME
            data.loc[:,'month_date'] = data['month_date'].astype(str)
            self.push_to_snowflake(
                df=data,
                snowflake_table_name="TRN_MIL_RBF_RESULTS",
                date=self.config.RUN_MONTH,
            )

        # push the validation summary data to snowflake
        query_data = f""" SELECT DISTINCT("run_month") FROM TRN_MIL_RBF_VALIDATION_RESULTS WHERE "channel" = '{self.config.CHANNEL_NAME}'"""
        existing_run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=query_data)

        if self.config.RUN_MONTH in existing_run_months['run_month'].tolist():
            print("RBF VALIDATE  is already present on snowflake")
        else:
            rbf_model_summary = pd.read_csv(
                os.path.join(self.location_to_save, "model_summary.csv")
            )
            rbf_model_summary.columns = [col.lower() for col in rbf_model_summary.columns]
            rbf_model_summary.loc[:, "run_type"] = self.config.RUN_TYPE
            rbf_model_summary.loc[:, "channel"] = self.config.CHANNEL_NAME
            rbf_model_summary['train_till'] = pd.to_datetime(pd.to_datetime(rbf_model_summary['train_till']).dt.date)
            
            self.push_to_snowflake(
                df=rbf_model_summary,
                snowflake_table_name="TRN_MIL_RBF_VALIDATION_RESULTS",
                date=self.config.RUN_MONTH,
            )


    def push_mil_data_to_snowflake(self):
        
        for file in os.listdir(self.location_to_save):
            if "trend" in file:
                data = pd.read_csv(os.path.join(self.location_to_save, file))
                data['train_till'] = data['train_till'].apply(lambda x: x.split(' ')[0] if ' ' in str(x) else x)
                train_till_date = data['train_till'].iloc[0]
                break

        query_data = f""" SELECT DISTINCT(TRAIN_TILL_DATE) FROM TRN_MIL_DF_TRAIN_FORECAST WHERE CHANNEL = '{self.config.CHANNEL_NAME}'"""
        existing_run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=query_data)

        if train_till_date in existing_run_months['train_till_date'].tolist():
            print("MIL Trend Data is already present on snowflake")

        else:
            data.loc[:,'asm_area_code'] = data['key'].apply(lambda x: x.split('_')[0])
            data.loc[:, 'depot_code'] = data['key'].apply(lambda x: x.split('_')[1])
            data.loc[:, "channel"] = self.config.CHANNEL_NAME
            data.loc[:,'month_date'] = pd.to_datetime(data['month_date']).dt.tz_localize('UTC')
            data = data[ ['month_date', 'key', 'asm_area_code', 'depot_code', 'parent_material_code',
                            'sec_vol_actuals_rum_month', 'sec_vol_actuals_rum_month_treated',
                        'pred_rf', 'pred_prophet', 'pred_SARIMA', 'qtr_ind_rate', 'channel', 'train_till']]
            
            data = data.rename(columns={'pred_SARIMA':'sarima_pred', "pred_prophet":'prophet_pred', 
                                        'pred_rf':'rf_pred','train_till':'train_till_date'})
            data.columns =  [col.upper() for col in data.columns]

            self.push_to_snowflake(
                df=data,
                snowflake_table_name="TRN_MIL_DF_TRAIN_FORECAST",
                date=None,
                update_timestamp = datetime.today().date()
            )


        query_data = f""" SELECT DISTINCT("run_month") FROM TRN_MIL_FORECAST_RESULTS WHERE CHANNEL = '{self.config.CHANNEL_NAME}'"""
        existing_run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=query_data)

        if self.config.RUN_MONTH in existing_run_months['run_month'].tolist():
            print("MIL Forecast Data is already present on snowflake")

        else:
            for file in os.listdir(self.location_to_save):
                if ("forecast" in file)&('training' not in file):
                    mil_model_pt_forecast = pd.read_csv(os.path.join(self.location_to_save, file))
                    break
            
            mil_model_pt_forecast.loc[:, "RUN_TYPE"] = self.config.RUN_TYPE
            mil_model_pt_forecast.loc[:, "CHANNEL"] = self.config.CHANNEL_NAME

            selected_col =  [ 'CHANNEL','key',  'asm_area_code', 'depot_code', 'parent_material_code', 'brand_code',
                'month_date', 'Model_Type', 'pred',  'Flag', 'validation_bias', 'validation_accuracy', 'train_accuracy',
                'Best_Model','series_length', 'qtr_ind_rate',  'train_till', 'predicting_month', 'cov', 'RUN_TYPE']
            
            mil_model_pt_forecast = mil_model_pt_forecast[selected_col]
            mil_model_pt_forecast.columns = [col.upper() for col in mil_model_pt_forecast.columns]
            # mil_model_pt_forecast = mil_model_pt_forecast[mil_model_pt_forecast['MONTH_DATE']>"2023-12-31"]
            self.push_to_snowflake(
                df=mil_model_pt_forecast,
                snowflake_table_name="TRN_MIL_FORECAST_RESULTS",
                date=self.config.RUN_MONTH,
            )

        query_data = f""" SELECT DISTINCT("run_month") FROM TRN_MIL_VALIDATION_RESULTS WHERE CHANNEL = '{self.config.CHANNEL_NAME}'"""
        existing_run_months = FetchSnowflakeData().fetch_mil_table_from_db(query=query_data)

        if self.config.RUN_MONTH in existing_run_months['run_month'].tolist():
            print("MIL VALIDATE  is already present on snowflake")
        else:
            mil_model_summary = pd.read_csv(
            os.path.join(self.location_to_save, "model_summary.csv")
            )
            mil_model_summary.columns = [col.upper() for col in mil_model_summary.columns]
            mil_model_summary.loc[:, "RUN_TYPE"] = self.config.RUN_TYPE
            mil_model_summary.loc[:, "CHANNEL"] = self.config.CHANNEL_NAME

            self.push_to_snowflake(
                df=mil_model_summary,
                snowflake_table_name="TRN_MIL_VALIDATION_RESULTS",
                date=self.config.RUN_MONTH,
            )

