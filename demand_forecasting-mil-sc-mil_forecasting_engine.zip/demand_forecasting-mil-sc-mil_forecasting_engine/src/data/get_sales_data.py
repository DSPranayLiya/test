"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file reads and preprocess the sales data
"""
from ..helper import json, sqlalchemy, URL, pd, MonthEnd, tqdm
from ..helper import read_files, run_parallel_functions, concatenate_pandas_dataframe, get_diff_month, get_diff_days

class GetSalesDataClass(object):
    """
    This class reads and preprocess the sales data and updates the 
    remaining inputs
    """
    def __init__(self, input_dict, config):
        """
        """
        self.channel = config.CHANNEL_NAME
        self.input_dict = input_dict
        self.DATE_COL = input_dict['input_template_data_processed']["DATE_COL"]
        self.target_column = input_dict['input_template_data_processed']["target_column"]
        self.di_model_input = input_dict['input_template_data_processed']["di_model_input"]
        self.actual_forecast_period = input_dict['cutoffs']['actual_forecast_period']
        self.cutoffs_periods = input_dict['cutoffs']["cutoffs_periods"]
        self.cv_periods = input_dict['cutoffs']["cv_periods"]
        self.input_variables = input_dict['input_template_data_processed']['input_vars']

    def filter_sales_on_past_sales(self, df):
        """
        This function will filter the sales data by checking the last freq sales.
        Given by the user, it will check past 'm' months or 'd' days and if the sales the 
        combined 'm'/'d' is zero, it will remove those key.

        Arguments:
         
            df: pandas dataframe
            - contain the sales data

        Return:

            df: pandas dataframe
            - contains the filtered sales data
        """
        if pd.isnull(self.input_dict['past_sales_check'])==False:
            to_check, total = list(map(int,self.input_dict['past_sales_check'].split("/")))
           
            if self.input_dict['data_frequency']=='M':
                date_to_filter = get_diff_month(x=self.di_model_input['train_till_date'],
                                months=total)
            if self.input_dict['data_frequency']=='D':
                date_to_filter = get_diff_days(x=self.di_model_input['train_till_date'], 
                                days=total)
            
            past_sales_data = df[(df[self.DATE_COL]>=date_to_filter) &
                                (df[self.DATE_COL]<=self.di_model_input['train_till_date'])]

            grouped_past_sales = past_sales_data.groupby(['key'], as_index=False)[self.target_column]\
                                .agg(lambda x: x.eq(0).sum())
            grouped_past_sales = grouped_past_sales[grouped_past_sales[self.target_column]>=to_check]
            keys_to_filter = grouped_past_sales["key"].values.tolist()      
            df = df[~df['key'].isin(keys_to_filter)]
            keys_to_filter = pd.DataFrame(keys_to_filter, columns=['key'])
            keys_to_filter.to_csv(f"{self.input_dict['location_to_save']}/past_sales_check_keys.csv", index=False)
            del past_sales_data, grouped_past_sales
        return df

    def filter_sales_data_on_series_length(self, df):
        """
        This function will filter the data on the key level and take only those
        combination whose series length is greater than 12.

        Argument:
         
            df: pandas dataframe
            - contain the sales data

        Return:

            df: pandas dataframe
            - contains the filtered sales data
        """
        df_copy = df.copy()
        df_copy = df_copy[~df_copy[self.DATE_COL].isin(self.actual_forecast_period)]
        min_max_date_pmc = df_copy.groupby('key',as_index=False).agg(count = ('key','count'))
        keys_to_filter = min_max_date_pmc[min_max_date_pmc['count']>12]["key"].values.tolist() 
        df = df[df['key'].isin(keys_to_filter)]
        keys_to_filter = pd.DataFrame(keys_to_filter, columns=['key'])
        keys_to_filter.to_csv(f"{self.input_dict['location_to_save']}/keys_length_filter.csv", index=False)
        del df_copy
        return df

    def fetch_data_from_snowflake(self):
        """
        This function will fetch the data fron snowflake

        Arguments:
                None
        Return:
            df: pandas dataframe
            - contains the sales data along with all the demand drivers
        """
        snowflake_table_name = self.input_dict['snowflake_table_name']
        snowflake_table_filter_date = self.input_dict['snowflake_table_filter_date']
        snowflake_table_date_filter_col = self.input_dict['snowflake_table_date_filter_col']   
        sql_credential = self.input_dict['snowflake_creds']
        snowflake_engine = sqlalchemy.create_engine(URL(
        account = sql_credential.get('company'),
        user = sql_credential.get('username'),
        password = sql_credential.get('password'),
        database = sql_credential.get('db'),
        schema = sql_credential.get('schema'),
        warehouse = sql_credential.get('warehouse'),
        ))
        
        connection = snowflake_engine.connect()
        #checking if the date filter provided in input template exists in snowflake db
        data_check_query = f"select distinct({snowflake_table_date_filter_col}) from {snowflake_table_name}"
        unique_date_from_snowflake = pd.read_sql(data_check_query, connection)
        unique_date_from_snowflake.columns = [col.lower() for col in unique_date_from_snowflake.columns]
        # unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"] = pd.to_datetime(unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"])
        # unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"] = unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"]+pd.offsets.MonthEnd(0)
        # unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"] = unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"].dt.date

        snowflake_table_filter_date = str(pd.to_datetime(snowflake_table_filter_date).date())
        if snowflake_table_filter_date in unique_date_from_snowflake[f"{snowflake_table_date_filter_col}"].values:
            data_fetch_query = f"""select * from {snowflake_table_name} where {snowflake_table_date_filter_col} = '{snowflake_table_filter_date}' and channel = '{self.channel}' """
            #quering the snowflake db
            df = pd.read_sql(data_fetch_query, connection)
            # df[snowflake_table_date_filter_col] = pd.to_datetime(df[snowflake_table_date_filter_col])
            # df[snowflake_table_date_filter_col] = df[snowflake_table_date_filter_col]+pd.offsets.MonthEnd(0)
            # df[snowflake_table_date_filter_col] = df[snowflake_table_date_filter_col].dt.date
            # #filter the data for the date specified in input template 
            # df = df[df[snowflake_table_date_filter_col]==snowflake_table_filter_date]
            df.drop([snowflake_table_date_filter_col], axis=1,inplace=True)
            df.columns = map(lambda col: str(col).lower(), df.columns)
            connection.close()
            return df
        else:
            print("ERROR!!")
            print(f"Snowflake does not contain the data for the given {snowflake_table_filter_date} month run")

    
    def impute_missing_date_col_data(self, df, Key):
        """
        This function will impute missing data on key X date_col level depending on the 
        freq provided

        Arguments:

            ds_data: pandas dataframe

            Key: string
            - defines the combination for which we have to filter ds_data

            freq: str
            - defines the frequency of the data(monthly, daily)
        """
        data_key = df[df['key']==Key]
        max_date = df[self.DATE_COL].max()
        min_date = data_key[self.DATE_COL].min()
        date_range = pd.DataFrame(pd.date_range(min_date,max_date,
                                                freq=self.input_dict['data_frequency']),columns=[self.DATE_COL])
       
        if self.input_dict['data_frequency']=='M':
             date_range[self.DATE_COL] = date_range[self.DATE_COL]+MonthEnd(0)
        date_range['key'] = Key
        data_key_updated = pd.merge(date_range,data_key.drop(["key"],axis=1),
                                    how="left", on=[self.DATE_COL])
        data_key_updated[self.input_dict['gran_cols']] =  data_key_updated[self.input_dict['gran_cols']].bfill().ffill()
        object_cols = list(df.select_dtypes(include=['object']))
        object_cols = list(set(object_cols)-set(self.input_dict['gran_cols']))
        num_cols = list(df.select_dtypes(include=['int','float']))
        data_key_updated[object_cols] = data_key_updated[object_cols].bfill().ffill()
        data_key_updated[num_cols] = data_key_updated[num_cols].fillna(0)
        return data_key_updated

    
    def group_sales_data_at_given_freq(self, df):
        """
        This function will change the granularity of the data if given at different level.

        Arguments:

            df: pandas dataframe
            - dataframe which contain the sales data + dd 

        Return:
            df: pandas dataframe
            - updated dataframe which contain the sales data + dd 

            freq: string
            - defines the frequency of the data(daily, monthly)

        """
        df[self.DATE_COL] = pd.to_datetime(df[self.DATE_COL])
        #replace with last value
        object_cols = list(df.select_dtypes(include=['object']))
        object_cols = list(set(object_cols)-set(self.input_dict['gran_cols']))
        object_cols.remove('key')
        num_cols = list(df.select_dtypes(include=['int','float']))
        object_cols_dict = dict.fromkeys(object_cols, "last")
        num_cols_dict = dict.fromkeys(num_cols, "sum")
        agg_parameter_dict = {**object_cols_dict, **num_cols_dict}


        if (self.di_model_input['frequency_given']=="Daily") & (self.di_model_input['frequency_forecast']=="Monthly"):


            df[f'{self.DATE_COL}'] = df[self.DATE_COL]+MonthEnd(0)
       
            df = (df.groupby(['key', self.DATE_COL])
                            .agg(agg_parameter_dict
                                )
                            .reset_index()
                        )
            df = df.reset_index(drop=True)

        if (self.di_model_input['frequency_given']=="Monthly") & (self.di_model_input['frequency_forecast']=="Monthly"):
            df[self.DATE_COL]=df[self.DATE_COL]+MonthEnd(0)

        return df

    

    def add_granularity(self, df:pd.DataFrame)->pd.DataFrame:
        """
        This function will add the granularity column(represented)
        by "key" in the dataframe

        Arguments:

            df: pandas dataframe
            - contains the sales data
        
        Return:

            df: pandas dataframe
            - updated dataframe with key column
        """
        #adding granularity to sales data            
        if self.input_dict["gran_cols"]!= []:
            gran_cols = self.input_dict['gran_cols']
            df['key'] = df[gran_cols].astype(str).agg('_'.join, axis=1)
        else:
            df['key'] = "A"
        return df

    def preprocess_sales_data(self, df:pd.DataFrame)->pd.DataFrame:
        """
        This function will preprocess the dataframe passed into it

        Arguments:

            df: pandas dataframe
            - pandas dataframe with sales+dd
        """
        #filtering the columns for which the flag is 1 in input template data
        df = df[self.input_variables]
        #converting the dtypes of key columns
        df = self.add_granularity(df)
        #check the granularity of data and if not at the one mentioned in input template convert it
        df = self.group_sales_data_at_given_freq(df=df)
        #filtering the data for minimum date provided in input template
        if self.input_dict['min_date_for_modeling_data']:
            df = df[df[self.DATE_COL]>=self.input_dict['min_date_for_modeling_data']]
        #if input_missing_data == True, then it will run the function of input missing datas
        if self.input_dict['impute_missing_data'] in [True,'True','TRUE','true']:
            missing_date_col_dict={}
            # impute_missing_month
            df_with_missing_date_col_data = run_parallel_functions(func=self.impute_missing_date_col_data,
                                                                df=df,
                                                                argument_dict=missing_date_col_dict,
                                                                desc="Imputing Missing Dates",
                                                                iter_col="key",
                                                                is_iter_idx=False,
                                                                is_df_arg=True)
            df = concatenate_pandas_dataframe(data_list=df_with_missing_date_col_data)
            
        print('Start Date:', df[self.DATE_COL].min(),'\n','End Date:',df[self.DATE_COL].max())
        #creating covid and post covid flag if dates are given
        if self.input_dict["covid_months"]!=None:
            df.loc[df[self.DATE_COL].isin(self.input_dict["covid_months"]), "covid_flag"] = 1
            df['covid_flag'].fillna(0, inplace=True)

        if self.input_dict["post_covid_months"]!=None:
            df.loc[df[self.DATE_COL].isin(self.input_dict["post_covid_months"]), "post_covid_flag"] = 1
            df['post_covid_flag'].fillna(0, inplace=True)
        #filtering the data
        df = df[df[self.DATE_COL]<=max(self.actual_forecast_period)]
        #replacing the negative value in target value with zero
        df.loc[df[self.target_column]<0,self.target_column] = 0 
        #replacing the target values of actual forecast period with zero 
        # df.loc[df[self.DATE_COL].isin(self.actual_forecast_period),self.target_column] = 0
        
        return df
    
    def flag_input_driven_month(self, df:pd.DataFrame)->pd.DataFrame:
        """
        As there is drop in march month in GT channel, so this function add
        a feature name `input_driven_month` dataframe to flag march month as
        input driven month.
        Args:
            df (pd.DataFrame): input dataframe with all the demand derivers

        Returns:
            pd.DataFrame: input df with input driven month col added
        """
        if self.channel == 'GT':
            df.loc[:,'input_driven_month'] = 0
            df.loc[pd.to_datetime(df[self.DATE_COL]).dt.month ==3,'input_driven_month'] = 1
        
        return df
    
    def filter_brands_data( self, df:pd.DataFrame):
        """
        """
        final_data = pd.DataFrame()
        brand_data = self.input_dict['brands_data']
        brand_data['start_date'] = pd.to_datetime(brand_data['start_date'].astype(str))
        df['month_date'] = pd.to_datetime(  df[ 'month_date'] )
        
        print("Filter Data on Brand Cutoffs")
        for brand in tqdm(df['brand_code'].unique()):
            try:
                start_date = brand_data[brand_data['brand_code']==brand]['start_date'].iloc[0]
            except IndexError:
                start_date = None
            if pd.isna(start_date)==False:
                sub_df = df[(df['month_date']>=start_date)&(df['brand_code']==brand)] 
            else:
                sub_df = df[(df['brand_code']==brand)] 
            final_data = pd.concat([final_data, sub_df], axis=0, ignore_index=True)

        return final_data
    
    def run(self):
        """
        This is the main function to run this class which executes all the functions mentioned above.
        """
        extra_cols_to_drop = self.input_dict['extra_cols_to_drop']
        
        if (self.input_dict['read_data_from_snowflake']==True) or (self.input_dict['read_data_from_snowflake']=="TRUE") or \
                (self.input_dict['read_data_from_snowflake']=="True") or (self.input_dict['read_data_from_snowflake']=="true"):
           
            df = self.fetch_data_from_snowflake()
        else:
            input_sales_file_path = self.input_dict['input_sales_file_path']
            df = read_files(input_file_path=input_sales_file_path)

        # add input driven month for GT channel
        df = self.flag_input_driven_month(df)

        #dropping the extra column from dataframe (mentioned in the input template data)
        if len(extra_cols_to_drop)>0:
            df.drop(extra_cols_to_drop,axis=1,inplace=True,errors='ignore')
    
        #preprocess sales data
        df = self.preprocess_sales_data(df=df)
        # checking the sales data 
        if df[['key',self.DATE_COL]].duplicated().sum()>0:
            print(f"Sales data contains the duplicate at key X {self.DATE_COL} level")
            df = df.drop_duplicates(subset=['key',self.DATE_COL], keep ='first')
            # exit(0) # Successful exit
        #adding master data (if present) to sales data
        df[self.DATE_COL] = pd.to_datetime(df[self.DATE_COL])
        df = df.sort_values(by=[self.DATE_COL, 'key'])
        master_data = self.input_dict['master_data']
        old_df_rows = df.shape[0]
        
        if master_data.empty==False:
            df['mst_key'] = df['key']
            df = pd.merge(df,
                        master_data,
                        how="left",
                        on='mst_key')
            df.drop(['mst_key'],axis=1,inplace=True)
            master_data_cols = master_data.drop(["mst_key"],axis=1).columns.tolist()
        else:
            master_data_cols = []
        self.input_dict['master_data_cols'] = master_data_cols
        del self.input_dict['master_data']
        
        if old_df_rows==df.shape[0]:
            # saving the sales data with master data
            df.to_csv(f"{self.input_dict['location_to_save']}/data.csv",index=False)
            # filtering all non-npd combinations, if the data has npd column
            # if self.input_dict['npd_col']:
            #     df =df[df[self.input_dict['npd_col']]==0]
            # filtering the data combination whose length is >12   
            df = self.filter_sales_data_on_series_length(df=df)
            # filtering the data combination whose target column is for past dates not zero
            df = self.filter_sales_on_past_sales(df=df)
            # applying brand cutoffs
            df = self.filter_brands_data( df= df.copy())
            df.to_csv(f"{self.input_dict['location_to_save']}/data_for_modeling.csv",index=False)
        else:
            print("shape of dataframe is different after merging with master data.")
            exit(0)
        return df