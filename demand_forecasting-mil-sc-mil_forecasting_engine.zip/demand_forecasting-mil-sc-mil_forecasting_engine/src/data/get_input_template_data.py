"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file fetches all the data from input template 
"""
from ..helper import pd, np, relativedelta, MonthEnd, MonthBegin
from ..helper import read_files, convert_date_to_month_end, create_dir, get_add_days, get_add_month, \
    create_date_range, get_diff_month, convert_date_to_pd_date, os
from configs import config as mil_config

class GetInputTemplateDataClass(object):
    """
    This class will read the input templated and return all the inputs
    """
    def __init__(self,input_template_data, config):
        """
        """
        self.input_variables_list = input_template_data['Variable_Input_List']
        self.input_Transformation = input_template_data['Transformations']
        self.input_outlier_Values = input_template_data['Outlier_Values']
        self.input_model_vars = input_template_data['Model_Inputs']
        self.input_trend_seas = input_template_data['Trend_and_Seasonality']
        self.input_stats_vars = input_template_data['Statistical_Params']
        self.input_stats_summary = input_template_data['Summary_Statistics']
        self.input_classical_ts_vars = input_template_data['Classical_Time_Series']
        self.input_extra_files = input_template_data['Folder_and_Files_Path']
        self.input_pipeline_data= input_template_data['Pipeline_Inputs']
        self.input_feature_selection_data = input_template_data['Feature_Selection_Input']
        self.input_dl_params = input_template_data['DL_Params']
        self.input_rbf_params = input_template_data['RBF_Params']
        self.input_template_data_processed = {}
        self.input_dict = {}

        
        self.input_dict['brands_data'] = input_template_data['Brands_List']
        if config.FORECAST_TYPE == 'RBF':
            self.input_dict['high_volatile_brands'] = input_template_data['High_Volatile_Brands']
    
    def create_results_dir(self):
        """
        This function creates results directory at the location specified
        in the input template
        """
        day = pd.to_datetime(self.input_template_data_processed['di_model_input']['train_till_date']).strftime('%d')
        month_name = pd.to_datetime(self.input_template_data_processed['di_model_input']['train_till_date']).strftime('%b')
        year = pd.to_datetime(self.input_template_data_processed['di_model_input']['train_till_date']).strftime('%Y')
        location_to_save = f"{self.input_dict['dir_name']}/train_till_{day}_{month_name}_{year}"
        location = os.path.join( location_to_save, mil_config.FORECAST_TYPE, mil_config.CHANNEL_NAME)
        create_dir(location=location, message="Forecast Results")
        self.input_dict['location_to_save'] = location

        
    def get_statistical_parameters(self):
        """
        This function will read statistical parameters provided in 
        input template(Sheet:Statistical_Params)
        """
        di_stats = {}
        for var in self.input_stats_vars.index.levels[0]:
            for sub in self.input_stats_vars.loc[var].index:
                if self.input_stats_vars.loc[(var,sub),'Current_Value'] == np.nan:
                    di_stats[sub] = self.input_stats_vars.loc[(var,sub),'Default_Value']
                else:
                    di_stats[sub] = self.input_stats_vars.loc[(var,sub),'Current_Value']  
        alpha = di_stats['Significance_Level']
        acceptable_skewness_threshold = di_stats['acceptable_skewness_threshold']
        threshold_iqr = di_stats['threshold_iqr']

        return di_stats

    def get_model_input_parameters(self):
        """
        This function will read all model input provided in 
        input template(Sheet:Model_Inputs)
        """
        self.input_model_vars.sort_values('Parameter_Type',inplace = True)
        self.input_model_vars.set_index(['Parameter_Type','Sub_Type'],inplace = True)
        di_model_input = {}
        for var in self.input_model_vars.index.levels[0]:
            for sub in self.input_model_vars.loc[var].index:
                if self.input_model_vars.loc[(var,sub),'Current_Value'] == np.nan:
                    di_model_input[sub] = self.input_model_vars.loc[(var,sub),'Default_Value']
                else:
                    di_model_input[sub] = self.input_model_vars.loc[(var,sub),'Current_Value']
                if sub == 'Holiday_Data_Type':
                    di_model_input["holiday_data_type"] = self.input_model_vars.loc[(var,sub),'Current_Value']
                if sub == 'Holiday_Data_Columns':
                    di_model_input["festival_col"] =self.input_model_vars.loc[(var,sub),'Current_Value']
                if sub == 'Additional_Regressors':
                    add_reg_val = self.input_model_vars.loc[(var,sub),'Current_Value']
                    if pd.isnull(add_reg_val)==False:
                        di_model_input["prophet_additional_regressors"] = add_reg_val.split(",")
                    else:
                        di_model_input["prophet_additional_regressors"] = []


        return di_model_input

    def get_model_transformation_input_parameters(self):
        """
        This function will read all transformation input provided in 
        input template(Sheet:Transformations)
        """
        self.input_Transformation.sort_values('Variable',inplace = True)
        self.input_Transformation = self.input_Transformation[self.input_Transformation.Variable.isin(self.input_vars)]
        self.input_Transformation.set_index(['Variable','Transformation'],inplace = True)

    def get_model_outliers_values_input_parameters(self):
        """
        This function will read all outlier and missing value input provided in 
        input template(Sheet:Outlier_Missing_Values)
        """
        self.input_outlier_Values.sort_values('Variable',inplace = True)
        self.input_outlier_Values = self.input_outlier_Values[self.input_outlier_Values.Variable.isin(self.input_vars)]
        self.input_outlier_Values.set_index('Variable',inplace = True)
        self.input_outlier_Values = self.input_outlier_Values.stack(dropna = False).to_frame().rename(columns = {0:'Values'})
        self.input_outlier_Values.index.names = ['Variable','Sub_Params']

    def get_model_classical_time_series_parameters(self):
        """
        This function will read all classical time series model parameters range provided in 
        input template(Sheet:Classical_Time_Series)
        """
        self.input_classical_ts_vars.set_index(['Model_Type','Parameter_Type'],inplace = True)
        di_cts_inputs = {}
        for var in self.input_classical_ts_vars.index.levels[0]:
            var_input = {}
            for sub in self.input_classical_ts_vars.loc[var].index:
                if self.input_classical_ts_vars.loc[(var,sub),'Current_Value'] == np.nan:
                    var_input[sub] = self.input_classical_ts_vars.loc[(var,sub),'Default_Value']
                else:
                    var_input[sub] = self.input_classical_ts_vars.loc[(var,sub),'Current_Value']  
            di_cts_inputs[var] = var_input
        return di_cts_inputs

    def get_input_template_data(self):
        """
        This function will  pre process all the data from the inputs template
        """
        self.input_stats_vars.set_index(['Parameter_Type','Sub_Type'], inplace = True)
        self.input_trend_seas.set_index('Params/Vars', inplace=True)

        target_column = self.input_variables_list[self.input_variables_list.Is_Target == 1].Variable.iloc[0]
        DATE_COL =  self.input_variables_list[ self.input_variables_list.Is_Date_Col == 1].Variable.iloc[0]
        self.input_vars =  self.input_variables_list[ self.input_variables_list.Flag == 1].Variable.tolist()
        cols_to_pred =  self.input_variables_list[ self.input_variables_list['Predict'] == 1][['Variable','Predict_Model_Type_cts_prophet']].values
        cols_to_pred = dict(cols_to_pred)

        di_stats = self.get_statistical_parameters()
        di_model_input = self.get_model_input_parameters()
        di_model_input['train_till_date'] = pd.to_datetime(di_model_input['train_till_date'].date())
        self.get_model_transformation_input_parameters()
        self.get_model_outliers_values_input_parameters()
        di_cts_inputs = self.get_model_classical_time_series_parameters()
        di_cts_inputs['SARIMA']["m"] = di_cts_inputs['SARIMA']["m"].split(",")
        di_cts_inputs['SARIMA']["m"] = list(map(int,di_cts_inputs['SARIMA']["m"]))
        
        self.input_template_data_processed["input_variables_list"] =  self.input_variables_list
        self.input_template_data_processed["di_stats"] = di_stats
        self.input_template_data_processed["di_model_input"] = di_model_input
        self.input_template_data_processed["Input_outlier_Values"] = self.input_outlier_Values
        self.input_template_data_processed["Input_Transformation"] = self.input_Transformation
        self.input_template_data_processed["di_cts_inputs"] = di_cts_inputs
        self.input_template_data_processed["Input_trend_seas"] =  self.input_trend_seas
        self.input_template_data_processed["DATE_COL"] = DATE_COL
        self.input_template_data_processed["target_column"] = target_column
        self.input_template_data_processed["Input_model_vars"] =  self.input_model_vars
        self.input_template_data_processed['cols_to_pred'] = cols_to_pred
        self.input_template_data_processed['input_vars'] = self.input_vars
        self.input_template_data_processed['input_fs_values'] = self.input_feature_selection_data 


    def get_dl_model_inputs( self):
        """
        This function will read all deep learning model input provided in 
        input template(Sheet:DL_Params)
        """
        dl_model_params_dict = {}
        input_dl_model_params =self.input_dl_params.set_index("Param")
        for param in input_dl_model_params.index:
            value = input_dl_model_params.loc[param]['Current_Value']
            if pd.isna(value):
                value = input_dl_model_params.loc[param]['Default_Choice']
            dl_model_params_dict[param] = {
                'value': value,
                "min": input_dl_model_params.loc[param]["Min"],
                "max": input_dl_model_params.loc[param]["Max"],
            }
        self.input_dict['dl_model_params'] = dl_model_params_dict

    def get_rbf_input( self):
        """
            This function read the range base forecasting parameter inputs
            from the input template.(Sheet:RBF_Params)
        """
        rbf_params_dict = {}
        input_rbf_model_params = self.input_rbf_params.set_index("Param")
        for param in input_rbf_model_params.index:
            value = input_rbf_model_params.loc[param]['Current_Value']
            if pd.isna(value):
                value = input_rbf_model_params.loc[param]['Default_Choice']
            
            try: 
                if ',' in value: 
                    value = [val.strip() for val in value.split(',')]
            except: pass
            rbf_params_dict[param.strip()] = value
        self.input_dict['rbf_params'] = rbf_params_dict

    def read_festival_data_location(self):
        """
        This functions read whether the festival data is provided or not and 
        if yes, it will read that file
        """
        festival_data_location =  self.input_pipeline_data[self.input_pipeline_data["Variable"]=="festival_data_location"]["Remarks"].values[0]

        if (festival_data_location==None) or (festival_data_location==np.nan) or (str(festival_data_location)=="nan") \
            or  (pd.isnull(festival_data_location)==True):
            self.input_dict["festival_data"] = None
        else:
            festival_data = read_files(festival_data_location)
            self.input_dict["festival_data"] = festival_data
    
    def read_snowflake_data_info(self):
        """
        This function will read all snowflake related parameters provided in 
        input template 
        """
        read_data_from_snowflake = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="read_data_from_snowflake"]["Remarks"].values[0]
        self.input_dict['read_data_from_snowflake'] = read_data_from_snowflake

        snowflake_table_name = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_table_name"]["Remarks"].values[0]
        snowflake_table_filter_date = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_date_filter"]["Remarks"].values[0]
        snowflake_table_date_filter_col = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_date_filter_col"]["Remarks"].values[0]

        self.input_dict['snowflake_table_name'] = snowflake_table_name
        self.input_dict['snowflake_table_filter_date'] = snowflake_table_filter_date
        self.input_dict['snowflake_table_date_filter_col'] = snowflake_table_date_filter_col

    
    def read_covid_months_data(self):
        """
        This function will read the covid months and if no. of post covid months is provided
        then it will calculate the post covid months as well.
        """
        covid_months = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="covid_months"]["Remarks"].values[0]
        if pd.isnull(covid_months)==False:
            covid_months = pd.to_datetime(pd.Series((covid_months).replace(" ", "").split(",")),format="%Y-%m-%d").tolist()    
            min_date = min(covid_months)+ MonthBegin(-1)
            max_date = max(covid_months) + MonthEnd(0)  
            covid_months = list(pd.date_range(min_date, max_date, freq='D'))
        else:
            covid_months = None

        no_of_post_covid_months = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="no_of_post_covid_months"]["Remarks"].values[0]
        if pd.isnull(no_of_post_covid_months)==False:    
            start_date = max(covid_months)+relativedelta(months=1) + MonthBegin(-1)
            end_date =  max(covid_months)+relativedelta(months=no_of_post_covid_months) + MonthEnd(0)
            post_covid_months = list(pd.date_range(start_date, end_date, freq='D'))
        else:
            post_covid_months = None
        
        self.input_dict['covid_months'] = covid_months
        self.input_dict['post_covid_months'] = post_covid_months
    
    def read_treat_covid_month_flag(self):
        """
        This function will read whether to replace the covid month sales with p3m for 
        classical time series forecasting
        """
        treat_covid_months_flag_cts = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="treat_covid_month_cts"]["Remarks"].values[0]
        if (treat_covid_months_flag_cts==True) or (treat_covid_months_flag_cts=="TRUE") or (treat_covid_months_flag_cts=="True") or \
            (treat_covid_months_flag_cts=="true"):
            treat_covid_months_flag_cts = True
        else:
            treat_covid_months_flag_cts=False
        
        self.input_dict["treat_covid_months_flag_cts"] = treat_covid_months_flag_cts

    def read_snowflake_credentials(self):
        """
        This function will read the credentials to be used in order to 
        connect to snowflake
        """
        snowflake_creds = {}
        snowflake_username = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_username"]["Remarks"].values[0]
        if pd.isnull(snowflake_username)==True:
            snowflake_username = ""
        snowflake_creds['username'] = snowflake_username

        snowflake_password = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_password"]["Remarks"].values[0]
        if pd.isnull(snowflake_password)==True:
            snowflake_password = ""
        snowflake_creds['password'] = snowflake_password

        snowflake_company = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_company"]["Remarks"].values[0]
        if pd.isnull(snowflake_company)==True:
            snowflake_company = ""
        snowflake_creds['company'] = snowflake_company

        snowflake_warehouse = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_warehouse"]["Remarks"].values[0]
        if pd.isnull(snowflake_warehouse)==True:
            snowflake_warehouse = ""
        snowflake_creds['warehouse'] = snowflake_warehouse

        snowflake_db = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_db"]["Remarks"].values[0]
        if pd.isnull(snowflake_db)==True:
            snowflake_db = ""
        snowflake_creds['db'] = snowflake_db

        snowflake_schema = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="snowflake_schema"]["Remarks"].values[0]
        if pd.isnull(snowflake_schema)==True:
            snowflake_schema = ""
        snowflake_creds['schema'] = snowflake_schema
        self.input_dict['snowflake_creds'] = snowflake_creds

    def read_pipeline_inputs(self):
        """
        This function will read all the input from Pipeline_Inputs sheet 
        in the input template data
        """
        self.input_dict['no_of_keys_to_process'] = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="no_of_keys"]\
                                                    ["Remarks"].values[0]
        self.input_dict['impute_missing_data'] = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="impute_missing_data"]\
                                                    ["Remarks"].values[0]

        self.read_festival_data_location()
        self.read_snowflake_data_info()
        self.read_snowflake_credentials()
       
        extra_cols_to_drop = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="extra_cols_to_drop"]["Remarks"].values[0]
        if pd.isnull(extra_cols_to_drop)==True:
            extra_cols_to_drop = []
        else:
            extra_cols_to_drop = extra_cols_to_drop.split(",")
        self.input_dict["extra_cols_to_drop"] = extra_cols_to_drop

        self.read_covid_months_data()
        self.read_treat_covid_month_flag()

        npd_col = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="npd_col"]["Remarks"].values[0]
        if pd.isnull(npd_col)==True:
            npd_col = ""
        
        self.input_dict["npd_col"] = npd_col

        min_date_for_modeling_data = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="modeling_data_min_date"]["Remarks"].values[0]
        if pd.isnull(min_date_for_modeling_data)==True:
            min_date_for_modeling_data = None
        self.input_dict["min_date_for_modeling_data"] = min_date_for_modeling_data


        past_sales_check_no = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="past_sales_check"]["Remarks"].values[0]
        if pd.isnull(past_sales_check_no)==True:
            past_sales_check_no = None
        self.input_dict["past_sales_check"] = past_sales_check_no

        dir_name = self.input_pipeline_data[self.input_pipeline_data["Variable"]=="location_to_save"]["Remarks"].values[0]
        self.input_dict['dir_name'] = dir_name

    def process_extra_files(self, extra_files_df):
        """
        This function will read and process the extra files like master data, 
        bpm file if provided in the input template

        Arguments:

            extra_files_df: pandas dataframe
            - contains the file names to be processed

        Return:

            file_data:pandas dataframe
            - processed file data

            gran_cols: list
            - granularity of the processed file data

        """
        extra_files_df = extra_files_df.reset_index(drop=True)
        if extra_files_df.shape[0]>0:
            input_file_path = extra_files_df.loc[0,'File_Path']
            key = extra_files_df.loc[0,'Key']
            if "," in key:
                key = key.split(",")

            else:
                key = [key]
            extra_files_df_cols = extra_files_df.loc[0,'columns']
            if "," in extra_files_df_cols:
                extra_files_df_cols = extra_files_df_cols.split(",") + key
            else:
                extra_files_df_cols = [extra_files_df_cols] + key

            file_data = read_files(input_file_path)
            col_dtypes = file_data.dtypes
            for col in key:
                if col_dtypes[col]==int:
                    file_data[col] = file_data[col].astype(int).astype(str)
                else:
                    file_data[col] = file_data[col].astype(str)
            
            file_data = file_data[extra_files_df_cols]
            file_data = file_data.drop_duplicates(keep="first")

            gran_cols = key.copy()
            
        else:
            file_data = None
            gran_cols = None
        return file_data,gran_cols
    
    def get_extra_files_data(self):
        """
        This function will read all the extra files provided and save into 
        input_dict
        """
        index_rate_file_data = self.input_extra_files[self.input_extra_files['Files']=="Index_Rate_File"]
        index_rate_file_name = index_rate_file_data['File_Path'].values[0]
        if pd.isnull(index_rate_file_name)==False:
            index_rate,idx_gran_cols = self.process_extra_files(index_rate_file_data)
            self.input_template_data_processed['di_model_input']['idx_key_cols'] = idx_gran_cols
            if self.input_template_data_processed['DATE_COL'] in index_rate.columns:
                index_rate[self.input_template_data_processed['DATE_COL']] = pd.to_datetime(index_rate[ self.input_template_data_processed['DATE_COL']])
            index_rate.to_excel(f"{self.input_dict['location_to_save']}/index_rate_final.xlsx", index=False)
        else:
            index_rate = pd.DataFrame()
            idx_gran_cols = []
            self.input_template_data_processed['di_model_input']['idx_key_cols'] = []
        
        master_file_data = self.input_extra_files[self.input_extra_files['Files']=="Master_Data_File"]
        master_file_name = master_file_data['File_Path'].values[0]
        if pd.isnull(master_file_name)==False:
            master_data, mst_gran_cols = self.process_extra_files(master_file_data)
            master_data["mst_key"] = master_data[mst_gran_cols].astype(str).agg('_'.join, axis=1)
            master_data.drop(mst_gran_cols, axis=1, inplace=True)   
            self.input_template_data_processed['di_model_input']['mst_key_cols'] = mst_gran_cols
            master_data.to_excel(f"{self.input_dict['location_to_save']}/master_data.xlsx", index=False)
        else:
            master_data = pd.DataFrame()
            mst_gran_cols = []
            self.input_template_data_processed['di_model_input']['mst_key_cols'] = []
        
        self.input_dict['index_rate_data'] = index_rate
        self.input_dict['master_data'] = master_data

        modeling_file_path = self.input_extra_files[self.input_extra_files['Files']=="Modeling_File"]['File_Path'].values[0]
        if pd.isnull(modeling_file_path)==False:
            self.input_dict['input_sales_file_path'] = modeling_file_path
        else:
            self.input_dict['input_sales_file_path'] = ""

    def calculate_cutoffs(self):
        """
        This function will calculate the forecasting period, validation period, cutoff & prophet_horizon
        
        Return:

            actual_forecast_period: list
            - Contains the datetime values of the periods to be forecasted

            cutoffs_periods: list
            - Contains the different cutoff(train_till_date) on which cross validation has to be done

            cv_periods: list
            - contains the cross validation periods for all the cutoffs mentioned above

            prophet_horizon: list
            - contains the no. of days to be forecasted at each validation

        """
        di_model_input = self.input_template_data_processed['di_model_input']
        if (di_model_input['frequency_forecast']=="Monthly"):
            freq='M'
        elif (di_model_input['frequency_forecast']=="Daily"):
            freq='D'
        else:
            pass
        self.input_dict['data_frequency'] = freq
        
        if freq=='M':
            start_date = get_add_month(x=di_model_input["train_till_date"], months=1)
            end_date = get_add_month(x=di_model_input["train_till_date"], months=di_model_input["buffer_horizon"]+\
                                                di_model_input["forecast_horizon"])
        if freq=='D':
            start_date = get_add_days(x=di_model_input["train_till_date"], days=1)
            end_date = get_add_days(x=di_model_input["train_till_date"], days=di_model_input["buffer_horizon"]+\
                                                di_model_input["forecast_horizon"])
        actual_forecast_period = create_date_range(start_date=start_date, end_date=end_date, freq=freq)

        cv_periods, cutoffs_periods, no_of_days = [], [], []

        tm = di_model_input["validation_horizon"] + di_model_input["buffer_horizon"]
        step = 0 

        for n in range(0,di_model_input["no_of_cross_validations"]):
            if freq=='M':
                cutoff = convert_date_to_month_end(get_diff_month(x=di_model_input['train_till_date'], months=tm+step))
                cv_start = get_add_month(x=cutoff, months=1)
                cv_end = get_add_month(x=cutoff, months=tm)
               
            if freq=='D':
                cutoff = di_model_input['train_till_date']-relativedelta(days=tm+step)
                cv_start = get_add_days(x=cutoff, days=1)
                cv_end = get_add_days(x=cutoff, days=tm)
            
            cvs = create_date_range(start_date=cv_start, end_date=cv_end, freq=freq)
             
            cutoffs_periods.append(cutoff)
            cv_periods.append(cvs)
            no_of_days.append((cv_end-cutoff).days)
            step = step+di_model_input["validation_horizon"] 
            
        prophet_horizon = no_of_days

        if freq=='M':
            actual_no_of_days = (di_model_input["buffer_horizon"]+di_model_input["validation_horizon"])*30
            actual_forecast_period = list(map(convert_date_to_month_end, actual_forecast_period))
            cutoffs_periods = list(map(convert_date_to_month_end, cutoffs_periods))
            cv_periods = list(map(lambda b : list(map(convert_date_to_month_end, b)), cv_periods))

        if freq=='D':
            actual_no_of_days = di_model_input["buffer_horizon"]+di_model_input["validation_horizon"]
            actual_forecast_period = list(map(convert_date_to_pd_date, actual_forecast_period))
            cutoffs_periods = list(map(convert_date_to_pd_date, cutoffs_periods))
            cv_periods = list(map(lambda b : list(map(convert_date_to_pd_date, b)), cv_periods))

        return actual_forecast_period, cv_periods, cutoffs_periods, prophet_horizon, actual_no_of_days

    def create_granularity(self):
        """
        This function will create the granularity column(represented)
        by "key" in the dataframe

        Arguments:

            df: pandas dataframe
            - contains the sales data
        
        Return:

            df: pandas dataframe
            - updated dataframe with key column
        """
        #adding granularity to sales data      
        di_model_input = self.input_dict['input_template_data_processed']['di_model_input'] 
        if pd.isnull(di_model_input['Granularity'])!=True:
            gran_cols = [ val.strip() for val in di_model_input['Granularity'].split(',')]
            self.input_dict["gran_cols"] = gran_cols
        else:
            self.input_dict["gran_cols"] = []       
    
    def run(self):
        """
        This is the main function of this class which executes all the functions mentioned above.
        """
        #read all the input template data
        self.get_input_template_data()
        #read all the inputs of pipeline input sheet
        self.read_pipeline_inputs()
        #create a directory to save all the results
        self.create_results_dir()
        #read and process extra files data
        self.get_extra_files_data()
        #calculating the forecast period, cross validation period, cutoff based on the train till date provide in the input templates
        actual_forecast_period, cv_periods, cutoffs_periods,prophet_horizon, actual_no_of_days = self.calculate_cutoffs()
        # reading the deep learning model input params
        self.get_dl_model_inputs()
        # reading the rbf input params
        self.get_rbf_input()
        cutoff_dict = {"actual_forecast_period":actual_forecast_period,
                        "cv_periods":cv_periods,
                        "cutoffs_periods":cutoffs_periods,
                        "prophet_horizon":prophet_horizon,
                        "actual_no_of_days":actual_no_of_days}
        self.input_dict['cutoffs'] = cutoff_dict
        self.input_dict['input_template_data_processed'] = self.input_template_data_processed
        self.create_granularity()
        self.input_dict['master_data_cols'] = []
        print("*******************************************************************************************\n\n")
        print("Actual Forecast Period",actual_forecast_period)
        print("Train till date",self.input_template_data_processed['di_model_input']['train_till_date'])
        print("*******************************************************************************************\n\n")
        print("Cross Validation Periods")
        print()
        print("Cutoff Periods",cutoffs_periods)
        print()
        print("Validation  Periods",cv_periods)

        print("*******************************************************************************************\n\n")


        print("Prophet Cross Validation Horizon",  prophet_horizon)
        print("*******************************************************************************************\n\n")