"""
Author: Pranjal Soni
Version: 0.0.1
Description: This file perform data validation and generate a report.
"""

from ..helper import math, pd, np, Fore

class MasterDataValidation:
    """
        This class help in validation the final prepared data
    """

    def __init__(self, df, input_dict, channel) -> None:
        """
        
        Args:
            config (_type_): _description_
        """
        self.common_cols = [ 'month_date', 'parent_material_code', 'depot_code',
                         'asm_area_code', 'sec_vol_actuals_rum_month', 'extra_vol_co',	
                        'price_off_co',	'other_co','brand_code', 'qtr_ind_rate']
        
        self.gt_specific_cols = [ 'mrp', 'npt', 'npt-aft', 'npt-morn',
                             	'pt', 'pt-eve',	'npt-eve',	'print_spends_in_lacs',
                                'tv_spends_in_lacs',	"radio_spends_in_lacs", 'pc',
                                'btl_flag']

        self.mt_ecom_specific_cols = ['fill_rate']

        self.mapping_cols = [ 'free', 'npd_flag', 'seasonal_month_flag'] 

        self.festival_cols = ['bakri_eid', 'independence_day', 'ganesh_chaturthi', 
                              'gandhi_jayanthi', 'dussehra', 'diwali', 'christmas',
                              'ramzan_eid', 'new_year', 'gudi_padwa']

        self.channel = channel
        # if config.FORECAST_TYPE == 'MIL':
        self.gran_cols =['asm_area_code', 'depot_code', 'parent_material_code']
        
        #self.gran_cols = [val.strip() for val in self.gran_cols.split(',')]
        self.DATE_COL = input_dict['input_template_data_processed']['DATE_COL']
        self.df = df

    def validate_binary_cols(self, cols_to_val):
        """
            Check if binary column data type to be 
            integer and have should be 0 and 1 only.
        Args:
            cols_to_val ( list): binary column list
            df ( pandas dataframe): df ( pandas dataframe): Channel data with all demand derivers.
        """
        for col in cols_to_val:
            if (self.df[col].dtype != int) and (self.df[col].dtype != float):
                print(Fore.RED +f'{col} do not have type int or float')
                print(Fore.RED +f'Data Type of {col}: {self.df[col].dtype}')      
     
            outlier = []
            for val in self.df[col].unique():
                if math.isnan(val):
                    pass
                elif( int(val) in [0,1]):
                    pass
                else:
                    outlier.append(val)
            if len(outlier)>0:     
                print(f'Distinct values for {col} {self.df[col].unique()}')
                print(f'{col} in not binary column.','\n')
    
    def check_all_cols(self):
        """
            Check all the required column present in the final data.
        Args:
            df ( pandas dataframe): Channel data with all demand derivers.
        """

        if self.channel == 'GT':
            cols = self.common_cols + self.gt_specific_cols + self.mapping_cols + self.festival_cols
        else:
            cols = self.common_cols + self.mt_ecom_specific_cols + self.mapping_cols + self.festival_cols
        
        for col in cols:
            if col not in self.df.columns:
                print(Fore.RED + f'{col} not present in the GT data.')
        
        print('\nAll the columns present in the data.\n')

    
    def check_data_type(self):
        """
            Check data type of demand derivers.
        Args:
            df ( pandas dataframe): Channel data with all demand derivers.
        """
        # check month_date col data type
    

        # check for festival columns binary values.
        print(f"Validating Festival Cols...")
        self.validate_binary_cols(cols_to_val=self.festival_cols)   
        print(Fore.GREEN + f'All the festival columns have binary values.')

        # check for npd_flag, free, seasonal_month_flag cols.
        print(f"Validating NPD, Free, Seasonal Month Flag...")
        self.validate_binary_cols(cols_to_val=self.mapping_cols)   
        print(f'All the NPD, Free, Seasonal Month Flag columns have binary values.')

        if self.channel.upper() == 'GT':
            # check for co and to columns.
            print(f"Validating GT Specific Demand Derivers...")
            for col in self.mapping_cols:
                if (self.df[col].dtype not in [int,float])and( 'flag' not in col):
                    print(Fore.RED +f'Data Type of {col}: {self.df[col].dtype}') 
                    raise Exception(f'{col} do not have type float')
                    
                
                if (self.df[col].dtype not in [int,float]) and ('flag' in col):
                    print(Fore.RED + f'Data Type of {col}: {self.df[col].dtype}')
                    raise Exception(f'{col} do not have type int')
                    
            print(f'All the  GT Specific have float data type.')

        if self.channel.upper() != 'GT':
            print(f"Validating Fill Rate Column...")
            col = 'fill_rate'
            if self.df[col].dtype != float:
                print(f'{col} do not have type float')  
        
        # check for float columns
        for col in [ 'sec_vol_actuals_rum_month', 'qtr_ind_rate']:
            if ( self.df[col].dtype != float):
                print(f'{col} do not have type float \n ')  
                print(f'Data Type of {col}: {self.df[col].dtype} \n')
            else:
                print(f"{col} have the correct data type. \n")
            
        # check for CO columns
        cols = ['extra_vol_co','price_off_co', 'other_co']
        self.validate_binary_cols( cols_to_val = cols)
        print("All CO cols have correct columns.")
            
        # check data type of identifier columns
        for col in ['depot_code', 'asm_area_code', 'brand_code']:
            if (col == 'parent_material1_code'):
                if ( self.df[col].dtype==int):
                    print(f"\n {col} have correct data type. \n")
                else:
                    raise Exception(f'{col} do not have type int')
            else:
                if ( self.df[col].dtype==object):
                    print(f"\n {col} have correct data type. \n")
                else:
                    raise Exception(f'{col} do not have type object')


    def check_duplicate_rows(self):
        """
            Check if for duplicate row at month and key level.
        """
        num_duplicates = self.df.duplicated(subset= [self.DATE_COL ]+ self.gran_cols).sum()
        if num_duplicates>0:
            raise Exception(f'Data consist Duplicate rows.')
        else:
            print(f'Data do not contains any duplicate rows.')

    def run_data_validation(self):
        """
            Perform data validation and return True if data validation 
            is successful.
        """
        print("Running Data Validation")
        self.check_all_cols()
        self.check_data_type()
        self.check_duplicate_rows()
        print("Data Validation Successful")
        return True

if __name__ == "__main__":  
    df = pd.read_csv("model_input_data/Aug'23/gt_mil_data_updated.csv")
    df = df.rename( columns= {'npd':'npd_flag'})
    print(df.columns)
    data_val_obj = MasterDataValidation(df)
    data_val_obj.run_data_validation()