"""
    This file consists the functions to fetch the data from 
    snowflake data schema. 
"""

from pandas import read_sql, DataFrame, read_sql_query, to_datetime
from snowflake.sqlalchemy import URL
#from ..helper import os, sqlalchemy, json
import os, sqlalchemy, json

class FetchSnowflakeData:

    def __init__( self) -> None:
        with open( os.path.join( './configs', 'server_credentials.json')) as file:
            self.db_credentials = json.load(file)


    def get_dbconnection(self, db_name):
        if db_name == 'PROD':
            db_name = 'snowflake_prod'
        else:
            db_name = 'snowflake_dev'

        url = URL(
            account=  self.db_credentials.get(db_name).get('company'),
            user= self.db_credentials.get(db_name).get('username'),
            password= self.db_credentials.get(db_name).get('password'),
            database= self.db_credentials.get(db_name).get('db'),
            schema= self.db_credentials.get(db_name).get('schema'),
            warehouse= self.db_credentials.get(db_name).get('warehouse'),
            role= self.db_credentials.get(db_name).get('role'),
        )
        dbconnection = sqlalchemy.create_engine(url)
        return dbconnection


    def get_historical_sales( self, start_date, end_date, channel):
        """
        Fetch the historical sales and plan numbers at ASM*DEPOT*PSKU level from dwh_bpm_dist_brand_mth_sbp table.

        Input:
            start_date: str
            - start data from data is fetched in format yyyy-mm-dd

            end_date: str
            - end date till the ec pc data to be fetched in format yyyy-mm-dd

            channel: str
            - channel name for which ec & pc data be fetched

        Return:
            sales_data : pandas dataframe
            - dataframe consisting historical sales data and plan numbers
        """

        print(
            f" Fetching the historical {channel} sales data from {start_date} to {end_date} ."
        )
        query = """ SELECT 
                        asm_area_code, 
                        depot_code, 
                        parent_material1_code, 
                        month_date, 
                        sum(sec_actuals_vol_rum_month) Sec_Vol_Actuals_Rum_Month,
                        sum(sec_apo_plan_vol_rum_month) Sec_Vol_Apo_Plan_Rum_Month
                    FROM (
                        Select 
                            Month_Date, 
                            Distributor_Code, 
                            material_code, 
                            sec_actuals_vol_rum_month, 
                            sec_apo_plan_vol_rum_month
                        from 
                            dwh_bpm_dist_brand_mth_sbp 
                        where 
                        month_date  between '{}' and '{}') A
                    
                    JOIN (
                        SELECT 
                            customer_code, 
                            asm_area_code, 
                            depot_code
                        FROM 
                            mst_sap_customer_master 
                        WHERE 
                            company_code= 'MIL' 
                            and latest_record_ind=1 
                            and channel_name = '{}') C 
                        ON 
                            distributor_code = customer_code
                    
                    JOIN (
                        Select 
                            material_code, 
                            parent_material1_code 
                        from 
                            mst_sap_material_master_latest 
                        where 
                            company_code= 'MIL' 
                            and latest_record_ind=1) M 
                        ON 
                            A.material_code = M.material_code
                        group by 
                            asm_area_code, depot_code, parent_material1_code, Month_date
                        ORDER BY 
                            asm_area_code, depot_code, parent_material1_code, Month_date

                """.format(
            start_date, end_date, channel
        )

        connection = self.get_dbconnection( db_name= 'PROD')
        results = read_sql(con=connection, sql=query)
        sales_data = DataFrame(results)
        sales_data = sales_data.rename(columns={'parent_material1_code':'parent_material_code'})
        return sales_data


    def get_historical_mrp_data( self, start_date, end_date, channel):
        """
        Fetch the historical MRP data from trn_billwise_itemwise_urban table.

        Input:
            start_date: str
            - start data from data is fetched in format yyyy-mm-dd

            end_date: str
            - end date till the ec pc data to be fetched in format yyyy-mm-dd

            channel: str
            - channel name for which ec & pc data be fetched

        Return:
            historical_mrp_data : pandas dataframe
            - dataframe consisting historical mrp data
        """

        print(
            f" Fetching the historical {channel} MRP data from {start_date} to {end_date} ."
        )
        query = """select 
                last_day(Sale_Inv_Date) as month_date, 
                customer_code, 
                customer_name, 
                asm_area_code, 
                asm_area_name, 
                depot_code, 
                parent_material1_code, 
                parent_material1_desc, 
                sum(Sales_Volume) as Total_Volume, 
                avg(Mrp) as AVG_MRP, 
                sum(Mrp * Sales_Volume) as MRP_Sale_Vol 
                from 
                (
                    select 
                    Dist_Code, 
                    item_code, 
                    Sale_Inv_Date, 
                    Sales_Volume, 
                    Mrp 
                    from 
                    trn_billwise_itemwise_urban 
                    where 
                    Bill_Status = '{}' 
                    and Sale_Inv_Date between '{}' 
                    AND '{}' 
                    and Dist_Code in (
                        select 
                        customer_code 
                        from 
                        mst_sap_customer_master 
                        where 
                        company_code = '{}' 
                        and latest_record_ind = {} 
                        and channel_name = '{}'
                    )
                ) trn 
                join (
                        Select 
                        customer_code, 
                        customer_name, 
                        asm_area_code, 
                        asm_area_name, 
                        depot_code 
                        from 
                        mst_sap_customer_master 
                        where 
                        company_code = '{}' 
                        and latest_record_ind = {}
                    ) cust on trn.Dist_Code = cust.customer_code 
                join (
                        Select 
                        material_code, 
                        parent_material1_code, 
                        parent_material1_desc 
                        from 
                        mst_sap_material_master_latest 
                        where 
                        company_code = '{}' 
                        and latest_record_ind = {}
                    ) mat on trn.item_code = mat.material_code 
                group by 
                    last_day(Sale_Inv_Date), 
                    customer_code, 
                    customer_name, 
                    asm_area_code, 
                    asm_area_name, 
                    depot_code, 
                    parent_material1_code, 
                    parent_material1_desc 
                order by 
                    last_day(Sale_Inv_Date)""".format(
            "Delivered", start_date, end_date, "MIL", 1, channel, "MIL", 1, "MIL", 1
        )

        connection = self.get_dbconnection( db_name= 'PROD')
        results = read_sql(con=connection, sql=query)
        mrp_data = DataFrame(results)
        mrp_data.columns = [
            "month_date",
            "customer_code",
            "customer_name",
            "asm_area_code",
            "asm_area_name",
            "depot_code",
            "parent_material1_code",
            "parent_material1_desc",
            "Total_Volume",
            "AVG_MRP",
            "MRP_Sale_Vol",
        ]

        mrp_data.loc[(mrp_data.depot_code == "D352"), "depot_code"] = "D356"
        mrp_data.loc[(mrp_data.depot_code == "D353"), "depot_code"] = "D356"
        return mrp_data


    def get_material_master_table( self):
        """
        Fetch the material info from the mst_sap_material_master_latest.

        Return:
        material_master: pandas dataframe
            - material master information in dataframe

        """

        connection = self.get_dbconnection( db_name= 'PROD')
        material_master_query = """select  material_code, parent_material1_code, material_group_code, material_group_desc
                                            from mst_sap_material_master_latest where company_code='MIL' and latest_record_ind='1'"""
        material_master = read_sql_query(material_master_query, con=connection)
        material_master.rename(
            columns={"material_code": "sku", "parent_material1_code": "PSKU"}, inplace=True
        )
        return material_master


    def get_customer_master_table( self, channel):
        """
        Fetch the customer data from the mst_sap_customer_master table.

        Input:
            channel: str
            - channel name for which customer details to be fetched

        Return:
            customer_master: pandas dataframe
            - customer master information in dataframe

        """

        connection = self.get_dbconnection( db_name= 'PROD')
        customer_master_query = """select customer_code, asm_area_code, depot_code, depot_name from mst_sap_customer_master where
                                        company_code= 'MIL' and latest_record_ind='1' and channel_name='{}'  """.format(
            channel
        )
        customer_master = read_sql_query(customer_master_query, con=connection)
        return customer_master


    def get_ec_pc_data( self, start_date, end_date, CHANNEL_NAME):
        """
        Fetch the EC & PC data from trn_billwise_itemwise_urban table.

        Input:
            start_date: str
            - start data from data is fetched in format yyyy-mm-dd

            end_date: str
            - end date till the ec pc data to be fetched in format yyyy-mm-dd

            CHANNEL_NAME: str
            - channel name for which ec & pc data be fetched

        Return:
            ec_pc_data: pandas dataframe
            - dataframe consisting ec pc data
        """

        query = """ SELECT
                            asm_area_code,
                            depot_code,
                            last_day(Sale_Inv_Date) as month_date
                            ,mst_cust.channel_name
                            ,trn.Parent_Material_Code
                            ,count(distinct(concat(trn.Dist_Code, trn.retailer_code))) as ec
                            ,count(distinct(Sale_Inv_No)) as pc

                    FROM
                            trn_billwise_itemwise_urban as trn
                            left join mst_sap_customer_master as mst_cust on trn.Dist_Code=mst_cust.customer_code and mst_cust.company_code='MIL' and mst_cust.latest_record_ind=1
                    WHERE
                            Sale_Inv_Date>='{}'
                            and Sale_Inv_Date< '{}'
                            and Net_Value>0
                            and mst_cust.channel_name = '{}'

                    GROUP BY
                            asm_area_code,
                            depot_code,
                            last_day(Sale_Inv_Date),
                            mst_cust.channel_name,
                            trn.Parent_Material_Code

                """.format(
            start_date, end_date, CHANNEL_NAME
        )

        connection = self.get_dbconnection( db_name= 'PROD')
        results = read_sql(con=connection, sql=query)

        ec_pc_data = DataFrame(results)
        return ec_pc_data


    def get_reg_table_data( self, channel):
        """
        Fetch the customer data from the mst_sap_customer_master table.

        Input:
            channel: str
            - channel name for which customer details to be fetched

        Return:
            reg_forecast_data: pandas dataframe
            - reg forecast data available in the reg_forecast_table

        """

        connection = self.get_dbconnection( db_name= 'PROD')
        reg_query = f"""  select *  from   {channel.lower()}_reg_forecast"""
        reg_forecast_data = read_sql_query(reg_query, con=connection)
        return reg_forecast_data


    def read_club_sku_table( self):
        """
        Fetch the club sku information from madhav_clubsku table.

        Return
            club_sku_data: pandas dataframe
            - dataframe contains all the results from the club sku table.

        """
        connection = self.get_dbconnection( db_name= 'PROD')
        query = """select * from madhav_clubsku"""
        club_sku_data = read_sql(con=connection, sql=query)
        return club_sku_data


    def read_qtr_ind_rate_table( self):
        """
        Fetch the club sku information from  DWH_SAP_INDEX_TURNOVER_MONTHWISE table.

        Return:
            qtr_ind_rate_data: pandas dataframe
            - dataframe contains all the results from the index rate table.
        """
        connection = self.get_dbconnection( db_name= 'PROD')
        query = """select * from DWH_SAP_INDEX_TURNOVER_MONTHWISE"""
        qtr_ind_rate_data = read_sql(con=connection, sql=query)
        qtr_ind_rate =  qtr_ind_rate_data[['date', 'brand_code', 'turnover']]
        qtr_ind_rate = qtr_ind_rate.rename(columns= {'date':'month_date', 'turnover':'qtr_ind_rate'})
        return qtr_ind_rate


    def fetch_mil_table_from_db( self, table_name=None, query = None, timestamp_col = 'update_timestamp',filter_date=None):

        connection = self.get_dbconnection( db_name= 'DEV')

        if query:
            data = read_sql(con=connection, sql=query)
        else:
            query = "select * from {}".format(table_name)
            data = read_sql(con=connection, sql=query)

        if filter_date:
            data = data[ data[timestamp_col] == to_datetime(filter_date)]
            print( "{} data updated at {}".format( table_name, max(data[timestamp_col])))
        data.drop(timestamp_col, axis=1, inplace=True, errors='ignore')
        # else:
        #     data = data[ data[timestamp_col] == max(data[timestamp_col])]
        return data
    
    def fetch_mil_df_data( self, forecast_month, channel, timestamp_col = 'update_timestamp' ):
        
        connection = self.get_dbconnection( db_name= 'DEV')
        query = "select * from {} where channel='{}' and run_month='{}'".format('TRN_MIL_DF_DATA', channel, forecast_month)
        data = read_sql(con=connection, sql=query)
    
        print( " data updated at {}".format( max(data[timestamp_col])))
        data.drop(timestamp_col, axis=1, inplace=True)
        return data

