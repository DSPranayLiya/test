"""
Run the Streamlit Dashboard to analyses the RBF results.
"""

from ..helper import pd, np, MonthEnd, tqdm, Parallel, delayed, cpu_count, json, \
                    sqlalchemy, URL, json, relativedelta, MonthEnd, time, os, \
                    st, px, go, pio, make_subplots, BytesIO, perform_left_join

from ..helper import GetGeneralPipelineInput
from ..data import FetchSnowflakeData, SnowflakeDataIngestion

st.set_page_config(
    page_title="Dashboard for Data Check",
    page_icon="1200px-Marico_Logo.svg.png",
    layout="wide",
)


@st.cache_data()
def read_rbf_data( channel, run_month, DATE_COL, rbf_trend_table, rbf_range_est_table ):

    portfolio_mapping = FetchSnowflakeData().fetch_mil_table_from_db( query= " select * from {}".format('MST_MIL_PORTFOLIO_MAPPING'))
    portfolio_mapping.drop('update_timestamp',axis=1, inplace=True, errors='ignore')
    portfolio_mapping.columns = [col.lower() for col in portfolio_mapping]


    rbf_pt_est_data_query =  """select * from {} where "{}" = '{}' and "channel" = '{}' """.format( 
                        rbf_trend_table, 'run_month', run_month, channel)

    pt_est_data = FetchSnowflakeData().fetch_mil_table_from_db( query=rbf_pt_est_data_query)
    pt_est_data.loc[:,DATE_COL] = pd.to_datetime( pt_est_data[DATE_COL])
    # add the bpm values
    for col in pt_est_data.columns:
        if ('pred' in col)or('train' in col):
            updated_col =  col + '_vol'
            pt_est_data = pt_est_data.rename(columns = { col: updated_col})
            pt_est_data.loc[:, col+"_value"] = (pt_est_data[updated_col] * pt_est_data['qtr_ind_rate'])/10**7
        if ('sec_vol_actuals_rum_month'   == col)or('sec_vol_actuals_rum_month_treated'   == col):
            pt_est_data.loc[:, col+"_value"] = (pt_est_data[col] * pt_est_data['qtr_ind_rate'])/10**7

    pt_est_data = perform_left_join( pt_est_data, portfolio_mapping, join_on='brand_code', filter_cols = 'portfolio_name')

    rbf_range_ft_query = """select * from {} where "{}" = '{}' and "channel" = '{}' """.format( 
                         rbf_range_est_table, 'run_month', run_month, channel)
    range_est_data = FetchSnowflakeData().fetch_mil_table_from_db( query=rbf_range_ft_query)
    range_est_data.loc[:, DATE_COL] = pd.to_datetime( range_est_data[ DATE_COL])
    range_est_data.loc[:,'parent_material_code'] = range_est_data['key']
    # add cal bpm values
    for col in range_est_data :
        if ('percent' in col)or('point_est' in col):
            updated_col =  col + '_vol'
            range_est_data = range_est_data.rename(columns = { col: updated_col})
            range_est_data.loc[:, col+"_value"] = (range_est_data[updated_col] * range_est_data['qtr_ind_rate'])/10**7

    material_master = FetchSnowflakeData().get_material_master_table()
    material_master = material_master.rename(columns={'PSKU':'parent_material_code', 'material_group_code':'brand_code'})
    range_est_data = perform_left_join( range_est_data, material_master, join_on='parent_material_code', filter_cols = 'brand_code')
    range_est_data = perform_left_join( range_est_data, portfolio_mapping, join_on='brand_code', filter_cols = 'portfolio_name')
    range_est_data.loc[:, 'best_model_flag'] = range_est_data['best_model'] == range_est_data['model']
    
    
    return pt_est_data, range_est_data


class RBFStreamlitDashboard( GetGeneralPipelineInput):
    
    def __init__(self, input_dict, config):
        super().__init__(input_dict)
        self.config = config
        self.train_till_date = self.di_model_input['train_till_date']
        self.fetch_data_from_snowflake = FetchSnowflakeData().fetch_mil_table_from_db
        
        self.channel = None
        self.run_month = None

        self.calculation_metric = None
        self.threshold_value = None
        self.no_of_rows = None

        self.selected_best_model = None
        self.selected_shifting = None
        self.selected_smoothen_level = None
        self.selected_scaling_factor = None
        self.selected_model = None
        self.selected_run_type = None
    
    def update_model_selection_df(self, data):
        data.loc[:,'channel'] = self.channel
        rbf_final_result_df = pd.read_csv("./data/processed/rbf_final_result_selection.csv")
        rbf_final_result_df = rbf_final_result_df[~(rbf_final_result_df['channel']==self.channel)]
        rbf_final_result_df = pd.concat([rbf_final_result_df,data], ignore_index=True, axis=0)
        rbf_final_result_df.to_csv("./data/processed/rbf_final_result_selection.csv", index=False)
        st.warning(f"""Data Updated Successfully""", icon="✅")
        
    def calculate_trend(self, list_of_index, array_of_data, order):
        """
            Fits a simple regression line on the data and calculate 
            the trend & return the trend direction ( positive, negative
            and constant).
        """
        result = np.polyfit(list_of_index, list(array_of_data), order)
        slope = float(result[-2])
        if slope>0: trend = "positive"
        if slope<0: trend = "negative"
        if slope==0: trend = "constant"  
        return trend

    def convert_df( self, df):
        return df.to_csv(index=False).encode('utf-8')

    def trend_overall_detector(self, Key, df, target_column, key_col, order=1):
        """
            Calculate the trend for the data at a key level.

            Args:
                Key (str): Key for which trend to be calculated
                df (pandas dataframe): dataframe consisting data for all key
                key_col ( str | int): key column name
                order (int): the polynomial order to be fit on data
            
            Return:
                output (list): list consist Key name and trend for the key.
        """
        data_key = df[df[key_col]==Key]        
        if  self.train_till_date:
            data_key = data_key[data_key[ self.DATE_COL]<= self.train_till_date].reset_index(drop=True)
            if len(data_key)>2:
                list_of_index = data_key.index
                array_of_data = data_key[target_column].values
                trend =  self.calculate_trend(list_of_index, array_of_data,order)
            else:
                trend = "less DP"
        
        output = [ Key, trend]
        return output

    def calculate_cov( self, df, key):
        """
            Calculate the coefficient of variance at Key level.
        """
        cov_data = df[pd.to_datetime(df[self.DATE_COL])<= self.train_till_date]
        cov_data = cov_data[[key, self.DATE_COL, self.target_column]]
        cov_data = cov_data.groupby([key], as_index=False).agg({self.target_column:['mean','std']})
        cov_data.columns = [key, 'mean', 'std']
        cov_data["cov"] = cov_data.apply(lambda x: x['std']/x['mean'] if x['mean'] != 0 else np.inf, axis=1)
        cov_data = cov_data[ [ key, 'cov']]
        return cov_data

    def display_df(self, df, cols, title):

        data_title = "{} {} ...".format(title, ", ".join( cols))
        st.subheader(data_title)
        st.dataframe( df.head(self.no_of_rows))

        df = self.convert_df(df)
        file_name =  self.channel +'_'+ "_".join(data_title.replace('...','').split(' ')) + '.csv'
        save_file = os.path.join( self.location_to_save, file_name)
        st.download_button(label=f"Download Data",
                            data= df,
                            file_name=save_file,
                            mime="text/csv") 

    def plot_trend_chart(self, grouped_data_monthly, cols_to_agg, chart_title, y_axis):
        """
        Plot the trend chart on streamlit dashboard.

        Args:
            grouped_data_monthly (_type_): _description_
            cols_to_agg (_type_): _description_
            chart_title (_type_): _description_
            y_axis (_type_): _description_
        """
        fig = make_subplots(specs=[[{"secondary_y": True}]])

        for col in cols_to_agg:
            try:
                fig.add_trace(
                    go.Scatter(x=grouped_data_monthly[ self.DATE_COL], 
                                y=grouped_data_monthly[col], 
                                name=col, 
                                mode="lines"),
                )
            except Exception as e:
                pass

        fig.update_xaxes(title_text="month_date")
        fig.update_yaxes(title_text=y_axis, secondary_y=False)
        # fig.update_yaxes(title_text="Actual BPM in Cr", secondary_y=True,rangemode = 'tozero')   
        fig.update_layout(showlegend=True,title_text=chart_title)
        fig.update_layout(
                xaxis=dict(
                    rangeselector=dict(
                        buttons=list([
                            dict(count=6,
                                label="6m",
                                step="month",
                                stepmode="backward"),
                            dict(count=1,
                                label="1y",
                                step="year",
                                stepmode="backward"),
                            dict(count=2,
                                label="2y",
                                step="year",
                                stepmode="backward"),
                            dict(count=3,
                                label="3y",
                                step="year",
                                stepmode="backward"),
                            dict(step="all")
                        ])
                    ),
                    type="date",
                    
                ))

        st.plotly_chart(fig, use_container_width=True)

        
    def pivot_range_based_data(self, range_est_data, groupby_cols):
        """_summary_
        """
        range_est_data.columns = [ val.replace('percent', '%') for val in range_est_data.columns]

        if self.calculation_metric == 'Value':
            agg_cols = [val for val in range_est_data.columns if ('value' in val)and('width' not in val)]
        else:
            agg_cols = [val for val in range_est_data.columns if ('vol' in val)and('width' not in val)]

        if self.selected_model == 'All':
            self.selected_model = range_est_data['model'].unique().tolist()
        elif type(self.selected_model) != list:
            self.selected_model = [ self.selected_model]

        range_est_data = range_est_data[ (range_est_data['best_model_flag'] == self.selected_best_model)&\
                                        (range_est_data['scaling_factor'] == self.selected_scaling_factor)&\
                                        (range_est_data['shifting'] == self.selected_shifting)&\
                                        (range_est_data['smoothen_level'] == self.selected_smoothen_level)&\
                                        (range_est_data['model'].isin(self.selected_model))]

        grouped_data = range_est_data.groupby( by= [self.DATE_COL] +groupby_cols )[ agg_cols].agg(sum)

        grouped_data.columns = [ col.replace('vol','').replace('value','').replace( "_",'') for col in grouped_data.columns ]
        
        grouped_data['70%_Width'] = (( grouped_data['eightyfive%'] - grouped_data['fifteen%'])/(2*grouped_data['pointest']))*100
        grouped_data['80%_Width'] = (( grouped_data['ninety%'] - grouped_data['ten%'])/(2*grouped_data['pointest']))*100
        grouped_data['90%_Width'] = (( grouped_data['ninetyfive%'] - grouped_data['five%'])/(2*grouped_data['pointest']))*100
        
        self.display_df(df=grouped_data, cols=groupby_cols, title='RBF Range Forecast')    


    def final_data_selection(self, data, rbf_final_result_df ):
        """
        
        """
        final_model_selection_df = rbf_final_result_df.copy()
        data.loc[:, 'model'] = data['model'].str.lower()
        high_cov_brands = data[data['model']=='high_cov']['brand_code'].unique().tolist()
        
        st.subheader(f"Select Final Model Choice ...")
        final_model_selection_df = st.data_editor(final_model_selection_df, key='final_model_choices')
        if st.button('Update Final Selection Data'):
            self.update_model_selection_df( data=final_model_selection_df.copy())
            
        high_cov_data = data[data['brand_code'].isin(high_cov_brands)]
        final_model_selection_df =  final_model_selection_df[~final_model_selection_df['brand_code'].isin(high_cov_brands)]
        final_data = pd.DataFrame()
        for row in final_model_selection_df.values:
            brand, model, smoothen_level, shifting, scaling = row
            selected_data = data[ (data['brand_code'] == brand)&\
                                  (data['model']==model)&\
                                  (data['smoothen_level']==smoothen_level)&\
                                  (data['shifting']==shifting)&\
                                  (data['scaling_factor']==scaling)]
            final_data = pd.concat([final_data, selected_data])
        
        final_data = pd.concat([ final_data, high_cov_data], axis=0, ignore_index=True)

        final_data.loc[:,'In Range'] = (final_data['point_est_vol']>=final_data['five_%_vol'])&\
                                        (final_data['point_est_vol']<=final_data['ninety_five_%_vol'])
        
        final_data.loc[:, 'High Volatile Brand Result'] = final_data['brand_code'].isin(high_cov_brands)
        selected_col =  ['channel', 'month_date', 'brand_code', 'key', 'point_est_vol', 'qtr_ind_rate',
                        'five_%_vol', 'ten_%_vol', 'fifteen_%_vol', 'twenty_%_vol',
                        'eighty_%_vol', 'eighty_five_%_vol', 'ninety_%_vol',
                        'ninety_five_%_vol', 'sixty_%_interval_width_vol',
                        'seventy_%_interval_width_vol', 'eighty_%_interval_width_vol',
                        'ninety_%_interval_width_vol', 'In Range','smoothen_level', 'shifting',
                        'scaling_factor', 'model', 'best_model', 'best_model_flag',
                        'High Volatile Brand Result' ,'run_type' ]
        final_data = final_data[selected_col]
        

        final_data.columns = ['Channel', 'Forecast_Month', 'brand_code', 'key',
                            'Pt Est', 'qtr_ind_rate', '5%', '10%', '15%', '20%', '80%', '85%',
                            '90%', '95%', '60% Interval Width', '70% Interval Width',
                            '80% Interval Width', '90% Interval Width', 'In Range',
                            'smoothen_level', 'Shifting', 'Scaling Factor', 'Model', 'Best Model',
                            'Best Model Flag', 'High Volatile Brand Result', 'Month', ]

        self.display_df( df=final_data, cols = '', title=f'Final {self.channel} RBF Data ...')
        
        if st.button('Push Final Result To Snowflake ...'):
            query = f"""Select distinct("run_month") from TRN_MIL_RBF_RESULTS_SHARED
             where "run_month" = '{self.run_month}' and "Channel"='{self.channel}' """
            
            run_months = self.fetch_data_from_snowflake(query=query)

            if len(run_months)>0:
                st.warning(f"""Data Already Present on Snowflake 
                for {self.channel} & {self.run_month}\nPlease Delete it and try again.""", icon="⚠️")
            else:
                st.warning(f"""Uploading Data""", icon="🌟")
                final_data['Forecast_Month'] = pd.to_datetime(final_data['Forecast_Month']).dt.tz_localize('UTC')
                SnowflakeDataIngestion().push_to_snowflake(df=final_data, snowflake_table_name='TRN_MIL_RBF_RESULTS_SHARED',
                                                            date=self.run_month)
                st.warning(f"""Data Pushed Successfully""", icon="✅")
            pass
 
    def perform_analysis(self, data_copy, range_est_data, groupby_cols, rbf_final_result_df):
        """
        
        """
        if type( groupby_cols)!=list: groupby_cols = [ groupby_cols]

        if len(groupby_cols)==1:
            chart_title = self.channel + " X " + groupby_cols[0]
        else:
            chart_title = self.channel + " X " + " X ".join(groupby_cols)

        cols_to_agg = []
        train_till_date = pd.to_datetime( self.run_month) - relativedelta(months=1) + MonthEnd(0)
        forecast_start_month = pd.to_datetime( self.run_month) + relativedelta(months=1) + MonthEnd(0)

        if self.calculation_metric == 'Volume':
            cols_to_agg = [ self.target_column, self.target_column+'_treated' ]
            y_axis = 'Volume'
            for col in data_copy.columns:
                if (('pred' in col)or('train' in col)) and ('value' not in col): cols_to_agg.append(col)
                
        elif self.calculation_metric == 'Value':
            y_axis = 'Value (Cr)'
            cols_to_agg = [self.target_column+'_value', self.target_column+'_treated_value']
            for col in data_copy.columns:
                if (('value' in col)or('train' in col))and ('vol' not in col): cols_to_agg.append(col)

        chart_cols = [ col for col in cols_to_agg if ('final' not in col)and('lms' not in col)]
        grouped_data_monthly = data_copy.groupby( [self.DATE_COL], as_index=False)[chart_cols].agg(sum)

        self.plot_trend_chart( grouped_data_monthly, cols_to_agg, chart_title, y_axis)
        self.pivot_range_based_data( range_est_data, groupby_cols)

        if type(groupby_cols) == list: key_col = "_".join( groupby_cols)
        train_data = data_copy[ data_copy[self.DATE_COL]<= train_till_date]
        train_data = train_data.groupby( [self.DATE_COL]+groupby_cols, as_index=False)[self.target_column].agg(sum)

        cols_to_agg = [col for col in cols_to_agg if ('train' not in col) and (self.target_column not in col)]

        cov_data = self.calculate_cov( train_data, key_col)
        output = Parallel(n_jobs = cpu_count()-2)(delayed( self.trend_overall_detector)
                                            ( Key, train_data, self.target_column, key_col,order=1
                                            )  
                                            for Key in tqdm(train_data[key_col].unique(), desc="Calculating Trend"))
        overall_trend_data = pd.DataFrame(output, columns=[ key_col, 'overall_trend'])

        forecasted_data = data_copy[data_copy[self.DATE_COL]>(train_till_date)]
        forecasted_data = forecasted_data.groupby( [self.DATE_COL]+groupby_cols, as_index=False)[cols_to_agg].agg(sum)


        forecasted_data = pd.merge( forecasted_data, cov_data, on=key_col, how='left')
        forecasted_data = pd.merge( forecasted_data, overall_trend_data, on=key_col, how='left')
        self.display_df( df=forecasted_data, cols = groupby_cols, title='Demand Forecast Data')
        self.final_data_selection(range_est_data, rbf_final_result_df )

    

    def get_rbf_run_dates(self):
        """
            This function query the data and get the dates for the 
            available results on the rbf data table.
        """
        query = f"""select distinct("run_month") from {self.config.RBF_TREND_DATA_TABLE}"""
        dates = self.fetch_data_from_snowflake(query=query)
        dates = dates.sort_values(by='run_month', ascending=False)['run_month'].tolist()
        return dates

    def run_streamlit_dashboard(self):
        """_summary_
        """

        available_dates = self.get_rbf_run_dates()
        self.run_month = st.sidebar.selectbox("Select Forecast Month: ", available_dates, key="selected_month")
        # run_month = str(( pd.to_datetime( run_month) - relativedelta(months=1) +MonthEnd(0)).date())
        
        self.channel = st.sidebar.selectbox("Select Channel: ", [ 'GT', 'MT', 'ECOM'],key="key_channel")
        self.calculation_metric = st.sidebar.selectbox("Select Target Column: ", [  'Value', 'Volume'],key="target_col")
        self.threshold_value = st.sidebar.number_input("Deviation Threshold: ",  value =15, key="threshold_val")
        self.no_of_rows = st.sidebar.number_input("Enter Display number of rows: ",  value =30, key="num_of_df_rows")

        rbf_final_result_df = pd.read_csv("./data/processed/rbf_final_result_selection.csv")
        rbf_final_result_df = rbf_final_result_df[rbf_final_result_df['channel']==self.channel].drop('channel',axis=1)

        if self.channel:
            #pt_est_data = self.read_rbf_data() #, last_forecast_data 
            pt_est_data, range_est_data = read_rbf_data( self.channel, self.run_month,
                                             self.DATE_COL, self.config.RBF_TREND_DATA_TABLE, 
                                             self.config.RBF_RUN_FORECAST_TABLE )

            filter_columns_to_show = ['portfolio_name', 'brand_code','key']
            filter_columns = st.sidebar.multiselect("Select Filter Columns:",filter_columns_to_show,key="key_filter_cols")

            if len(filter_columns)>0:
                for filter in filter_columns:
                    option = st.sidebar.multiselect(f"select filter for {filter}:", pt_est_data[filter].unique().tolist(),
                                key=f"key_{filter}")
                    if len(option)>0:
                        pt_est_data = pt_est_data.loc[pt_est_data[filter].isin(option)]
                        range_est_data = range_est_data.loc[ range_est_data[filter].isin(option)]
            
            run_types = range_est_data['run_type'].unique().tolist()
            self.selected_run_type = st.sidebar.selectbox("Select Run Type: ", run_types, key="run_type")
            
            best_model_flags = [ True, False]
            self.selected_best_model = st.sidebar.selectbox("Select Best Model: ", best_model_flags, key="best_model")
            self.selected_shifting = st.sidebar.selectbox("Select Shifting Value: ", [True, False], key="shifting_value")
            smoothen_levels = range_est_data['smoothen_level'].unique().tolist()
            self.selected_smoothen_level = st.sidebar.selectbox("Select Smoothen Level: ", smoothen_levels, key="smoothen_level")
            scaling_factors = range_est_data['scaling_factor'].unique().tolist()
            self.selected_scaling_factor = st.sidebar.selectbox("Select Scaling Factor: ", scaling_factors, key="scaling_factor")
            models = ['All'] +  range_est_data['model'].unique().tolist()
            self.selected_model = st.sidebar.selectbox("Select Model: ", models, key="model")

            hierarchy_cols_to_filter = [ 'portfolio_name', 'brand_code', 'parent_material_code']
            hierarchy_columns = st.sidebar.selectbox("Hierarchy for Data Check:", hierarchy_cols_to_filter,key="key_hierarchy")

            self.perform_analysis( pt_est_data.copy(),  range_est_data.copy(),hierarchy_columns, rbf_final_result_df )
        
        
