"""
This file run the streamlit app for MIL results.
Author: Pranjal Soni
"""

from ..helper import pd, np, MonthEnd, tqdm, Parallel, delayed, cpu_count, json, \
                    sqlalchemy, URL, json, relativedelta, MonthEnd, time, os, \
                    st, px, go, pio, make_subplots, BytesIO, perform_left_join

from ..helper import GetGeneralPipelineInput
from ..data import FetchSnowflakeData, SnowflakeDataIngestion

TARGET_COL = 'sec_vol_actuals_rum_month'

def fetch_mapping_data( train_till_date,  channel):
    """ 
    This function fetch the fetches the data such as npd_flags,
    seasonal_month_flag, free pskus flags. This columns can be 
    added to final data to filter the data.
    Args:
        train_till_date(str): it is required to fetch the data form snowflake for required month
        channel(str): Channel name 
    Return:
        mapping_data(pandas dataframe): dataframe consisting the flags columns 
    """
    forecast_month = str((pd.to_datetime(train_till_date) + relativedelta(months=1) +MonthEnd(0)).date())
    mapping_data_query = f"""SELECT DISTINCT MONTH_DATE, ASM_AREA_CODE, DEPOT_CODE, parent_material_code, NPD_FLAG, FREE, SEASONAL_MONTH_FLAG 
       FROM DEV_DB.DATA_SCIENCE.TRN_MIL_DF_DATA
       WHERE RUN_MONTH = '{forecast_month}' AND CHANNEL = '{channel}' """
    
    mapping_data = FetchSnowflakeData().fetch_mil_table_from_db( query=mapping_data_query)
    mapping_data.columns = [ col.lower() for col in mapping_data.columns]
    return mapping_data


def get_last_month_shared_data( train_till_date, channel, gran_cols, DATE_COL):
    """
    Fetch the last month shared numbers.
    Args:
        forecast_start_date ( pandas datetime): min dates for forecast months

    Returns:
        last_forecast_data ( pandas datetime): data consisting last month data shared
    """
    print("Fetching LMS Data ... ")
    last_forecast_data_query = "select * from {} where {} = '{}' and channel_name = '{}' ".format( 
                                'TRN_MIL_DF_FINAL_SHARED', 'month_date', train_till_date, channel)
    last_forecast_data = FetchSnowflakeData().fetch_mil_table_from_db( query =last_forecast_data_query)
    last_forecast_data.loc[:,'forecast_month'] = pd.to_datetime( last_forecast_data['forecast_month'])
    last_forecast_data = last_forecast_data[['forecast_month'] + gran_cols + ["pred_vol"]]
    last_forecast_data.columns = [ DATE_COL] + gran_cols + ['lms_vol']
    last_forecast_data = last_forecast_data.groupby( [DATE_COL] + gran_cols, as_index=False)[['lms_vol']].agg(sum)
    print("LMS Data Fetched Successfully {}...\n".format(last_forecast_data.shape))
    return last_forecast_data

def fetch_forecast_data( train_till_date, channel ):
    """ 
    This function fetch the forecast data from the snowflake.
    Args:
        train_till_date(str): it is required to fetch the data form snowflake for required month
        channel(str): Channel name 
    Return:
        forecast_data(pandas dataframe): dataframe consisting forecast results
    """
    print("Fetching Forecast Data ... ")
    forecast_date = str((pd.to_datetime(train_till_date) + relativedelta(months=1) +MonthEnd(0)).date())
    forecast_data_query =  """select * from {} where "run_month" = '{}' and CHANNEL = '{}' """.format( 
                        'TRN_MIL_FORECAST_RESULTS', forecast_date, channel)
    forecast_data = FetchSnowflakeData().fetch_mil_table_from_db(query=forecast_data_query)

    forecast_data = forecast_data[[  'month_date', 'key', 'asm_area_code', 'depot_code', 'parent_material_code',
                                     'brand_code',  'model_type', 'pred', 
                                     'best_model', 'series_length', 'qtr_ind_rate', 'train_till',
                                     'predicting_month' ]]
    forecast_data.loc[:,'month_date'] = pd.to_datetime(forecast_data['month_date'])
    forecast_data = forecast_data[forecast_data['predicting_month']!= 'M']
    print("Forecast Data Fetched Successfully with shape {} ...\n".format(forecast_data.shape))
    return forecast_data


def fetch_rbf_data(channel, train_till_date, DATE_COL):
    """
    Fetch the range based results. RBF results further used to disaggregated into MIL final results.
    Args:
        channel(str): Channel Name 
        train_till_date(str): date for which rbf results are required
        DATE_COL(str): date column name
    Return:
        rbf_shared_data(pandas dataframe): Point Estimates for the RBF results
    """

    train_till_date = str((pd.to_datetime(train_till_date) + relativedelta(months=1) +MonthEnd(0)))
    data_check_query = """select DISTINCT("run_month") from {} where "{}" = '{}' and "Channel" = '{}' """.format( 
                                'TRN_MIL_RBF_RESULTS_SHARED', 'run_month', train_till_date, channel)
    data_to_check = FetchSnowflakeData().fetch_mil_table_from_db( query =data_check_query)

    if len(data_to_check) >0 :
        
        rbf_shared_data_query = """select "Forecast_Month", "key", "Pt Est" from {} where "{}" = '{}' and "Channel" = '{}' """.format( 
                                    'TRN_MIL_RBF_RESULTS_SHARED', 'run_month', train_till_date, channel)
        rbf_shared_data = FetchSnowflakeData().fetch_mil_table_from_db( query =rbf_shared_data_query)
        rbf_shared_data.columns = [DATE_COL, 'parent_material_code', 'rbf_pt_est']
        rbf_shared_data = rbf_shared_data.drop_duplicates(subset=[ DATE_COL, 'parent_material_code'], keep='first')
    else:
        rbf_shared_data = pd.DataFrame()
    return rbf_shared_data




# def perform_final_model_selection()

@st.cache_data()
def read_rbf_data( channel, train_till_date, gran_cols, DATE_COL ):
    # print('Reading Scaling Table ... ')
    # scaling_data_query = f""" SELECT * FROM DEV_DB.DATA_SCIENCE.TRN_MIL_SCALING_MASTER """
    # scaling_data = FetchSnowflakeData().fetch_mil_table_from_db(query= scaling_data_query)
    # scaling_data.columns = ['portfolio_name', 'model', 'factor', 'channel']
    # scaling_data.drop('channel', axis=1, inplace=True)

    print('Reading Portfolio Mapping ... ')
    portfolio_mapping = FetchSnowflakeData().fetch_mil_table_from_db( query= " select * from {}".format('MST_MIL_PORTFOLIO_MAPPING'))
    portfolio_mapping.drop('update_timestamp',axis=1, inplace=True, errors='ignore')
    portfolio_mapping.columns = [col.lower() for col in portfolio_mapping]

    print('Reading Trend Data ... ')
    trend_data_query =  """select * from {} where {} = '{}' and channel = '{}' """.format( 
                        'TRN_MIL_DF_TRAIN_FORECAST ', 'train_till_date', train_till_date, channel)

    trend_data = FetchSnowflakeData().fetch_mil_table_from_db( query=trend_data_query)
    trend_data.loc[:,DATE_COL] = pd.to_datetime( trend_data[DATE_COL])
    trend_data.columns = [col.lower() for col in trend_data.columns]

    # add the bpm values
    for col in trend_data.columns:
        if ('pred' in col)or('train' in col):
            updated_col =  col + '_vol'
            trend_data = trend_data.rename(columns = { col: updated_col})
            try:
                trend_data.loc[:, col+"_value"] = (trend_data[updated_col] * trend_data['qtr_ind_rate'])/10**7
            except TypeError:
                pass

        if ('sec_vol_actuals_rum_month'   == col)or('sec_vol_actuals_rum_month_treated'   == col):
            trend_data.loc[:, col+"_value"] = (trend_data[col] * trend_data['qtr_ind_rate'])/10**7

    print('Reading Material Master ...')
    material_master = FetchSnowflakeData().get_material_master_table()
    material_master = material_master.rename(columns={'PSKU':'parent_material_code', 'material_group_code':'brand_code'})
    trend_data = perform_left_join( trend_data, material_master, join_on='parent_material_code', filter_cols = 'brand_code')
    trend_data = perform_left_join( trend_data, portfolio_mapping, join_on='brand_code', filter_cols = 'portfolio_name')

    # forecast_data = trend_data[ trend_data[DATE_COL]> train_till_date]
    forecast_data = fetch_forecast_data( train_till_date, channel )
    forecast_data = perform_left_join( forecast_data, portfolio_mapping, join_on='brand_code', filter_cols = 'portfolio_name')

    last_shared_data = get_last_month_shared_data(train_till_date, channel, gran_cols, DATE_COL)
    forecast_data = perform_left_join( forecast_data, last_shared_data,  join_on=gran_cols+[DATE_COL])
    mapping_data = fetch_mapping_data( train_till_date, channel)
    forecast_data.loc[:,'lms_value'] = (forecast_data['lms_vol'] * forecast_data['qtr_ind_rate'])/10**7

    forecast_data = perform_left_join( forecast_data, mapping_data,  join_on=gran_cols+[DATE_COL])
    trend_data = perform_left_join( trend_data, mapping_data,  join_on=gran_cols+[DATE_COL])
    rbf_shared_data = fetch_rbf_data(channel=channel, train_till_date=train_till_date, DATE_COL=DATE_COL)
    return trend_data, forecast_data, rbf_shared_data


class MILStreamlitDashboard( GetGeneralPipelineInput):
    
    def __init__(self, input_dict, config):
        super().__init__(input_dict)
        self.config = config
        self.train_till_date = self.di_model_input['train_till_date']
        self.fetch_data_from_snowflake = FetchSnowflakeData().fetch_mil_table_from_db
        self.gran_cols = input_dict['gran_cols']
        self.pred_col = 'final_pred_vol'

        self.channel = None
        self.run_month = None

        self.calculation_metric = None
        self.threshold_value = None
        self.no_of_rows = None
        self.selected_run_type = None
    
    def create_date_range(self, end_date, lag, freq):
        """
            This function return on the given freq
            and start date is month less than 
        """
        time_range = pd.date_range( start = pd.to_datetime(end_date)-relativedelta(months=lag), \
                                end= pd.to_datetime( end_date), freq=freq)
        time_range= [str(date.date()) for date in time_range.to_list()]
        return time_range

    def calculate_trend(self, list_of_index, array_of_data, order):
        """
            Fits a simple regression line on the data and calculate 
            the trend & return the trend direction ( positive, negative
            and constant).
        """
        result = np.polyfit(list_of_index, list(array_of_data), order)
        slope = float(result[-2])
        if slope>0: trend = "positive"
        if slope<0: trend = "negative"
        if slope==0: trend = "constant"  
        return trend

    def convert_df( self, df):
        return df.to_csv(index=False).encode('utf-8')

    def trend_overall_detector(self, Key, df, target_column, key_col, order=1):
        """
            Calculate the trend for the data at a key level.

            Args:
                Key (str): Key for which trend to be calculated
                df (pandas dataframe): dataframe consisting data for all key
                key_col ( str | int): key column name
                order (int): the polynomial order to be fit on data
            
            Return:
                output (list): list consist Key name and trend for the key.
        """
        data_key = df[df[key_col]==Key]        
        if  self.train_till_date:
            data_key = data_key[data_key[ self.DATE_COL]<= self.train_till_date].reset_index(drop=True)
            if len(data_key)>2:
                list_of_index = data_key.index
                array_of_data = data_key[target_column].values
                trend =  self.calculate_trend(list_of_index, array_of_data,order)
            else:
                trend = "less DP"
        
        output = [ Key, trend]
        return output

    
    def to_excel( self, df):
        """
            Write the dataframe into excel.
        """

        output = BytesIO()
        writer = pd.ExcelWriter(output, engine='xlsxwriter')
        df.to_excel(writer, index=False, sheet_name='Sheet1')
        workbook = writer.book
        worksheet = writer.sheets['Sheet1']
        format1 = workbook.add_format({'num_format': '0.00'}) 
        worksheet.set_column('A:A', None, format1)  
        writer.save()
        processed_data = output.getvalue()
        return processed_data

    def calculate_cov( self, df, key, target_column):
        """
            Calculate the coefficient of variance at Key level.
        """
        cov_data = df[pd.to_datetime(df[self.DATE_COL])<= self.train_till_date]
        cov_data = cov_data[[key, self.DATE_COL, target_column]]
        cov_data = cov_data.groupby([key], as_index=False).agg({target_column:['mean','std']})
        cov_data.columns = [key, 'mean', 'std']
        cov_data["cov"] = cov_data.apply(lambda x: x['std']/x['mean'] if x['mean'] != 0 else np.inf, axis=1)
        cov_data = cov_data[ [ key, 'cov']]
        return cov_data

    

    def display_df(self, df, cols, title):

        data_title = "{} {} ...".format(title, ", ".join( cols))
        st.subheader(data_title)
        st.dataframe( df.head(self.no_of_rows))

        df = self.convert_df(df)
        file_name =  self.channel +'_'+ "_".join(data_title.replace('...','').split(' ')) + '.csv'
        save_file = os.path.join( self.location_to_save, file_name)
        st.download_button(label=f"Download Data",
                            data= df,
                            file_name=save_file,
                            mime="text/csv") 


    def fetch_mapping_data( self, forecast_month):
        """
        Read the mapping columns from the snowflake table.
        """
        mapping_data_query = f"""SELECT DISTINCT MONTH_DATE, ASM_AREA_CODE, DEPOT_CODE, parent_material_code, 
        NPD_FLAG, FREE, SEASONAL_MONTH_FLAG , FROM DEV_DB.DATA_SCIENCE.TRN_MIL_DF_DATA
        WHERE FORECAST_MONTH = '{forecast_month}' AND CHANNEL = '{self.channel}' """
        
        mapping_data = self.fetch_data_from_snowflake( query=mapping_data_query)
        mapping_data.columns = [ col.lower() for col in mapping_data.columns]
        return mapping_data

    def plot_trend_chart(self, grouped_data_monthly, cols_to_agg, chart_title, y_axis):
        """
        Plot the trend chart on streamlit dashboard.

        Args:
            grouped_data_monthly (_type_): _description_
            cols_to_agg (_type_): _description_
            chart_title (_type_): _description_
            y_axis (_type_): _description_
        """
        fig = make_subplots(specs=[[{"secondary_y": True}]])

        for col in cols_to_agg:
            try:
                fig.add_trace(
                    go.Scatter(x=grouped_data_monthly[ self.DATE_COL], 
                                y=grouped_data_monthly[col], 
                                name=col, 
                                mode="lines"),
                )
            except Exception as e:
                pass

        fig.update_xaxes(title_text="month_date")
        fig.update_yaxes(title_text=y_axis, secondary_y=False)
        # fig.update_yaxes(title_text="Actual BPM in Cr", secondary_y=True,rangemode = 'tozero')   
        fig.update_layout(showlegend=True,title_text=chart_title)
        fig.update_layout(
                xaxis=dict(
                    rangeselector=dict(
                        buttons=list([
                            dict(count=6,
                                label="6m",
                                step="month",
                                stepmode="backward"),
                            dict(count=1,
                                label="1y",
                                step="year",
                                stepmode="backward"),
                            dict(count=2,
                                label="2y",
                                step="year",
                                stepmode="backward"),
                            dict(count=3,
                                label="3y",
                                step="year",
                                stepmode="backward"),
                            dict(step="all")
                        ])
                    ),
                    type="date", 
                ))
        st.plotly_chart(fig, use_container_width=True)
        
    
    def perform_final_model_selection(self, scaling_table, data, apply_scaling=True):
        """
        Multiply the forecast month with scaling to generate final forecast 
        Args:
            scaling_table: pandas dataframe
            - scaling mapping with portfolio
            
            forecast_data : pandas dataframe
            - dataframe consisting all models forecast result

        Returns:
            final_output: pandas dataframe
            - data with scaling forecast columns as final pred
        """

        final_output = pd.DataFrame()
        for row in scaling_table.values:
            portfolio, model, factor = row
            if pd.isna(portfolio)==False:
                try:
                    filtered_data = data[ (data['portfolio_name'] == portfolio)&(data['model_type'].str.upper() == model.upper())]
                    filtered_data.loc[:,'final_pred_vol'] = filtered_data[filtered_data['model_type'].str.upper()==model.upper()]['pred']
                    if apply_scaling:
                        filtered_data.loc[:,'scaling'] = factor
                        filtered_data.loc[:,'final_pred_vol'] = filtered_data.loc[:,'pred']*filtered_data.loc[:,'scaling']
                    filtered_data.loc[:,'final_pred_value'] = (filtered_data.loc[:,'final_pred_vol']*filtered_data.loc[:,'qtr_ind_rate'])/10**7
                    final_output = pd.concat([ final_output, filtered_data], axis=0, ignore_index=True)
                except Exception as e:
                    print(e)
                    pass
                
        other_keys_data = data[~data['key'].isin(final_output['key'].unique())]
        other_keys_data.loc[:,'final_pred_vol'] = other_keys_data.loc[:,'pred']
        other_keys_data.loc[:,'final_pred_value'] = (other_keys_data.loc[:,'final_pred_vol']*other_keys_data.loc[:,'qtr_ind_rate'])/10**7
        final_output = pd.concat([final_output,other_keys_data], axis=0, ignore_index=True)
        
        final_output.loc[ final_output['final_pred_vol']<0, 'final_pred_vol'] = 0
        final_output.loc[ final_output['final_pred_value']<0, 'final_pred_value'] = 0
        return final_output


    def calculate_deviation(self, df, new_val, old_val):
        """
        Calculate the deviation of new values from old values.
        
        Args:
            df: pandas dataframe
            - dataframe having all the data values 
            
            new_val: str
            - column name having new values
            
            old_val: str
            - column name having old values

        Return:
            df: pandas dataframe
            - updated dataframe with deviation column created
            
            col_created: str
            - deviation column name
        """
        col_created = f'deviation_from_{old_val}'
        df[col_created] = ((df[new_val]-df[old_val])/abs(df[old_val]))*100
        return df, col_created

    def calculate_deviation_flags(self, forecast, new_added_cols):
        """
        Generate the deviation flags.
        Value will be 1 if deviation is greater then threshold value otherwise 0.
        
        Args:
            forecast: pandas dataframe
            - dataframe having forecasted values
            
            new_added_cols: list
            - list of columns last sales metrics
            
        Return:
            forecast: pandas dataframe
            - input forecast data with flags column added
            
            flag_cols: list
            - Newly added flag columns
        """
        deviation_cols = []
        forecast.reset_index(drop=True, inplace=True)
        for key,value in new_added_cols.items():
            if self.calculation_metric== 'Volume': new_val = TARGET_COL
            if self.calculation_metric== 'Value': new_val = TARGET_COL + '_value'
            for col in value:
                forecast,col_created =  self.calculate_deviation(df=forecast, new_val=new_val, old_val=col)
                deviation_cols.append(col_created)

        threshold = self.threshold_value
        flag_cols = []

        for dev_col in deviation_cols:
                col_created = f"{dev_col}_flag"
                forecast.loc[((forecast[dev_col] < -threshold) | (forecast[dev_col]>threshold)),col_created] = 1
                forecast[col_created].fillna(0, inplace=True)
                forecast[ dev_col] = forecast[ dev_col].round(2).astype(str) + '%'
                flag_cols.append(col_created)

        return forecast, flag_cols

    def create_date_range(self, end_date, lag, freq):
        """
            This function return on the given freq
            and start date is month less than 
        """
        time_range = pd.date_range( start = pd.to_datetime(end_date)-relativedelta(months=lag), \
                                end= pd.to_datetime( end_date), freq=freq)
        time_range= [str(date.date()) for date in time_range.to_list()]
        return time_range

    def calculate_past_sales( self, df,  key, col, rolling_size, col_name, shift_size=1, 
                                    if_sum=False, if_shift_only=False):
        """
        
        """
        if if_sum==True:
            df[col_name] = df.sort_values([ key, self.DATE_COL],ascending=True).\
                            groupby([key],as_index=False)[col].\
                            transform(lambda x: x.rolling(rolling_size, min_periods=1).sum().shift(shift_size))
        elif if_shift_only==True:
            df[col_name] = df.sort_values([ key, self.DATE_COL],ascending=True).\
                                groupby([ key],as_index=False)[col].shift(shift_size)
        else:
            df[col_name] = df.sort_values([ key,self.DATE_COL],ascending=True).\
                                groupby([ key],as_index=False)[col].\
                                transform(lambda x: x.rolling(rolling_size,
                                                            min_periods=1).mean().shift(shift_size))
        return df

    def rbf_data_disaggregation(self, mil_data, rbf_shared_data, target_column):
        """
        This function read the rbf shared results.
        Args:
            channel (str): Channel Name
            train_till_date (str): date till the data is trained
            DATE_COL (str): date column name

        Returns:
            rbf_data(pandas dataframe): rbf shared data
        """
        if len(rbf_shared_data) >0 :
            # dis-aggregate rbf results 
            sub_mil_data = mil_data[mil_data['parent_material_code'].isin(rbf_shared_data['parent_material_code'])]
            if len(sub_mil_data)>0:
                sub_mil_data_grouped = sub_mil_data.groupby(by=[self.DATE_COL, 'parent_material_code'], as_index=False)[target_column].agg(sum)
                sub_mil_data_grouped.columns = [self.DATE_COL, 'parent_material_code', 'agg_sum']
                sub_mil_data = pd.merge(sub_mil_data, sub_mil_data_grouped, on=[self.DATE_COL, 'parent_material_code'], how='left')
                sub_mil_data['contribution'] = sub_mil_data[target_column]/ sub_mil_data['agg_sum']
                sub_mil_data = pd.merge(sub_mil_data, rbf_shared_data, on=[self.DATE_COL, 'parent_material_code'], how='left')

                for key in sub_mil_data[sub_mil_data['contribution'].isna()]['parent_material_code'].unique():
                    sub_mil_data.loc[sub_mil_data['parent_material_code'] == key, 'contribution'] = 1/len(sub_mil_data[sub_mil_data['parent_material_code'] == key ])
                    
                mil_data = mil_data[~mil_data['parent_material_code'].isin(sub_mil_data['parent_material_code'])]
                mil_data = pd.concat([mil_data, sub_mil_data], ignore_index=True, axis=0)
                st.warning(f"""RBF Data Disaggregation Successful.""", icon="✅")
            else:
                pass
        else:
            st.warning(f"""RBF data is not present for the current run month. \n 
                        Please update data on snowflake to disaggregated rbf data""", icon="⚠️")
            mil_data = mil_data.copy()
        return mil_data
        
    def add_past_sales_columns( self, df, key, cal_cols_list, train_till_date):
        """
        """
        new_cols_added = {}
        train_till_date = pd.to_datetime(train_till_date)
        df = df.groupby( [self.DATE_COL, key], as_index=False)[cal_cols_list].agg(sum)
        for col in  cal_cols_list:
            
            cols_to_add= [f"{col}_MV3", f"{col}_MV6", 
                        f"{col}_LM",
                        f"{col}_LLM", f"{col}_LLLM", f"{col}_LY", f"{col}_LLY", f"{col}_LLLY",
                        ]
            new_cols_added[col] = cols_to_add
            
            df.loc[:,self.DATE_COL] = pd.to_datetime(df[self.DATE_COL])
            mv3_dates = self.create_date_range( train_till_date, 2, 'M')
        
            mv3_values = df[df[self.DATE_COL].isin( mv3_dates)].groupby(key, as_index=False)[col].agg(np.mean)
            df = pd.merge( df, mv3_values.rename(columns={col:f"{col}_MV3"}), on=key, how='left')
    
            mv6_dates = self.create_date_range( train_till_date, 5, 'M')
            mv6_values = df[df[self.DATE_COL].isin( mv6_dates)].groupby(key, as_index=False)[col].agg(np.mean)
            df = pd.merge( df, mv6_values.rename(columns={col:f"{col}_MV6"}), on=key, how='left')

            lm_values = df[df[self.DATE_COL] == train_till_date].groupby(key, as_index=False)[col].agg(np.mean)
            df = pd.merge( df, lm_values.rename(columns={col:f"{col}_LM"}), on=key, how='left')
            
            llm_date = train_till_date - relativedelta( months=1) + MonthEnd(0)
            llm_values = df[df[self.DATE_COL] == llm_date].groupby(key, as_index=False)[col].agg(np.mean)
            df = pd.merge( df, llm_values.rename(columns={col:f"{col}_LLM"}), on=key, how='left')
            
            lllm_date = train_till_date - relativedelta( months=2) + MonthEnd(0)
            lllm_values = df[df[self.DATE_COL] == lllm_date].groupby(key, as_index=False)[col].agg(np.mean)

            df = pd.merge( df, lllm_values.rename(columns={col:f"{col}_LLLM"}), on=key, how='left')
            
            df = self.calculate_past_sales(df = df, key=key, col=col, rolling_size=0, col_name=f"{col}_LY",
                                         shift_size=12, if_sum=False, if_shift_only=True)

            df = self.calculate_past_sales(df = df, key=key, col=col, rolling_size=0, col_name=f"{col}_LLY", 
                                         shift_size=24, if_sum=False, if_shift_only=True)
            
            df = self.calculate_past_sales(df = df, key=key, col=col, rolling_size=0, col_name=f"{col}_LLLY",
                                        shift_size=36, if_sum=False, if_shift_only=True)
      
            df[[f"{col}_MV3",f"{col}_MV6",
                f"{col}_LM",f"{col}_LLM",
                f"{col}_LLLM",]] = df.groupby([key],as_index = False,group_keys = False)\
                                                                [[f"{col}_MV3",f"{col}_MV6",
                                                                f"{col}_LM",f"{col}_LLM",
                                                            f"{col}_LLLM"]].bfill().ffill()
        return df, new_cols_added


    def prepare_trend_data(self, trend_data, groupby_cols, scaling_input):
        """_summary_

        Args:
            trend_data (_type_): _description_
            groupby_cols (_type_): _description_
            scaling_input (_type_): _description_
        """
        train_data = trend_data[trend_data[self.DATE_COL]<=self.train_till_date]
        forecast_data = trend_data[trend_data[self.DATE_COL]>self.train_till_date]
        
        # final selection train_data data
        pred_cols = [col for col in trend_data.columns if 'pred_vol' in col]
        pivot_train_data = pd.melt(train_data, id_vars=[ self.DATE_COL, 'portfolio_name','key','qtr_ind_rate'], value_vars=pred_cols)
        pivot_train_data.columns = [self.DATE_COL ,  'portfolio_name' , 'key', 'qtr_ind_rate', 'model_type', 'pred'] 
        pivot_train_data['model_type'] = pivot_train_data['model_type'].apply(lambda x : x.split('_')[0])
        pivot_train_data = self.perform_final_model_selection(data=pivot_train_data, scaling_table=scaling_input, apply_scaling=False)
        pivot_train_data = pivot_train_data.drop(['portfolio_name', 'qtr_ind_rate'], axis=1)
        train_data = pd.merge(train_data, pivot_train_data, on=[ self.DATE_COL, 'key'], how='left')
        
        # perform scaling on forecast data
        pivot_forecast_data = pd.melt(forecast_data, id_vars=[ self.DATE_COL, 'portfolio_name','key','qtr_ind_rate'], value_vars=pred_cols)
        pivot_forecast_data.columns = [self.DATE_COL ,  'portfolio_name' , 'key', 'qtr_ind_rate', 'model_type', 'pred'] 
        pivot_forecast_data['model_type'] = pivot_forecast_data['model_type'].apply(lambda x : x.split('_')[0])
        pivot_forecast_data = self.perform_final_model_selection(data=pivot_forecast_data, scaling_table=scaling_input)
        pivot_forecast_data = pivot_forecast_data.drop(['portfolio_name', 'qtr_ind_rate', 'scaling'], axis=1)
        forecast_data = pd.merge(forecast_data, pivot_forecast_data, on=[ self.DATE_COL, 'key'], how='left')
        
        trend_data = pd.concat([train_data,forecast_data], axis=0, ignore_index=True)
        
        if len(groupby_cols)==1:
            chart_title = self.channel + " X " + groupby_cols[0]
        else:
            chart_title = self.channel + " X " + " X ".join(groupby_cols)
            
        if self.calculation_metric == 'Volume':
            cols_to_agg = [ self.target_column, self.target_column+'_treated' ]
            y_axis = 'Volume'
            for col in trend_data.columns:
                if (('pred' in col)or('train' in col)) and ('value' not in col): cols_to_agg.append(col)
                
        elif self.calculation_metric == 'Value':
            y_axis = 'Value (Cr)'
            cols_to_agg = [self.target_column+'_value', self.target_column+'_treated_value']
            for col in trend_data.columns:
                if (('value' in col)or('train' in col))and ('vol' not in col): cols_to_agg.append(col)

        chart_cols = [ col for col in cols_to_agg if ('lms' not in col)]
        grouped_data_monthly = trend_data.groupby( [self.DATE_COL], as_index=False)[chart_cols].agg(sum)
        self.plot_trend_chart( grouped_data_monthly, cols_to_agg, chart_title, y_axis)
    
    def scale_forecast_data( self, forecast_data, scaling_data, rbf_shared_data):
        """
        Perform Scaling on the Forecast data.
        Args:
            forecast_data (_type_): _description_
        """
        pivot_data = forecast_data.pivot(index=['key',self.DATE_COL], 
                                columns=['model_type'], 
                                values='pred').reset_index().drop(['Best_Model'], axis=1, errors='ignore')
        forecast_data = pd.merge(forecast_data, pivot_data, how='left', on=['key', self.DATE_COL])
        
        scaled_forecast_data = self.perform_final_model_selection( scaling_table=scaling_data, 
                                                                  data=forecast_data.copy())
        
        for col in ['rf','SARIMA', 'prophet', 'last_active_sale', 'p3m']:
            if col in forecast_data.columns:
                forecast_data.loc[:,col+'_vol'] = forecast_data[col]
                forecast_data.loc[:,col+'_value'] = (forecast_data[col]*forecast_data['qtr_ind_rate'])/10**7
                
        scaled_forecast_data = self.rbf_data_disaggregation(scaled_forecast_data.copy(), rbf_shared_data, 'final_pred_vol')
        return scaled_forecast_data
        
    def prepare_final_data(self, forecast_data, trend_data):
        """
        Prepare final data with all the columns needed.
        Args:
            forecast_data (_type_): _description_
            trend_data (_type_): _description_
        """
        data = self.add_past_sales_columns(trend_data, 'key', [self.target_column], train_till_date=self.train_till_date)[0]
        forecast_data = pd.merge( forecast_data, data, on=[self.DATE_COL, 'key'], how='left')
        final_columns = [col for col in forecast_data.columns if 'value' not in col]
        forecast_data = forecast_data[final_columns]
        self.display_df( df=forecast_data, cols=['key'], title='Final Forecast Data ')
        
        
    def perform_analysis(self,  trend_data, forecast_data, scaling_data, rbf_shared_data,  groupby_cols):
        """
        This function generate all the summary data and plot the streamlit charts.
        
        Args:
            trend_data: pandas dataframes
            - dataframe with all models forecast result for train and test period
            
            forecast_data: pandas dataframe
            - dataframe consist result for forecast period
            
            scaling_data: pandas dataframe
            - df containing mapping of portfolios for scaling
            
            rbf_shared_data: pandas dataframe
            - range forecasting pt est at national psku level
            
            groupby_cols: list
            - list of cols on which data aggregation is going to be performed
            
        """
        st.subheader(f"Scaling Factor Table...")
        scaling_input = st.data_editor( scaling_data, key='scaling_input')
        if st.button('Update Final Selection Data'):
            self.update_scaling_df( data=scaling_input.copy())
        # making groupby_cols a list if not
        if type( groupby_cols)!=list: groupby_cols = [ groupby_cols]

        # defining calculation metric
        if self.calculation_metric == 'Value':
            cal_col,target_column = "final_pred_value", self.target_column + '_value'
        else:
            cal_col, target_column = "final_pred_vol", self.target_column

        
        key_col = "_".join( groupby_cols)
        train_till_date = pd.to_datetime( self.train_till_date) 
        forecast_start_month = pd.to_datetime( self.run_month) + relativedelta(months=1) + MonthEnd(0)

        ###############
        self.prepare_trend_data( trend_data, groupby_cols, scaling_input=scaling_data)
        
        
            
        train_data = trend_data[ trend_data[self.DATE_COL]<= train_till_date]
        train_data = train_data.groupby( [self.DATE_COL]+groupby_cols, as_index=False)[target_column].agg(sum)
         
        cov_data = self.calculate_cov( train_data, key_col, target_column)
        output = Parallel(n_jobs = cpu_count()-2)(delayed( self.trend_overall_detector)
                                            ( Key, train_data, target_column, key_col,order=1
                                            )  
                                            for Key in tqdm(train_data[key_col].unique(), desc="Calculating Trend"))
        overall_trend_data = pd.DataFrame(output, columns=[ key_col, 'overall_trend'])

        additional_col_data, additional_cols = self.add_past_sales_columns( trend_data.copy(), key_col, [target_column], train_till_date)
        additional_col_data = additional_col_data[additional_col_data[self.DATE_COL] >= forecast_start_month]

        deviation_data, flag_cols = self.calculate_deviation_flags( additional_col_data.copy(), additional_cols)
        deviation_cols = [ self.DATE_COL, key_col, cal_col] + [ col for col in deviation_data.columns if 'deviation' in col]

        scaled_data = self.scale_forecast_data(forecast_data=forecast_data.copy(),
                                               scaling_data=scaling_data,
                                               rbf_shared_data=rbf_shared_data)

        agg_cols = []
        for col in scaled_data.columns:
            if ('val' in col)&(self.calculation_metric=='Value'):  agg_cols.append(col)
            elif ('vol' in col)&(self.calculation_metric!='Value'): agg_cols.append(col)
            
        grp_scaled_data = scaled_data.groupby(by=groupby_cols+[self.DATE_COL], as_index=False)[agg_cols].agg(sum).round(4)
        
        grp_scaled_data = pd.merge( grp_scaled_data, cov_data, on=key_col, how='left')
        grp_scaled_data = pd.merge( grp_scaled_data, overall_trend_data, on=key_col, how='left')

        self.display_df(grp_scaled_data, cols=groupby_cols, title='Final Forecast Summary')
        self.display_df(deviation_data, cols=groupby_cols, title='Deviation Data')
        self.display_df(deviation_data[ [self.DATE_COL, key_col, target_column] + flag_cols], cols=groupby_cols, title='Deviation Data')
        
        final_grp_scaled_data = scaled_data.groupby(by=[self.DATE_COL], as_index=False)[agg_cols].agg(sum).round(4)
        self.display_df(final_grp_scaled_data , cols=groupby_cols, title='Overall Forecast')
        
        self.prepare_final_data(scaled_data, trend_data)

    def get_mil_run_dates(self):
        """
        Select dates for available data.
        """
        query = f"""select distinct(train_till_date) from TRN_MIL_DF_TRAIN_FORECAST"""
        dates = self.fetch_data_from_snowflake(query=query)
        dates = dates.sort_values(by='train_till_date', ascending=False)['train_till_date'].tolist()
        return dates
    
    def update_scaling_df(self, data):
        """
        Save the updates in the scaling the data
        
        Args:
            data: pandas dataframe
            - updated scaling data to be saved locally
        """
        data.loc[:,'channel'] = self.channel
        scaling_data = pd.read_csv(f"./data/processed/mil_scaling_factor.csv")#_{self.train_till_date} 
        scaling_data = scaling_data[~(scaling_data['channel']==self.channel)]
        scaling_data = pd.concat([scaling_data,data], ignore_index=True, axis=0)
        scaling_data.to_csv(f"./data/processed/mil_scaling_factor.csv", index=False)
        st.warning(f"""Data Updated Successfully""", icon="✅")
        st.rerun()
        
    # def read_scaling_df(self):
    #     """
    #         Read the scaling data for the run.
    #     """
        
    #     file_name = f'scaling_master_{self.train_till_date}.csv'
        
    #     if file_name in os.listdir('./data/processed/'):
    #         scaling_master  = pd.read_csv(os.path.join('./data/processed/', file_name))
    #     else:
    #         scaling_master = pd.read_csv('scaling_master.csv')
    #         forecast_month_df = 

    def run_streamlit_dashboard(self):
        """
        This function start the streamlit dashboard and take the initial inputs from 
        the user to show the final dashboard. 
        """

        available_dates = self.get_mil_run_dates()
        self.train_till_date = st.sidebar.selectbox("Select Forecast Month: ", available_dates, key="selected_month")
        self.train_till_date = str(pd.to_datetime( self.train_till_date).date())
        self.run_month = str(( pd.to_datetime( self.train_till_date) - relativedelta(months=1) + MonthEnd(0)).date())
        
        self.channel = st.sidebar.selectbox("Select Channel: ", ['ECOM' ,'GT', 'MT'],key="key_channel")
        self.calculation_metric = st.sidebar.selectbox("Select Target Column: ", [  'Value', 'Volume'],key="target_col")
        self.threshold_value = st.sidebar.number_input("Deviation Threshold: ",  value =15, key="threshold_val")
        self.no_of_rows = st.sidebar.number_input("Enter Display number of rows: ",  value = 50, key="num_of_df_rows")
        
        scaling_data = pd.read_csv("./data/processed/mil_scaling_factor.csv")
        scaling_data = scaling_data[scaling_data['channel']==self.channel].drop('channel',axis=1)

        if self.channel:
            trend_data, forecast_data, rbf_shared_data = read_rbf_data( self.channel, self.train_till_date, self.gran_cols, self.DATE_COL)

            pred_months = st.sidebar.multiselect("Select Forecast Months:", forecast_data['predicting_month'].unique().tolist(),key="pred_months")
            if len(pred_months)>0:
                forecast_data = forecast_data[forecast_data['predicting_month'].isin(pred_months)]
            self.forecast_months = forecast_data[self.DATE_COL].unique()
            filter_columns_to_show = [ 'portfolio_name', 'brand_code', 'asm_area_code', 'depot_code',
                                    'parent_material_code', 'key', 'npd_flag', 'seasonal_month_flag', 'free']
            filter_columns = st.sidebar.multiselect("Select Filter Columns:",filter_columns_to_show,key="key_filter_cols")

            if len(filter_columns)>0:
                for filter in filter_columns:
                    option = st.sidebar.multiselect(f"Select filter for {filter}:", forecast_data[filter].unique().tolist(),
                                key=f"key_{filter}")
                    if len(option)>0:
                        print(option)
                        forecast_data = forecast_data[forecast_data[filter].isin(option)]
                        trend_data = trend_data[trend_data[filter].isin(option)]      

            hierarchy_cols_to_filter = ['portfolio_name', 'brand_code', 'parent_material_code', 'key']
            hierarchy_columns = st.sidebar.selectbox("Hierarchy for Data Check:", hierarchy_cols_to_filter,key="key_hierarchy")
            self.perform_analysis( trend_data.copy(), forecast_data.copy(),scaling_data.copy(),  rbf_shared_data.copy(), hierarchy_columns)
        
        
