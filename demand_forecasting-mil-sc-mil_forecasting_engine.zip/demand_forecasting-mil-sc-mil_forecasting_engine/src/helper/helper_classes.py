"""
Author: Aishwarya Verma
Version: 0.0.1
Description: This file contains all helper class that are being used at multiple places 
            for the pipeline
"""

from .forecast_engine_packages import pd, os, literal_eval, relativedelta, MonthEnd, itertools, tqdm
from .helper_functions import run_parallel_functions, calculate_root_mean_sqaured_error, calculate_mape, calculate_r2,\
    calculate_bias, calculate_wape, concatenate_pandas_dataframe, get_add_month, get_add_days
from ..data import FetchSnowflakeData

class GetGeneralPipelineInput(object):
    """
    This class contains all the global variables and functions defined for the forecast engine
    pipeline
    """
    def __init__(self, input_dict):
        """
        """
        self.DATE_COL = input_dict['input_template_data_processed']["DATE_COL"]
        self.target_column = input_dict['input_template_data_processed']["target_column"]
        self.input_outlier_Values = input_dict['input_template_data_processed']["Input_outlier_Values"]
        self.di_fs_input = input_dict['input_template_data_processed']["input_fs_values"]
        self.di_model_input = input_dict['input_template_data_processed']["di_model_input"]
        self.di_cts_inputs = input_dict['input_template_data_processed']["di_cts_inputs"]
        self.Input_Transformation = input_dict['input_template_data_processed']["Input_Transformation"]
        self.Input_trend_seas = input_dict['input_template_data_processed']["Input_trend_seas"]
        self.Input_model_vars = input_dict['input_template_data_processed']['Input_model_vars']
        self.location_to_save = input_dict['location_to_save']
        self.hierarchy_features=input_dict['gran_cols']+input_dict['master_data_cols']
        self.cols_to_pred = input_dict["input_template_data_processed"]["cols_to_pred"]
        self.trend_col = "Current_Value"
        self.actual_forecast_period = input_dict['cutoffs']['actual_forecast_period']
        self.cutoffs_periods = input_dict['cutoffs']["cutoffs_periods"]
        self.cv_periods = input_dict['cutoffs']["cv_periods"]
        self.prophet_horizon = input_dict['cutoffs']["prophet_horizon"]
        self.to_drop = [self.DATE_COL,self.target_column,'key']
        self.index_rate = input_dict['index_rate_data']
        self.no_of_keys_to_process = input_dict['no_of_keys_to_process']
        self.fetch_holiday_data = FetchSnowflakeData().fetch_mil_table_from_db(table_name='MST_MIL_FESTIVAL_DATA')

    def calculate_forecasting_metrics(self, train, train_pred, valid, valid_pred, original_df, vb_value=False):
        """ 
        This function will calculate training as well as testing metrice required on volume as well as on 
        bpm.

        Arguments:

            train: pandas dataframe 
            - contains the training data

            train_pred: list 
            - contains the training data predictions

            valid: pandas dataframe 
            - contains the testing data

            valid_pred: list 
            - contains the testing data predictions
            
            original_df: pandas dataframe 
            - contains the sales data along with all the features & master data.
            index_rate: pandas dataframe

            vb_value: bool
            - bool value representing whether we required the biases for validation.
        Return: 
            metrics: dict
            - contains all the training, testing accuracies, error, biases

        """
        metrics = {}
        train.loc[:,'pred'] = train_pred 
        valid.loc[:,'pred'] = valid_pred 
        train_rmse_volume = calculate_wape(y_true=train[self.target_column], y_pred=train['pred'])*100
        train_r2_volume = calculate_r2(y_true=train[self.target_column], y_pred=train['pred'])
        train_metrics = {  
                            'vol':
                                {
                                    "rmse":train_rmse_volume,
                                    "r2":train_r2_volume
                                }
                        }
    
        if self.di_model_input['buffer_horizon']==0:
            pass
        else:
            if self.di_model_input['frequency_forecast']=='Monthly':
                to_exclude = get_add_month(x = valid[self.DATE_COL].min(), months=self.di_model_input['buffer_horizon'])
            if self.di_model_input['frequency_forecast']=='Daily':
                to_exclude = get_add_days(x = valid[self.DATE_COL].min(), days=self.di_model_input['buffer_horizon'])
            valid = valid[valid[self.DATE_COL]>=to_exclude]

        valid_rmse_volume = calculate_root_mean_sqaured_error(y_true = valid[self.target_column], y_pred= valid['pred'])
        wape_volume = calculate_wape(y_true=valid[self.target_column], y_pred=valid['pred'])*100
        valid_metric_volume = { 
                                "rmse":valid_rmse_volume ,
                                "wape":wape_volume
                            }
        
        if vb_value==True:
            vb = valid[[self.DATE_COL,self.target_column,'pred']].copy()
            vb = calculate_bias(data=vb, target_column=self.target_column, pred_column='pred')
            valid_metric_volume["validation_bias"] = vb.copy()

        if vb_value==False:
            valid.loc[:,"MAPE"] = calculate_mape(y_true=valid[self.target_column], y_pred=valid["pred"])
            valid = calculate_bias(data=valid, target_column=self.target_column, pred_column='pred')
            valid.loc[:,"Accuracy"] = 100-valid["MAPE"]
            valid_metric_volume["MAPE"] = valid
            
        valid_metrics = {
                            'vol':valid_metric_volume,
                        }
    
        if self.index_rate.empty==False:
            train = self.get_bpm(df_to_update=train, 
                            original_df=original_df)

            train_rmse_value = calculate_wape(y_true=train[f"{self.target_column}_value"], y_pred=train['pred_value'])*100
            train_r2_value = calculate_r2(y_true=train[f"{self.target_column}_value"], y_pred=train['pred_value'])
            train_metrics['val'] = {
                                        "rmse":train_rmse_value,
                                        "r2":train_r2_value
                                    }

            valid = self.get_bpm(df_to_update=valid, 
                            original_df=original_df)
            valid_rmse_value = calculate_root_mean_sqaured_error(y_true=valid[f"{self.target_column}_value"], y_pred=valid['pred_value'])
            wape_value =calculate_wape(y_true=valid[f"{self.target_column}_value"], y_pred=valid['pred_value'])*100
            valid_metric_value = {
                                    "rmse":valid_rmse_value,
                                    "wape":wape_value
                                }
            if vb_value==True:
                vb = valid[[self.DATE_COL,f"{self.target_column}_value",'pred_value']].copy()
                vb = calculate_bias(data=vb, target_column=f"{self.target_column}_value", pred_column='pred_value')
                valid_metric_value["validation_bias"] = vb
            
            if vb_value==False:
                valid.loc[:,"MAPE"] =  calculate_mape(y_true=valid[f"{self.target_column}_value"], y_pred=valid["pred_value"])
                valid.loc[:,'Test_bias'] = calculate_bias(data=valid, target_column=f"{self.target_column}_value", pred_column='pred_value')
                valid.loc[:,"Accuracy"] = 100-valid["MAPE"]
                valid_metric_value["MAPE"] = valid
            
            valid_metrics['val'] = valid_metric_value

        metrics["train"] = train_metrics
        metrics["valid"] = valid_metrics    
        return metrics

    def get_bpm(self, df_to_update, original_df=None, target_column=None):
        """
        This function will give the corresponding value for the volume by mapping the index rate

        Arguments:

            df_to_update: pandas dataframe
            - dataframe to get the turnover or values

            original_df: pandas dataframe
            - contains the modelling data along with all the hierarchy

        Return:

            df_to_update: pandas dataframe
            - updated dataframe with value and turnover column


        """
        if target_column==None:
            target_column = self.target_column

        idx_key_cols = self.di_model_input['idx_key_cols']
        
        if set(idx_key_cols).issubset(df_to_update.columns)==True:
            pass
        else:
            to_merge_on = ['key']
            if self.DATE_COL in idx_key_cols:
                to_merge_on.append(self.DATE_COL)
               
            df_to_update = pd.merge(df_to_update, 
                                    original_df[['key']+idx_key_cols].drop_duplicates(keep="first"),
                                    how="left", 
                                    left_on = to_merge_on,
                                    right_on = to_merge_on)
            
        idx_cols = self.index_rate.columns.tolist()
        bpm_col = list(set(idx_cols) - set(idx_key_cols))[0] 
        

        if 'qtr_ind_rate' not in df_to_update.columns:
            df_to_update = pd.merge(df_to_update, 
                                    self.index_rate[idx_key_cols+[bpm_col]],
                                    how="left", 
                                    left_on = idx_key_cols,
                                    right_on = idx_key_cols)
        
        if target_column not in df_to_update.columns:
            df_to_update  = pd.merge(df_to_update,
                                     original_df[['key',self.DATE_COL, target_column]],
                                    how="left",
                                    on=['key',self.DATE_COL])
        
        if "pred" in df_to_update.columns:
            df_to_update.loc[:,"pred_value"] = df_to_update['pred']*df_to_update[bpm_col]

        if target_column in df_to_update.columns:
            df_to_update.loc[:,f"{target_column}_value"] = df_to_update[target_column]*df_to_update[bpm_col]

        return df_to_update
    
    def cross_validation_date_check(self, data_key):
        """
        This function is used to get cross validation period for a 
        specific combination.

        Arguments:

            data_key: pandas dataframe
            - dataframe containing the data for a specific key
        
        Return:

            cutoffs_periods_subset: list of datetime 
            - contains the cutoffs for the key

            cv_periods_subset: list of datetime 
            - contains the validation periods for the key
        """
        check = []
        for idx in range(len(self.cv_periods)):
            if max(self.cv_periods[idx]) in data_key[self.DATE_COL].unique():
                check.append(idx)

        cutoffs_periods_subset = [self.cutoffs_periods[i] for i in check]
        cv_periods_subset = [self.cv_periods[i] for i in check]

        return cutoffs_periods_subset, cv_periods_subset


    def treat_covid_months(self, df, Key):
        """
        This function replaces the covid month target column values by the 
        average of past 3 months for a specific key

        Arguments:

            df: pandas dataframe
            - dataframe containing the sales data

            Key: string
            - defined the combination to filter
        """
        data_key = df[df['key']==Key]
        covid_months = self.input_dict['covid_months']
        for month_date in covid_months:
            data_key.loc[data_key[self.DATE_COL] == str(month_date.date()), self.target_column] = \
                data_key[ pd.to_datetime(data_key[self.DATE_COL]) < month_date].iloc[-3:][self.target_column].mean()
        data_key = data_key.dropna(subset = self.target_column)
        return [data_key]
    
    def get_metric_values(self, metric, idx, if_vol):
        """

        """
        if if_vol==True:
            col = "vol"
            target_col = self.target_column
            pred_col = "pred"
        else:
            col = "val"
            target_col = f"{self.target_column}_value"
            pred_col = "pred_value"
        train_rmse = metric["train"][col]["rmse"]
        train_r2 = metric["train"][col]["r2"]
        #valid metrics
        valid_rmse = metric["valid"][col]["rmse"]
        valid_wape = metric["valid"][col]["wape"]
        
        cv_validation_bias_data = metric["valid"][col]["validation_bias"]
        cv_validation_bias_data = cv_validation_bias_data.rename(columns={self.DATE_COL:f"Validation_Date_{idx+1}_{col}",
                                            'bias':f"Validation_Bias_{idx+1}_{col}",
                                            pred_col:f"Validation_Bias_{idx+1}_pred_{col}",
                                            target_col:f"Validation_Bias_{idx+1}_actual_{col}"}).reset_index(drop=True)
        return train_rmse, train_r2, valid_rmse, valid_wape, cv_validation_bias_data


class GetMlPipelineInput(GetGeneralPipelineInput):
    """
    This class contains all the global variables defined only for 
    ml pipeline
    """

    def __init__(self, df, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)
            
        if os.path.exists(f"{self.location_to_save}/advanced_feature_selection_final_data.csv"):

            self.features_to_take = pd.read_csv(f"{self.location_to_save}/advanced_feature_selection_final_data.csv")
            self.features_to_take['key'] =  self.features_to_take['key'].astype(str)
            self.features_to_take.loc[:,'k_best_features_name'] =  self.features_to_take.loc[:,'k_best_features_name'].\
                                                                    apply(lambda x: list(literal_eval(x)))
        else:
            self.features_to_take = pd.DataFrame()

        self.original_df = df
        self.suffix_dict = {
                        "LinearRegression":"lr",
                        "Lasso":"lasso",
                        "Ridge":"ridge",
                        "ElasticNet":"elasticnet",
                        "BayesianRidge":"bayesian_ridge",
                        "XGBoost":"xgb",
                        "RandomForest":"rf",
                        "LightGBM":"lgbm",
                        "BayesianLinearRegression":"bayesian_lr",
                        "MLP_2layer":"mlp_2layer"
                    }

        
class GetProphetPipelineInput(GetGeneralPipelineInput):
    """
    This class contains all the global variables and functions defined only for 
    prophet pipeline 
    """

    def __init__(self, df, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)
        self.additional_regressors = self.di_model_input['prophet_additional_regressors']
        self.df_prophet_model = df[['key',self.DATE_COL, self.target_column]+self.additional_regressors]
        self.df_prophet_model[self.DATE_COL] = pd.to_datetime(self.df_prophet_model[self.DATE_COL])
        self.df_prophet_model =  self.df_prophet_model.rename(columns={self.DATE_COL:'ds',
                                                                    self.target_column:'y'})

        self.original_df = df

        self.prophet_DATE_COL = 'ds'
        self.prophet_target_column = 'y'
        self.prophet_pred_column = 'yhat'
        self.input_dict = input_dict

        # param_df contains all the differnt combination of parameter combination in
        #order to find the best prophet model among them.
        param_grid = {
                'changepoint_prior_scale': [0.001, 0.01, 0.1, 0.5],
                'changepoint_range': [0.8],
                'seasonality_prior_scale': [0.01,0.1,1,10.0]
              }
        param_iter = itertools.product(*param_grid.values())
        params = []
        for param in param_iter:
            params.append(param) 
        self.params_df = pd.DataFrame(params, columns = list(param_grid.keys()))

    
    def import_column_festival_data(self):
            """
            This function will take the festival data and convert into the format
            the required by prophet model to pass it in holidays df.

            Arguments:

                None

            Return:

                festival_df: pandas dataframe
                - festival data in the format required by prophet

            """
            # festival_data = self.input_dict['festival_data']
            # festival_col = self.di_model_input["festival_col"]

            # festival_data[festival_col] = festival_data[festival_col].str.replace(" ","_")
            # festival_data[festival_col] = festival_data[festival_col].str.replace("'","")
            # festival_data[festival_col] = festival_data[festival_col].str.replace("-","_")
            # festival_data[self.DATE_COL] = pd.to_datetime(festival_data[self.DATE_COL])
            
            # festival_data = festival_data.groupby([festival_col],as_index=False).agg({self.DATE_COL:"unique"})
            # dfs_to_create = []
            # for row in festival_data.iterrows():
            #     festival_name = row[1][festival_col]
            #     dates = row[1][self.DATE_COL]
            #     festival_dict = {
            #         "festival":festival_name,
            #         self.DATE_COL:dates
            #         }
            #     dfs_to_create.append( festival_dict)
            dfs = []
            festival_df = self.fetch_holiday_data
            festival_df.columns = [col.lower() for col in festival_df.columns]
            for fest in festival_df['festival'].unique():
                fest_df = festival_df[ festival_df['festival']== fest]
                dfs.append(pd.DataFrame({
                    'holiday': fest,
                    'ds': pd.to_datetime(fest_df[self.DATE_COL].tolist()),
                    'lower_window': 0,
                    'upper_window': 0,
                    'prior_scale' :1
                }))
            festival_df = concatenate_pandas_dataframe(data_list=dfs)
            return festival_df

    def import_flag_festival_data(self, data_key):
        """
        """
        festival_col = self.di_model_input["festival_col"]
        final_festival_data = []

        if "," in festival_col:
            festival_cols = festival_col.split(",")
        else:
            festival_cols = [festival_col]
        
        for festival_col in festival_cols:
            if festival_col in data_key.columns:
                festival_data =data_key[data_key[festival_col]==1]
                if festival_data.shape[0]>0: 
                    events = pd.DataFrame({
                            'holiday': festival_col,
                            'ds': pd.to_datetime(festival_data[self.DATE_COL].tolist()),
                            'lower_window': 0,
                            'upper_window': 0,
                            'prior_scale' :1
                            })
                    final_festival_data.append(events)
            else:
                pass
        final_festival_data = concatenate_pandas_dataframe(data_list=final_festival_data)
        return final_festival_data

    def import_covid_prophet_data(self, data_key):
        """
        This function gives the covid data & post covid data for prophet model
        to append to holidays data

        Arguments:

            data_key: pandas dataframe
            - contains the full data(sales+dd) for a key
        
        Return:

            covid_data: pandas dataframe
            - contains the covid & post covid data in the required format
        """
        if "covid_flag" in data_key.columns:
            covid_flag = data_key[data_key["covid_flag"]==1]
        else:
            covid_flag = pd.DataFrame()
        
        if "post_covid_flag" in data_key.columns:
            post_covid_flag =data_key[data_key["post_covid_flag"]==1]
        else:
            post_covid_flag = pd.DataFrame()

        
        data  = []
        if covid_flag.shape[0]>0:
            Covid = pd.DataFrame({
                    'holiday': 'Covid',
                    'ds': pd.to_datetime(covid_flag[self.DATE_COL].tolist()),
                    'lower_window': 0,
                    'upper_window': 0,
                    'prior_scale' :1
                    })
            
            data.append(Covid)
        if post_covid_flag.shape[0]>0:
            Post_Covid = pd.DataFrame({
                    'holiday': 'Post_Covid',
                    'ds': pd.to_datetime(post_covid_flag[self.DATE_COL].tolist()),
                    'lower_window': 0,
                    'upper_window': 0,
                    'prior_scale' :1
                    })
            
            data.append(Post_Covid)
        covid_data = concatenate_pandas_dataframe(data_list=data)
        return covid_data

    def create_holidays_df(self, Key):
        """
        This function will create holiday data for prophet pipeline 
        at Key level.

        Arguments:

            Key: string
            - defines the key for which the ata has to be filter

        
        Return:

            holidays_df: pandas dataframe
            - contains the holiday data for prophet model

        """
        _type = self.di_model_input["holiday_data_type"]
        data_key = self.original_df[self.original_df['key']==Key]

        covid_data = self.import_covid_prophet_data(data_key=data_key)

        if _type=="flag":
            festival_data = self.import_flag_festival_data(data_key = data_key)

        elif _type=="columns":
            festival_data = self.import_column_festival_data()
        else:
            festival_data = self.import_column_festival_data()
        
        holidays_df = concatenate_pandas_dataframe(data_list = [covid_data, festival_data])
    
        return holidays_df


class GetCtsPipelineInput(GetGeneralPipelineInput):
    """
    This class contains all the global variables and functions defined only for 
    classical time series pipeline 
    """

    def __init__(self, df, input_dict):
        """
        """
        super().__init__(input_dict=input_dict)
        self.original_df = df
        self.input_dict = input_dict
