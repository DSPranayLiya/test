"""
Author: Aishwarya Verma
Version: 0.0.2
Description: This file contains the helper functions for he pipeline to use.
"""

from .forecast_engine_packages import os, np, pd, MonthEnd, Parallel, cpu_count, delayed, tqdm, \
    variance_inflation_factor, PCA, relativedelta, r2_score, mean_squared_error, pickle, sm, csv, wraps,time


def read_files(input_file_path):
    """
    This function will read file(csv/xlsx) if given the correct file path

    Arguments:

        input_file_path: str
        - contains the path of the file to be read

    Return:
        file_data: pandas dataframe
        - contains the data of the file read

    """
    #reading the files
    if input_file_path.endswith(".csv"):
        file_data = pd.read_csv(input_file_path)
    
    if input_file_path.endswith(".xlsx"):
        file_data = pd.read_excel(input_file_path)

    return file_data

def read_pickle_file( input_file_path):
    """
    This function will read file pickle objects if given the correct file path

    Arguments:

        input_file_path: str
        - contains the path of the file to be read

    Return:

        obj: Any
        - pickle file object

    """
    with open( input_file_path, 'rb') as file:
        obj = pickle.load( file)
    return  obj

def convert_date_to_month_end(x):
        """
        This function return the end of month date

        Argument:
            x: pandas datetime
        
        Return:
            end of month date
        """
        return x+MonthEnd(0)

def get_diff_month(x, months=1):
    """
    """
    return x-relativedelta(months=months)+MonthEnd(0)

def get_diff_days(x, days=1):
    """
    """
    return x-relativedelta(days=days)

def get_add_month(x, months=1):
    """
    """
    return x+relativedelta(months=months)+MonthEnd(0)

def get_add_days(x, days=1):
    """
    """
    return x+relativedelta(days=days)

def create_date_range(start_date, end_date, freq):
    """
    """
    date_list = pd.date_range(start=start_date, end=end_date, freq=freq)
    date_list = [date.date() for date in date_list]
    return date_list

def concatenate_pandas_dataframe(data_list, axis=0, ignore_index=True):
    """
    """
    if len(data_list)>0:
        final_data = pd.DataFrame()
        for df in data_list:
            final_data = pd.concat([final_data, df], axis=axis, ignore_index=ignore_index)
        final_data = final_data.reset_index(drop=True)
    else:
        final_data = pd.DataFrame()
    return final_data

def create_dir(location, message):
        """
        This function will create directory at the location specified
        in the parameter
        
        Arguments:

            location: str
            - contains the path where the folder needs to get created

            message:
            - contains the purpose of the folder 
        """
        if os.path.exists(location):
            print(f'{message} folder already exist..!!')
        else:
            os.makedirs(location)
            print(f'{message} folder Created..!!')
            
def run_parallel_functions(func, df, argument_dict, desc, iter_col, is_iter_idx=False, is_df_arg=True, backend=None):
    """
    This function will run the passed function in parallel fashion instead of running it
    serially

    Arguments:

        func: function
        - Name of the function to run in parallel

        df: pandas dataframe
        - dataframe to iterate over

        argument_dict: dictionary
        - contains the arguments to be passed in the running function

        desc: string
        - description to show while running the parallel function

        iter_col: string
        - defines the column name over which the dataframe has to be 
        iterated

        is_iter_idx: bool
        - 

        is_df_arg: bool
        - defines whether the df passed is to be passed as argument or not
    """
    if backend == None:
        backend ='loky'
    if is_df_arg==True:
        argument_dict["df"] = df
    
    if is_iter_idx==False:
        output = Parallel(n_jobs = cpu_count()-2, backend=backend)(delayed(func)
                                        (**argument_dict, Key=Key)  
                                        for Key in tqdm(df[iter_col].unique(), desc=desc))
        # output = [func
        #                                 (**argument_dict, Key=Key)  
        #                                 for Key in tqdm(df[iter_col].unique(), desc=desc)]

    print("***********************************************************************************************")
    print()
    print()
    return output


def calculate_r2(y_true, y_pred):
    """
    This function will calculate r2.

    Arguments:

        y_true: numpy array/ pandas dataframe/ list
        - contains the actual value

        y_pred:  numpy array/ pandas dataframe/ list
        - contains the predicted value
    
    Return:
        float: required r2 no.
    """
    return r2_score(y_true, y_pred)


def calculate_root_mean_sqaured_error(y_true, y_pred):
    """
    This function will calculate mean squared error.

    Arguments:

        y_true: numpy array/ pandas dataframe/ list
        - contains the actual value

        y_pred:  numpy array/ pandas dataframe/ list
        - contains the predicted value
    
    Return:
        float: required rmse no.
    """
    return mean_squared_error(y_true, y_pred, squared = False)

def calculate_bias(data, target_column, pred_column):
    """
    This function will calculate rmse.

    Arguments:

        data: numpy array/ pandas dataframe/ list
        - contains the actual value

        target_column: string
        - contains the name of target column

        pred_column:  string
        - contains the name of predicted column
    
    Return:
        float: required rmse no.
    """
    data.loc[:,'bias'] = ((data[pred_column] - data[target_column])/data[target_column])*100
    return data


def calculate_mape(y_true, y_pred):
    """
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100


def calculate_wape(y_true, y_pred):
    """
    This function will calculate wape.

    Arguments:

        y_true: numpy array/ pandas dataframe/ list
        - contains the actual value

        y_pred:  numpy array/ pandas dataframe/ list
        - contains the predicted value
    
    Return:
        float: required wape no.
    """
    return (abs(y_true-y_pred).sum()/y_true.sum())

def calculate_vif(train, to_drop, suffix):
        """
        """

        VIF             = pd.DataFrame()
        VIF['feature']  = train.drop(to_drop,axis=1).columns.tolist()
        VIF['VIF']      = [variance_inflation_factor(train.drop(to_drop,axis=1).values, i) for i in range(train.drop(to_drop,axis=1).shape[1])]
        VIF['Model_Type'] = suffix
        return VIF


def calculate_pca(train, test, to_drop, model, target_column, suffix):
    """
    """
    pca = PCA(n_components=0.99)
    pca.fit_transform(train.drop(to_drop,axis=1))
    _PCA = pd.DataFrame(pca.components_,columns=train.drop(to_drop,axis=1).columns)
    _PCA["variance_explained"] = pca.explained_variance_ratio_
    _PCA['Model_Type'] = suffix

    n_pcs= pca.components_.shape[0]
    most_important = [np.abs(pca.components_[i]).argmax() for i in range(n_pcs)]
    initial_feature_names = train.drop(to_drop,axis=1).columns
    # get the names
    most_important_names = [initial_feature_names[most_important[i]] for i in range(n_pcs)]
    # using LIST COMPREHENSION HERE AGAIN
    dic = {'PC{}'.format(i+1): most_important_names[i] for i in range(n_pcs)}
    # build the dataframe
    PCA_mst_imp_feat = pd.DataFrame(sorted(dic.items()))
    PCA_mst_imp_feat['Model_Type'] = suffix

    if suffix=="extra":
        targe_col = train[target_column]
        train_scaled = pca.fit_transform(train.drop(to_drop,axis=1))
        test_scaled = pca.transform(test.drop(to_drop,axis=1))
        model.fit(train_scaled,targe_col)
        train_pred  = model.predict(train_scaled)
        pred = model.predict(test_scaled)
        
    else:
        model.fit(train.drop(to_drop,axis=1), train[target_column])
        train_pred  = model.predict(train.drop(to_drop,axis=1))
        pred = model.predict(test.drop(to_drop,axis = 1))
    
    return _PCA, PCA_mst_imp_feat, train_pred, pred


def perform_left_join( df1, df2, join_on, filter_cols=None):
    """
     Perform left join with two columns

    Args:
        df1 ( pandas dataframe): main dataframe in which df2 to be joined
        df2 ( pandas dataframe): dataframe2 to merge with df1
        join_on ( list): list consist the column names dataframes to be joined
        filter_cols (list): the selected columns in df2 to merged with df1
    Returns:
        merged_df ( pandas dataframe): merged dataframe
    """
    if type( join_on)!= list:
        join_on = [ join_on]

    if (type( filter_cols)!= list)&(filter_cols!=None):
        filter_cols = [ filter_cols]

    if filter_cols:
        df2 = df2[ join_on + filter_cols].drop_duplicates(subset=join_on)
    for col in join_on:
        df2.loc[ :, col] = df2[col].astype(df1[col].dtype)
    
    merged_df = pd.merge( df1, df2, on = join_on, how='left')
    return merged_df


# Function to calculate VIF
def calculate_vif(data):
    vif_df = pd.DataFrame(columns = ['Var', 'Vif'])
    x_var_names = data.columns
    for i in range(0, x_var_names.shape[0]):
        y = data[x_var_names[i]]
        x = data[x_var_names.drop([x_var_names[i]])]
        r_squared = sm.OLS(y,x).fit().rsquared
        vif = round(1/(1-r_squared),2)
        vif_df.loc[i] = [x_var_names[i], vif]
    return vif_df.sort_values(by = 'Vif', axis = 0, ascending=False, inplace=False)


def convert_date_to_pd_date(x):
        """
        This function return the end of month date

        Argument:
            x: pandas datetime
        
        Return:
            end of month date
        """
        return pd.to_datetime(x)


def record_model_runtime( function_name = None, Key= None, location_to_save= "./outputs"):
        """
            Save the model run time.

            Input:
                function_name: str
                - name of the function

                Key: str | int
                - key value for which function is running by default it is None

                location_to_save: str
                - string to save the file location if not provided file will be 
                  saved into outputs folder.
        """
        def decorator( func):
            """ 
                Decorator function to calculate the runtime time of the 
                input function and return the output.
            """
            @wraps(func)  # Preserve the original function's metadata
            def calculate_and_save_runtime( *args, **kwargs):
                """ 
                    Implement the record model runtime and saves the model run
                    time in minutes and in csv file.
                """
                fn_name = function_name
                start_time = time()
                func_output = func( *args, **kwargs)
                end_time = time()
                total_runtime = round((( end_time - start_time)/60),4)
                location_to_save = args[0].location_to_save
                output_file = os.path.join( location_to_save, 'model_runtime.csv')
                

                with open( output_file, 'a', newline='') as csvfile:
                    fieldnames = ['Function Name', 'Key', 'Runtime (mins)']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    # If the file is empty, write the header
                    if csvfile.tell() == 0:
                        writer.writeheader()

                    if fn_name == None:
                        fn_name = func.__name__
                        
                    if 'suffix' in kwargs.keys():
                        fn_name = kwargs['suffix'] + '_' + fn_name
                        
                    writer.writerow({'Function Name': fn_name, 'Key': kwargs['Key'],'Runtime (mins)': total_runtime})
                return func_output
                
            return calculate_and_save_runtime

        return decorator