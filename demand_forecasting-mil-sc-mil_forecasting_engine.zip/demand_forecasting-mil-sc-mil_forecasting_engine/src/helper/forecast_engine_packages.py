"""
Author: Aishwarya Verma
Version: 0.0.1
Description: This file contains all packages requires to run the whole pipeline
"""
import statistics
import os,sys
import itertools
from os import cpu_count
from time import time
from tqdm import tqdm
import traceback
import calendar
from datetime import datetime
from IPython.display import display
import logging
import pickle
import traceback
import math
import shutil
import csv
from colorama import Fore
from functools import wraps

formatter = logging.Formatter('%(asctime)s | %(name)s | %(funcName)s | %(levelname)s | %(message)s')
def setup_logger(name, log_file, level = logging.DEBUG):
    handler = logging.FileHandler(log_file)        
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    return logger

import warnings
warnings.simplefilter(action='ignore')

import pandas as pd
#from pandas.errors import SettingWithCopyWarning
#warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)
pd.set_option('expand_frame_repr', False)
pd.options.display.max_columns = 500
pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.float_format', lambda x: '%.3f' % x)

import numpy as np
from pandas.api.types import is_string_dtype\
,is_numeric_dtype,is_categorical_dtype

from sklearn.metrics import mean_absolute_error,mean_absolute_percentage_error, r2_score\
,mean_squared_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder,StandardScaler
from category_encoders import BinaryEncoder
from xgboost import XGBRegressor
import lightgbm as lgb
from lightgbm import LGBMRegressor
from sklearn.linear_model import LinearRegression, Lasso, Ridge, ElasticNet, BayesianRidge


from hyperopt import fmin, tpe, hp, STATUS_OK, Trials
from hyperopt.pyll.base import scope
from joblib import Parallel, delayed


from prophet import Prophet
from prophet.diagnostics import cross_validation


import warnings
warnings.filterwarnings('ignore')

from dateutil.relativedelta import relativedelta
from functools import partial
from collections import ChainMap


import statsmodels.api as sm
from pmdarima import auto_arima
from sklearn import metrics
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import kpss

from pandas.tseries.offsets import MonthEnd, MonthBegin

import patsy
# import pymc3 as pm
# from pymc3.glm import GLM


import sqlalchemy
from snowflake import connector 
from snowflake.sqlalchemy import URL
from snowflake.connector.pandas_tools import write_pandas
import json

from sklearn.feature_selection import VarianceThreshold, mutual_info_regression, SelectPercentile

from ast import literal_eval

from statsmodels.stats.outliers_influence import variance_inflation_factor
from sklearn.decomposition import PCA


import shap
import matplotlib.pyplot as plt

from sklearn.neural_network import MLPRegressor


logger_1= logging.getLogger('cmdstanpy')
logger_1.addHandler(logging.NullHandler())
logger_1.propagate = False
logger_1.setLevel(logging.CRITICAL)
logger_2= logging.getLogger('INFO')
logger_2.addHandler(logging.NullHandler())
logger_2.propagate = False
logger_2.setLevel(logging.CRITICAL)
logger_3= logging.getLogger('prophet')
logger_3.addHandler(logging.NullHandler())
logger_3.propagate = False
logger_3.setLevel(logging.CRITICAL)

from pathlib import Path
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
import optuna
import math

from snowflake.sqlalchemy import URL
from joblib import Parallel, delayed

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots
st.set_option('deprecation.showPyplotGlobalUse', False)

from io import BytesIO
import math
from statsmodels.tsa.api import ExponentialSmoothing