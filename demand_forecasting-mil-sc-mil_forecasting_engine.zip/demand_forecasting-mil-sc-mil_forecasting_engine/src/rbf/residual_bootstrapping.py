from ..models import CtsForecastClass
from ..helper import  os, np, pd, read_pickle_file, Prophet, Parallel, delayed, math, ExponentialSmoothing, math
from ..helper import GetGeneralPipelineInput, GetProphetPipelineInput, GetMlPipelineInput, GetCtsPipelineInput
from tqdm import tqdm

class RangeBasedForecasting( GetGeneralPipelineInput):
    """ Generate the range based forecasting results."""
    def __init__(self, input_dict):
        super().__init__(input_dict=input_dict)

        if type(input_dict['covid_months']) != list:
            self.covid_months = []
        else:
            self.covid_months = input_dict['covid_months']
        self.num_bootstrap = 100
        self.input_dict = input_dict

    def treat_residuals(
        self,
        res_df,
        use_smoothening,
        smoothening_level,
        shifting,
        scaling,
        scaling_factor,
    ):
        """
        This function cap the residual, between 5 percentile and 95 percentile and smoothen
        the residuals if the use_smoothening is true.

        Args:
            res_df: pandas dataframe
            - contains the residuals values

            use_smoothening: list
            - boolean flag to use or not applying smoothening

            smoothening: float
            - smoothening level to be applied on the residuals. It lies in between 0 to 1

            shifting: bool
            - flag to check the shifting operation should be applied or not

            scaling: bool
            - flag to indicate scaling should be applied or not

            scaling_factor: float
            - factor by scaling needed to done to the residuals

        Return
            resids: list
            - List of residuals after treatment.

        """
        resids = res_df["Res"].tolist()
        lower_cap, upper_cap = np.percentile(resids, 10), np.percentile(resids, 90)
        for idx in range(len(resids) - 1):
            if resids[idx] < lower_cap:
                resids[idx] = lower_cap
            elif resids[idx] > upper_cap:
                resids[idx] = upper_cap

        if (use_smoothening is True) and len(resids) > 10:
            fit = ExponentialSmoothing(resids, initialization_method="heuristic").fit(
                smoothing_level=smoothening_level, optimized=False
            )
            resids = fit.fittedvalues.tolist()

        if shifting is True:
            resids = [res - np.mean(resids) for res in resids]
        if scaling is True:
            if scaling_factor == 0:
                scaling_factor = 1
            resids = [res * scaling_factor for res in resids]

        return resids

    def add_interval_widths( self, rb_results):
        """
        Calculate and add the Different Interval widths to the data.

        Args:
            rb_results: pandas dataframe
            - dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            - input dataframe with having the interval width for 60%, 70%, 80% and 90%

        """
        interval_widths = [
            "60% Interval Width",
            "70% Interval Width",
            "80% Interval Width",
            "90% Interval Width",
        ]

        for width in interval_widths:
            width_val = int(width.split("%")[0])
            diff = int((100 - width_val) / 2)
            upper_lim, lower_lim = str(int(100 - diff)) + "%", str(int(diff)) + "%"
            rb_results[width] = np.abs(rb_results[lower_lim] - rb_results[upper_lim]) / (
                2 * rb_results["Pt Est"]
            )

        return rb_results

    def add_cohort_column( self, rb_results):
        """
        Add the cohort columns to the range based forecast results.

        Args:
            rb_results: pandas dataframe
            -  dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            -  input dataframe with added cohort column
        """
        Cohort = []
        for idx in range(len(rb_results)):
            act = rb_results["Actual"].iloc[idx]
            five_prcnt, ninty_five_prcnt = (
                rb_results["5%"].iloc[idx],
                rb_results["95%"].iloc[idx],
            )

            if five_prcnt <= act <= ninty_five_prcnt:
                Cohort.append("In Range")
            elif act > ninty_five_prcnt:
                Cohort.append("Under Forecast")
            else:
                Cohort.append("Over Forecast")

        rb_results["Cohort"] = Cohort
        return rb_results

    def add_range_error_column( self, rb_results):
        """
        Calculate the the range error of the actual value from  5 percentile in case of
        underforecast and 95 percentile in case of underforecast

        Args:
            rb_results: pandas dataframe
            -  dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            -  input dataframe with added range error column

        """
        range_error = []
        for idx in range(len(rb_results)):
            act = rb_results["Actual"].iloc[idx]
            cohort = rb_results["Cohort"].iloc[idx]
            five_prcnt, ninety_five_prcnt = (
                rb_results["5%"].iloc[idx],
                rb_results["95%"].iloc[idx],
            )

            if cohort == "In Range":
                range_error.append(0)
            elif cohort == "Under Forecast":
                range_error.append(abs(act - ninety_five_prcnt))
            else:
                range_error.append(abs(act - five_prcnt))

        rb_results["Abs Error Range"] = range_error
        return rb_results

class ProphetResidualBootstrapping( RangeBasedForecasting):
    """
    This class contains the method to perform residual bootstrapping
    using prophet model.
    """

    def __init__(self, df, input_dict) -> None:
        super().__init__(input_dict=input_dict)
        self.df = df
        self.prophet_model_obj = GetProphetPipelineInput( df=df, input_dict=input_dict)
        self.result_path = os.path.join(self.location_to_save, 'prophet_results/validation/')
        
    def initialise_prophet_model(self, best, key):
        """
        Initialise the prophet model and return prophet model object.
        """
        if pd.isnull(self.di_model_input['holiday_data_type']) is False:
            holidays_df = self.prophet_model_obj.create_holidays_df(Key=key)
        else:
            holidays_df = pd.DataFrame()

        prophet_model = Prophet(
            holidays=holidays_df,
            changepoint_prior_scale=float(best["changepoint_prior_scale"]),
            changepoint_range=float(best["changepoint_range"]),
            seasonality_prior_scale=float(best["seasonality_prior_scale"]),
        )
        return prophet_model

    def fit_prophet_model(
        self,
        resids,
        Key,
        train_data_forecast,
        to_train_updated,
        best,
        no_of_forecast_dates,
        forecast_date):
        """
        Update the target values and fits the prophet model on the
        updated target values.
        """
        boot_resids = np.random.choice(resids, len(resids), replace=True)
        to_train_updated["y"] = train_data_forecast["yhat"].values + boot_resids
        prophet_model = self.initialise_prophet_model(best, Key)
        prophet_model.fit(to_train_updated)
        future = prophet_model.make_future_dataframe(
            periods=no_of_forecast_dates, freq="M"
        )
        forecast = prophet_model.predict(future)
        pred_val = forecast[forecast["ds"] == forecast_date]["yhat"].values[0]
        return pred_val

    def prophet_residual_bootstrapping(
        self,
        Key,
        forecast_date,
        scaling,
        shifting,
        scaling_factor,
        use_smoothening,
        smoothening_level,
        ):
        """
        Generate the prophet residual bootstrap forecasting results.

        Args:
            df: pandas dataframe
            - Master data contains data for all the keys

            Key: string
            - Key ( granularity level i.e. psku, asm_depot_psku) for which forecast needs to be generated

            forecast_date: string
            - forecast month in yyyy-mm-dd format

            scaling: bool
            - flag to indicate scaling should be applied or not

            shifting: bool
            - flag to check the shifting operation should be applied or not

            scaling_factor: float
            - factor by scaling needed to done to the residuals

            use_smoothening: bool
            - parameter to specify smoothening on residual should be applied or not

            smoothening_level: float
            - smoothening level between 0 and 1

        Return:
            test_predictions: list
            - list of bootstrap generated forecast results for prophet model
        """
        test_predictions = []

        df_prophet = self.df[self.df.key == str(Key)]
        df_prophet = df_prophet.groupby(["key", self.DATE_COL], as_index=False).agg(
            { self.target_column: sum}
        )
        df_prophet.columns = ["key", "ds", "y"]

        # df_prophet = treat_covid_months(df, df_prophet, date_col="ds", target_column="y")
        # df_prophet = treat_target_col_outliers(
        #     df, df_prophet, target_col=target_column_prophet, date_col_input="ds"
        # )

        prophet_pickle_file = os.path.join( self.result_path, 'prophet_models.pkl')
        prophet_best_hyperparameter_dict = read_pickle_file(input_file_path= prophet_pickle_file )


        if type(list(prophet_best_hyperparameter_dict.keys())[0])== str:
            best = prophet_best_hyperparameter_dict[str(Key)]
        else:
            best = prophet_best_hyperparameter_dict[Key]
            

        prophet_model = self.initialise_prophet_model(best, Key)
        to_train = df_prophet[df_prophet["ds"] <= self.di_model_input['train_till_date']]

        prophet_model.fit(to_train)
        forecast_horizon = math.ceil(
            (pd.to_datetime(forecast_date) - self.di_model_input['train_till_date']).days / 30
        )
        future = prophet_model.make_future_dataframe(
            periods=forecast_horizon, freq="M"
        )
        forecast = prophet_model.predict(future)
        forecast["yhat"] = forecast["yhat"].apply(lambda x: 0 if x < 0 else x)
        forecast = pd.merge(forecast, df_prophet, on="ds", how="left")
        forecast["key"] = forecast["key"].fillna(Key)

        to_train_updated = to_train.copy()
        to_train_updated["y"] = forecast[forecast["ds"] <= self.di_model_input['train_till_date']]["yhat"].values
        train_data_forecast = forecast[forecast["ds"] <= self.di_model_input['train_till_date']]

        resids = train_data_forecast["yhat"] - train_data_forecast["y"]

        res_df = pd.DataFrame({"Date": to_train_updated["ds"].tolist(), "Res": resids})
        res_df.loc[res_df["Date"].isin( self.covid_months), "Res"] = res_df[
            ~res_df["Date"].isin( self.covid_months)
        ]["Res"].median()

        resids = self.treat_residuals(
            res_df, use_smoothening, smoothening_level, shifting, scaling, scaling_factor
        )

        test_predictions = Parallel(n_jobs=-2)(
        delayed( self.fit_prophet_model)(
            resids,
            Key,
            train_data_forecast,
            to_train_updated,
            best,
            forecast_horizon,
            forecast_date,
        )
        for _ in range(self.num_bootstrap)
    )


        return test_predictions


class RegressionResidualBootstrapping( RangeBasedForecasting):
    """ Generate the range based forecast result for any sklearn regression model."""

    def __init__(self, df, input_dict, model_type):
        super().__init__(input_dict)
        self.ml_pipeline_input_obj = GetMlPipelineInput( df=df, input_dict=input_dict)
        self.model_type  = model_type
        self.val_result_path = f"{self.location_to_save}/ml_results/validation"
        self.forecast_result_path = f"{self.location_to_save}/ml_results/forecast"
        self.ml_best_model_pkl =  os.path.join(self.val_result_path, "ml_models.pkl")
        self.ml_best_models = read_pickle_file(self.ml_best_model_pkl)

    def fit_ml_model(self, resids, y_pred, reg_rf, train_data, valid_data):
        """Update the target and fit on the random forest regression model."""
        boot_resids = np.random.choice(resids, len(resids), replace=True)
        y_temp = y_pred + boot_resids
        reg_rf.fit(train_data, y_temp)
        y_valid_pred = reg_rf.predict(valid_data)
        return y_valid_pred

    def get_train_data_df( self, key):
        """ Read and return regression train df for the key """

        #if data_type == 'validation':
        for file in os.listdir( self.forecast_result_path):
            if 'forecast_data' in file.lower():
                train_df = pd.read_csv( os.path.join( self.forecast_result_path, file))
                train_df[self.DATE_COL] = pd.to_datetime(train_df[self.DATE_COL])
                if str(key) in train_df['key'].astype(str).unique():
                    key_train_df = train_df[ train_df['key'].astype(str) == str(key)]
                    break
        # else:
        #      for file in os.listdir( self.forecast_result_path):
        #         if 'forecast_data' in file.lower():
        #             train_df = pd.read_csv( os.path.join( self.forecast_result_path, file))
        #             if str(key) in train_df['key'].astype(str).unique():
        #                 key_train_df = train_df[ train_df['key'].astype(str) == str(key)]
        #                 break
        return key_train_df


    def ml_residual_bootstrapping(
        self,
        key,
        forecast_date,
        shifting,
        scaling,
        scaling_factor,
        use_smoothening,
        smoothening_level,
    ):
        """
        Generate the machine learning model residual bootstrap forecasting results.

        Args:
            ml_train_data: pandas dataframe
            - Master data contains data for all the keys

            Key: string
            - Key ( granularity level i.e. psku, asm_depot_psku) for which forecast needs to be generated

            model_name: string
            - Time series model name have to be mentioned ARIMA or SARIMA

            forecast_date: string
            - forecast month in yyyy-mm-dd format

            scaling: bool
            - flag to indicate scaling should be applied or not

            shifting: bool
            - flag to check the shifting operation should be applied or not

            scaling_factor: float
            - factor by scaling needed to done to the residuals

            use_smoothening: bool
            - parameter to specify smoothening on residual should be applied or not

            smoothening_level: float
            - smoothening level between 0 and 1


        Return:
            test_predictions: list
            - list of bootstrap generated forecast results for specified machine learning model
        """

        test_predictions = []
        to_drop = [
            self.DATE_COL,
            "key", self.target_column, "Year", "Month", "Value", "pred", "Model_Type", "pred_xgb", "pred_rf",
            "rf_residuals", "xgb_residuals", "Forecast_month", "brand_code", "qtr_ind_rate", "BPM", "psku",
            "Data_Type",  "cutoff", 'Brand Name','pred_value', 'sec_kl_value', 'turnover'
        ]

        data =  self.get_train_data_df( key)
        train = data[data[self.DATE_COL]<= self.di_model_input['train_till_date']]
        valid = data[data[self.DATE_COL].isin(self.actual_forecast_period)]
        train[self.target_column] = train[self.target_column]
        # ml_train_df = ml_train_data[ml_train_data["key"] == key]

        
        if 'advanced_feature_selection_final_data.csv' in os.listdir( self.location_to_save):
            selected_inputs = pd.read_csv( os.path.join( self.location_to_save, 'advanced_feature_selection_final_data.csv'))
            selected_inputs = eval(selected_inputs.loc[selected_inputs['key'].astype(str)==key, 'k_best_features_name'].loc[0])
            selected_inputs = selected_inputs + [self.DATE_COL, self.target_column]
            train, valid = train[selected_inputs], valid[selected_inputs]

        if type(list(self.ml_best_models.keys())[0]) == str:
            reg_rf = self.ml_best_models[str(key)][self.model_type.lower()]
        else:
            reg_rf = self.ml_best_models[key][self.model_type.lower()]

        train_data, valid_data = train.copy(), valid.copy()

        valid_data = valid_data[valid_data[self.DATE_COL]==forecast_date]
        train_data.drop(to_drop, axis=1, errors="ignore", inplace=True)
        valid_data.drop(to_drop, axis=1, errors="ignore", inplace=True)

        y_train_pred = reg_rf.predict(train_data)

        resids = train[self.target_column] - y_train_pred
        res_df = pd.DataFrame({"Date": train[self.DATE_COL].copy(), "Res": resids})
        res_df.loc[res_df["Date"].isin(self.covid_months), "Res"] = res_df[
            ~res_df["Date"].isin(self.covid_months)
        ]["Res"].median()

        resids = self.treat_residuals(
            res_df,
            use_smoothening,
            smoothening_level,
            shifting,
            scaling,
            scaling_factor,
        )

        test_predictions = []
        for _ in range(self.num_bootstrap):
            pred = self.fit_ml_model(resids, y_train_pred, reg_rf, train_data, valid_data)
            test_predictions.append(pred)

        test_predictions = [val.tolist()[0] for val in test_predictions]
        # print( Key,': \n', test_predictions)
        return test_predictions


class CTSResidualBootstrapping( RangeBasedForecasting):

    def __init__(self, df, input_dict, model_type, forecast_date):
        super().__init__(input_dict)
        self.df = df
        self.forecast_date = pd.to_datetime(forecast_date)
        self.cts_model_type = model_type
        self.cts_dir = f"{self.location_to_save}/cts/{self.cts_model_type}/forecast/"
        cts_stepwise_model_file = f"{self.cts_model_type}_models.pkl"
        self.cts_stepwise_models = read_pickle_file( os.path.join( self.cts_dir, cts_stepwise_model_file))
        input_dict[f"{model_type}_dir"] = self.cts_dir
        self.cts_data = GetCtsPipelineInput(df, input_dict)
        self.cts_forecast = CtsForecastClass(df=df, input_dict=input_dict, model_type= model_type )
    
    def fit_cts_model( self, train, valid, resids, y_pred ):
        boot_resids = np.random.choice(resids, len(y_pred), replace=True)
        y_updated = boot_resids[0] + y_pred
        train.loc[:,self.target_column] = list(y_updated)
        if self.cts_model_type == "ARIMA":
            _, result, _ = self.cts_forecast.fit_arima_model(train, valid)
        else:
            _, result, _ = self.cts_forecast.fit_sarima_model(train, valid)

        forecast = result[result[self.DATE_COL]==self.forecast_date]['pred'].iloc[0]
        return forecast


    def cts_residual_bootstrapping(
        self,
        Key,
        shifting,
        scaling,
        scaling_factor,
        use_smoothening,
        smoothening_level,
    ):
        """
        Time Series Model Residuals Bootstrapping Results.

        Args:
            df: pandas dataframe
            - Master data contains data for all the keys

            Key: string
            - Key ( granularity level i.e. psku, asm_depot_psku) for which forecast needs to be generated

            model_name: string
            - Time series model name have to be mentioned ARIMA or SARIMA

            forecast_date: string
            - forecast month in yyyy-mm-dd format

            scaling: bool
            - flag to indicate scaling should be applied or not

            shifting: bool
            - flag to check the shifting operation should be applied or not

            scaling_factor: float
            - factor by scaling needed to done to the residuals

            use_smoothening: bool
            - parameter to specify smoothening on residual should be applied or not

            smoothening_level: float
            - smoothening level between 0 and 1

        Return:
            test_predictions: list
            - list of bootstrap generated forecast results

        """

        test_predictions = []
        # df_cts_data = self.df[["key", self.DATE_COL, self.target_column]]
        data = self.cts_data.df_cts_data[ self.cts_data.df_cts_data["key"] == Key]
        # data = self.treat_covid_months( self.df, data)
        
        # data = treat_target_col_outliers(
        #     df, data, target_col= self.target_column, date_col_input=self.DATE_COL
        # )
        
        train, valid = (
            data[data[ self.DATE_COL] <= self.di_model_input['train_till_date']],
            data[data[ self.DATE_COL].isin( self.actual_forecast_period)],
        )

        x, y = train[self.DATE_COL].copy(), train[ self.target_column].copy()
        stepwise_model = self.cts_stepwise_models[Key]

        resids = stepwise_model.resid()
        pred, _ = stepwise_model.predict(n_periods=valid.shape[0] + 1, return_conf_int=True)
        pred = pred.tolist()[1]

        res_df = pd.DataFrame({"Date": x.tolist(), "Res": resids})
        res_df.loc[res_df["Date"].isin( self.covid_months), "Res"] = res_df[
            ~res_df["Date"].isin( self.covid_months)
        ]["Res"].median()
        resids = res_df["Res"]

        resids = self.treat_residuals(
            res_df, use_smoothening, smoothening_level, shifting, scaling, scaling_factor
        )

        y_pred = y + resids
        train = train.set_index( self.DATE_COL)
        valid = valid.set_index( self.DATE_COL)

        test_predictions = Parallel(n_jobs=-2)(
        delayed( self.fit_cts_model)(
             train, valid, resids, y_pred
        )
        for _ in range(self.num_bootstrap)
    )
        return test_predictions