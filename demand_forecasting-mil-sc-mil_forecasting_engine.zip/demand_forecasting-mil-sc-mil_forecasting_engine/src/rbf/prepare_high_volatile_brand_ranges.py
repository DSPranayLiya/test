

from ..helper import np, pd, tqdm, MonthEnd, statistics, os, sys
from .range_base_forecasting import RBFResultPreparation


# from read_inputs import Input
# import mil_config as mil_config
# from rbf_helper_functions import prepare_range_base_results
# from mil_helper_functions import fetch_dates, mil_result_path
# from get_sales_data import _fetch_sales_data




class HighVolatileBrandRange:

    def __init__(self) -> None:
        self.prepare_range_base_results = RBFResultPreparation().prepare_range_base_results
        pass

    def range_width( self, lower_lim, upper_lim, pt_fct):
        """ """
        width = abs(upper_lim - lower_lim) / (2 * pt_fct)
        return width


    def point_acc(self, actuals, pred):
        if actuals == 0: 
            return 0
        else:
            err = abs(actuals - pred)
            if 1 - (err / actuals) > 0:
                return 1 - (err / actuals)
            else:
                return 0


    def check_range(self, lower_lim, upper_lim, actuals):
        if actuals >= lower_lim and actuals <= upper_lim:
            return "In Range"

        elif actuals < lower_lim:
            return "Overforecast"

        else:
            return "Underforecast"


    def measure_dis( self, num, arr):
        std_dev = statistics.stdev(arr)
        mean = statistics.mean(arr)
        if std_dev != 0:
            return (num - mean) / std_dev
        else:
            return -1



    def predict(self, df,key,forecast_month,stdev_mul):
        # print(key,forecast_month)
        forecast_month = pd.to_datetime(forecast_month)
        actuals = float(df[(df['key']==key)&(df["month_date"]==forecast_month)]["sec_vol_actuals_rum_month"])
        
        data = df[(df['key']==key)&(df["month_date"]<=forecast_month+MonthEnd(-2))].reset_index(drop=True)
        data = data.sort_values('month_date')
        
        forecast = 0

        l12m = data.tail(12).sec_vol_actuals_rum_month
        p6m = data.tail(6).sec_vol_actuals_rum_month.mean()
        p3m = data.tail(3).sec_vol_actuals_rum_month.mean()
        p12m = data.tail(12).sec_vol_actuals_rum_month.mean()
        lm = float(data.iloc[-1].sec_vol_actuals_rum_month)
        llm = float(data.iloc[-2].sec_vol_actuals_rum_month)
        

        prev_month = [p6m, p3m, lm, llm]
        cov_var = [0 if self.measure_dis(x, l12m)==-1 else abs(self.measure_dis(x, l12m)-1) for x in prev_month]
        forecast = prev_month[cov_var.index(min(cov_var))]
        # forecast = p6m
        stdev = statistics.stdev(l12m)

        lower_lim = max(forecast - stdev_mul*stdev,0)
        upper_lim = forecast + stdev_mul*stdev

        data['forecast_month'] = forecast_month
        range = self.check_range(lower_lim=lower_lim, upper_lim=upper_lim, actuals=actuals)
        acc = self.point_acc(actuals,forecast)

        pred = {'key':key,'month_date':[forecast_month],'sec_vol_actuals_rum_month':[actuals], 
                    'pred_vol':[forecast],
                    'forecast_month':[forecast_month],'lower_lim':[lower_lim],'upper_lim':[upper_lim], 
                    'check_range':[range],'point_acc':[acc]}
        data = pd.concat([data,pd.DataFrame(pred)], ignore_index=True, axis=0)

        return data

    def prepare_high_volatile_brands_results(self, data, high_vol_brands, forecast_months):
        """
        
        """

        # map_master = data[['month_date','key','seasonal_month_flag','npd_flag']]
        # map_master = map_master.drop_duplicates().reset_index().drop(columns='index')   

        brand_master = data[['brand_code','key']]
        brand_master = brand_master.drop_duplicates().reset_index().drop(columns='index')   

        ind_rate = data[['brand_code','month_date']]
        ind_rate = ind_rate.drop_duplicates().reset_index().drop(columns='index')

        df = data.loc[data["brand_code"].isin(high_vol_brands), :].reset_index().drop(columns="index")
        df = df.drop(columns=['brand_code','free','seasonal_month_flag','npd_flag'],axis=1, errors='ignore')

        # pred_df = pd.DataFrame(columns=)
        pred_results = []
        for key in tqdm(df.key.unique()):
            for month in forecast_months:
                pred_results.append(self.predict(df,key,month,1))

        columns = ['key','month_date','forecast_month',
                                    'sec_vol_actuals_rum_month','pred_vol','lower_lim',
                                    'upper_lim','check_range','point_acc']
        
        pred_df = pd.concat( pred_results, axis=0, ignore_index=True)
        pred_df = pred_df[columns]
        
        pred_df = pred_df[~pred_df['check_range'].isnull()].reset_index(drop=True)
        pred_df = pred_df.drop_duplicates()

        pred_df = pred_df.merge(brand_master, on='key', how='left')
        pred_df = pred_df.merge(ind_rate, on=['brand_code','month_date'], how='left')

        # pred_df['bpm'] = pred_df['sec_vol_actuals_rum_month']*pred_df['qtr_ind_rate']/10**7

        plot_df = pred_df.rename(columns={'pred_vol':'Pt Est','sec_vol_actuals_rum_month':'Actual','lower_lim':'5%','upper_lim':'95%','check_range':'Cohort', 'forecast_month':'Forecast_month'})
        plot_df = plot_df.drop(columns={'month_date','point_acc'})

        plot_df['10%'] = plot_df['15%'] = plot_df['20%'] = plot_df['5%']
        plot_df['80%'] = plot_df['85%'] = plot_df['90%'] = plot_df['95%']

        plot_df.loc[:,'model'] = 'High_COV'
        columns=[ 'Forecast_month', 'key', 'model', 'Pt Est',  '5%', '10%',	'15%',	'20%',	'80%',	'85%',	'90%',	'95%']

        plot_df = plot_df[columns]

        final_results = []
        for month, df in plot_df.groupby(by='Forecast_month'):
            final_results.append(self.prepare_range_base_results( df.values.tolist(), use_smoothening=False, forecast_month=month, smoothening_level=False, shifting=False, scaling_factor=False))
        
        final_result_df = pd.concat( final_results, ignore_index=True, axis=0)
        return final_result_df


