
from ..helper import os, pickle, np, pd

class RBFResultPreparation():

    def __init__(self):
        pass

    def _add_interval_widths( self, rb_results):
        """
        Calculate and add the Different Interval widths to the data.

        Args:
            rb_results: pandas dataframe
            - dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            - input dataframe with having the interval width for 60%, 70%, 80% and 90%

        """
        interval_widths = [
            "60% Interval Width",
            "70% Interval Width",
            "80% Interval Width",
            "90% Interval Width",
        ]

        for width in interval_widths:
            width_val = int(width.split("%")[0])
            diff = int((100 - width_val) / 2)
            upper_lim, lower_lim = str(int(100 - diff)) + "%", str(int(diff)) + "%"
            rb_results[width] = np.abs(rb_results[lower_lim] - rb_results[upper_lim]) / (
                2 * rb_results["Pt Est"]
            )

        return rb_results


    def _add_cohort_column( self, rb_results):
        """
        Add the cohort columns to the range based forecast results.

        Args:
            rb_results: pandas dataframe
            -  dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            -  input dataframe with added cohort column
        """
        Cohort = []
        for idx in range(len(rb_results)):
            act = rb_results["Actual"].iloc[idx]
            five_prcnt, ninty_five_prcnt = (
                rb_results["5%"].iloc[idx],
                rb_results["95%"].iloc[idx],
            )

            if five_prcnt <= act <= ninty_five_prcnt:
                Cohort.append("In Range")
            elif act > ninty_five_prcnt:
                Cohort.append("Under Forecast")
            else:
                Cohort.append("Over Forecast")

        rb_results["Cohort"] = Cohort
        return rb_results


    def _add_range_error_column( self, rb_results):
        """
        Calculate the the range error of the actual value from  5 percentile in case of
        underforecast and 95 percentile in case of underforecast

        Args:
            rb_results: pandas dataframe
            -  dataframe contains the residual bootstrapping results

        Return:
            rb_results: pandas dataframe
            -  input dataframe with added range error column

        """
        range_error = []
        for idx in range(len(rb_results)):
            act = rb_results["Actual"].iloc[idx]
            Cohort = rb_results["Cohort"].iloc[idx]
            five_prcnt, ninety_five_prcnt = (
                rb_results["5%"].iloc[idx],
                rb_results["95%"].iloc[idx],
            )

            if Cohort == "In Range":
                range_error.append(0)
            elif Cohort == "Under Forecast":
                range_error.append(abs(act - ninety_five_prcnt))
            else:
                range_error.append(abs(act - five_prcnt))

        rb_results["Abs Error Range"] = range_error
        return rb_results


    def prepare_range_base_results(
        self,
        final_List_Output,
        use_smoothening,
        forecast_month,
        smoothening_level,
        shifting,
        scaling_factor,
    ):
        """
        Finalise the range based forecast results.

        Args:
            final_List_Output: list
            - list contains output from parallel processing for range forecast

            use_smoothening: bool
            - If True smoothening is applied on the residuals else not applied

            forecast_month: string
            - forecast month in yyyy-mm-dd format

            smoothening_level: float
            - smoothening level between 0 and 1

        Return:
            best_model_range_forecast: pandas dataframe
            - final output dataframe for range forecast results.

        """

        columns = [
            "forecast_date",
            "key",
            "model",
            "Pt Est",
            "5%",
            "10%",
            "15%",
            "20%",
            "80%",
            "85%",
            "90%",
            "95%",
        ]

        best_model_range_forecast = pd.DataFrame(final_List_Output, columns=columns)
        
        best_model_range_forecast["Pt Est"] = best_model_range_forecast["Pt Est"].apply(
            lambda x: x[0] if type(x) == np.ndarray else x
        )

        # filtering out if any extra column is present
        best_model_range_forecast = best_model_range_forecast[columns]

        #best_model_range_forecast = self._add_cohort_column(best_model_range_forecast)
        #best_model_range_forecast = self._add_range_error_column(best_model_range_forecast)
        best_model_range_forecast = self._add_interval_widths(best_model_range_forecast)

        # Specifying the point estimate of forecast lies in between the max range
        best_model_range_forecast["In Range"] = True

        best_model_range_forecast.loc[
            best_model_range_forecast["Pt Est"] < best_model_range_forecast["5%"],
            "In Range",
        ] = False

        best_model_range_forecast.loc[
            best_model_range_forecast["Pt Est"] > best_model_range_forecast["95%"],
            "In Range",
        ] = False

        best_model_range_forecast["Forecast_date"] = forecast_month

        if use_smoothening == True:
            best_model_range_forecast["smoothen_level"] = smoothening_level
        else:
            best_model_range_forecast["smoothen_level"] = "Not Smoothen"

        best_model_range_forecast["Shifting"] = shifting
        best_model_range_forecast["Scaling Factor"] = scaling_factor

        return best_model_range_forecast
