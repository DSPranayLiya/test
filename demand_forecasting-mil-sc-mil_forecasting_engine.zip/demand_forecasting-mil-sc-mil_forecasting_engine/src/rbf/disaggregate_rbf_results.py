import sys, os
sys.path.insert(0, "./mil_demand_forecast")

import statistics
import pandas as pd
import numpy as np
from tqdm import tqdm
from pandas.tseries.offsets import MonthEnd
from read_inputs import Input
import mil_config as mil_config
from rbf_helper_functions import prepare_range_base_results
from mil_helper_functions import fetch_dates, mil_result_path
from get_sales_data import _fetch_sales_data

user_input = Input()

def disaggregate_results( main_df, rbf_result, forecast_month):

    main_df  = main_df[main_df['Forecast_Month']== forecast_month]
    psku_level_main_df = main_df.groupby(['Forecast_Month', 'parent_material1_code' ], as_index=False)[final_vol_col].agg(sum)
    psku_level_main_df.columns = ['Forecast_Month', 'parent_material1_code', 'Agg_SUM']

    main_df = pd.merge(   main_df, psku_level_main_df, on=['Forecast_Month', 'parent_material1_code'], how='left').sort_values(by=['Forecast_Month', 'parent_material1_code'])
    main_df['Contribution'] = main_df[final_vol_col]/ main_df['Agg_SUM']

    # final_df  = []
    # for brand in rbf_model_selection_file['brand_code'].unique():
    #     model = rbf_model_selection_file[ rbf_model_selection_file['brand_code'] == brand]['Model'].iloc[0]
    #     temp =  rbf_result[(rbf_result['Model'] == model)&(rbf_result['Scaling Factor'] == 2)&(rbf_result['brand_code'] == brand)]
    #     final_df.append(temp)
    
    high_cov_brands = rbf_result[ rbf_result['High Volatile Brand Result']==True]
    
    # rbf_result = pd.concat( final_df, axis=0,ignore_index=True)
    rbf_result = rbf_result[(rbf_result['Model'] == 'Prophet')&(rbf_result['Scaling Factor'] == 0)]
    rbf_result = pd.concat( [ rbf_result, high_cov_brands], axis=0, ignore_index=True)
    rbf_result = rbf_result[['Forecast_month', 'key', 'Pt Est']]
    rbf_result = rbf_result[pd.to_datetime(rbf_result['Forecast_month']) == pd.to_datetime(forecast_month)]
    rbf_result = rbf_result.drop_duplicates(keep='first', subset=['Forecast_month', 'key'])
    rbf_result.columns  = ['Forecast_Month', 'parent_material1_code', 'RBF Pt Est']
    
    main_df['Forecast_Month'] = pd.to_datetime(main_df['Forecast_Month'])
    rbf_result['Forecast_Month'] = pd.to_datetime(rbf_result['Forecast_Month'])

    main_df = pd.merge( main_df, rbf_result, on=['Forecast_Month', 'parent_material1_code'], how='left')

    for key in main_df[main_df['Contribution'].isna()]['parent_material1_code'].unique():
        main_df.loc[main_df['parent_material1_code'] == key, 'Contribution'] = 1/len(main_df[main_df['parent_material1_code'] == key ])

    main_df['final_vol_great_0'] = main_df['RBF Pt Est']* main_df['Contribution']
    main_df['final_val_great_0'] = (main_df['final_vol_great_0']*main_df['qtr_ind_rate'])/10**7

    print(f" RBF Point Estimate Sum ({forecast_month}): {rbf_result['RBF Pt Est'].sum()}")
    print(f" Updated Point Estimate Sum ({forecast_month}): {main_df['final_vol_great_0'].sum()}")
    return main_df

if __name__  == "__main__":

    brands_to_filter = user_input.read_brands_to_filter()
    rbf_result_dir  = mil_result_path( 'RBF')
    #rbf_model_selection_file = pd.read_excel( os.path.join(rbf_result_dir, f'{mil_config.CHANNEL_NAME}_model_selection.xlsx'))
    rbf_result = pd.read_excel( os.path.join(rbf_result_dir, f'{mil_config.CHANNEL_NAME}_RBF_Aggregated_results.xlsx'))
    rbf_result['key'] = rbf_result['key'].astype(int)
    rbf_result['Forecast_month'] = pd.to_datetime(rbf_result['Forecast_month'])
    mil_result_dir =  mil_result_path(model_name=False).replace("RBF", "MIL")
    mil_pt_est_result = pd.read_excel( os.path.join( mil_result_dir,f"{mil_config.CHANNEL_NAME}_July'23_to_Sept'23_Forecast.xlsx"), sheet_name='base')

    mil_pt_est_result = mil_pt_est_result[mil_pt_est_result['brand_code'].isin(rbf_result['brand_code'].unique())]

    # calculate contribution 
 
    main_df = mil_pt_est_result.copy()
    for col in main_df.columns:
        if 'final_vol' in col.lower(): final_vol_col = col
    

    results_list = []

    for forecast_month in rbf_result['Forecast_month'].unique():
        results_list.append( disaggregate_results( main_df.copy(), rbf_result, forecast_month))
    
    result_df = pd.concat( results_list, ignore_index=True, axis=0)
    result_file_name = f"{mil_config.CHANNEL_NAME}_National_PSKU_to_ASM_DEPOT_Disaggregation.xlsx"
    result_df = result_df[result_df['Month']!=9]
    result_df.to_excel( os.path.join( mil_result_dir, result_file_name), index=False)
